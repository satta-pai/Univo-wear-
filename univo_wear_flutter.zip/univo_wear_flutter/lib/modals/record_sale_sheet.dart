import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/stock_item.dart';
import '../models/sale.dart';
import '../providers/auth_provider.dart';
import '../utils/helpers.dart';

class RecordSaleSheet extends ConsumerStatefulWidget {
  final StockItem item;
  final String? initialSize;
  const RecordSaleSheet({super.key, required this.item, this.initialSize});

  @override
  ConsumerState<RecordSaleSheet> createState() => _RecordSaleSheetState();
}

class _RecordSaleSheetState extends ConsumerState<RecordSaleSheet> {
  late String _selectedSize;
  final _qtyCtrl = TextEditingController(text: '1');
  final _discCtrl = TextEditingController(text: '0');
  late final TextEditingController _priceCtrl;
  String _payment = 'Cash';

  @override
  void initState() {
    super.initState();
    final availSizes = widget.item.sizes.entries.where((e) => e.value > 0).map((e) => e.key).toList();
    _selectedSize = widget.initialSize ?? (availSizes.isNotEmpty ? availSizes.first : 'Free Size');
    _priceCtrl = TextEditingController(text: widget.item.sellPrice.toStringAsFixed(0));
  }

  @override
  Widget build(BuildContext context) {
    final authUser = ref.watch(authStateProvider);
    final maxStaffDisc = ref.watch(maxStaffDiscountProvider);
    final sellPrice = double.tryParse(_priceCtrl.text) ?? 0;
    final unitDisc = (widget.item.sellPrice - sellPrice).clamp(0, double.infinity);
    final belowCostOrLimit = sellPrice < widget.item.costPrice || (!authUser.isAdmin && unitDisc > maxStaffDisc);

    return Padding(
      padding: EdgeInsets.only(
        left: 16, right: 16, top: 16,
        bottom: MediaQuery.of(context).viewInsets.bottom + 16,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Record Sale: ${widget.item.name}', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
          const SizedBox(height: 8),
          Wrap(
            spacing: 6,
            children: widget.item.sizes.entries.map((e) {
              final enabled = e.value > 0;
              return ChoiceChip(
                label: Text('${e.key} (${e.value})'),
                selected: _selectedSize == e.key,
                onSelected: enabled ? (_) => setState(() => _selectedSize = e.key) : null,
              );
            }).toList(),
          ),
          Row(
            children: [
              Expanded(child: TextField(controller: _qtyCtrl, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Qty'))),
              const SizedBox(width: 8),
              Expanded(
                child: TextField(
                  controller: _discCtrl,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(labelText: 'Less (₹)'),
                  onChanged: (v) {
                    final d = double.tryParse(v) ?? 0;
                    setState(() => _priceCtrl.text = (widget.item.sellPrice - d).clamp(0, double.infinity).toStringAsFixed(0));
                  },
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: TextField(
                  controller: _priceCtrl,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(labelText: 'Final Price (₹)'),
                  onChanged: (_) => setState(() {}),
                ),
              ),
            ],
          ),
          if (belowCostOrLimit)
            const Padding(
              padding: EdgeInsets.only(top: 6),
              child: Text('⚠️ Price is below Cost Price or Staff Discount Limit!', style: TextStyle(color: Colors.redAccent, fontSize: 11, fontWeight: FontWeight.bold)),
            ),
          const SizedBox(height: 12),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: () async {
                if (!authUser.isAdmin && belowCostOrLimit) return;
                final qty = int.tryParse(_qtyCtrl.text) ?? 1;
                final avail = widget.item.sizes[_selectedSize] ?? 0;
                if (avail < qty) return;

                final updatedSizes = Map<String, int>.from(widget.item.sizes);
                updatedSizes[_selectedSize] = avail - qty;
                final newTotalQty = updatedSizes.values.fold<int>(0, (a, b) => a + b);

                final updatedStock = StockItem(
                  id: widget.item.id,
                  name: widget.item.name,
                  category: widget.item.category,
                  colour: widget.item.colour,
                  colourName: widget.item.colourName,
                  sizes: updatedSizes,
                  qty: newTotalQty,
                  costPrice: widget.item.costPrice,
                  sellPrice: widget.item.sellPrice,
                  addedBy: widget.item.addedBy,
                  date: widget.item.date,
                  createdAt: widget.item.createdAt,
                );

                final total = sellPrice * qty;
                final mrpTotal = widget.item.sellPrice * qty;
                final sale = Sale(
                  id: makeId('INV'),
                  stockId: widget.item.id,
                  itemName: widget.item.name,
                  size: _selectedSize,
                  qty: qty,
                  mrpTotal: mrpTotal,
                  discount: (mrpTotal - total).clamp(0, double.infinity),
                  unitSellPrice: sellPrice,
                  totalSellPrice: total,
                  costPrice: widget.item.costPrice,
                  profit: total - (widget.item.costPrice * qty),
                  payment: _payment,
                  partnerId: authUser.uid,
                  soldBy: authUser.name,
                  date: getLocalDateString(),
                  time: TimeOfDay.now().format(context),
                  createdAt: DateTime.now().toIso8601String(),
                );

                await ref.read(firestoreServiceProvider).recordSale(sale, updatedStock);
                if (context.mounted) Navigator.pop(context);
              },
              child: const Text('Complete Sale'),
            ),
          ),
        ],
      ),
    );
  }
}
