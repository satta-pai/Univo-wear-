import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/stock_item.dart';
import '../providers/auth_provider.dart';
import '../utils/constants.dart';
import '../utils/helpers.dart';

class AddStockSheet extends ConsumerStatefulWidget {
  const AddStockSheet({super.key});

  @override
  ConsumerState<AddStockSheet> createState() => _AddStockSheetState();
}

class _AddStockSheetState extends ConsumerState<AddStockSheet> {
  final _nameCtrl = TextEditingController();
  final _costCtrl = TextEditingController();
  final _sellCtrl = TextEditingController();
  final _colourNameCtrl = TextEditingController();
  String _category = 'Pants';
  String _selectedHex = '#eab308';
  final Map<String, TextEditingController> _sizeCtrls = {};

  @override
  void initState() {
    super.initState();
    _initSizeControllers();
  }

  void _initSizeControllers() {
    _sizeCtrls.clear();
    for (final sz in sizesForCategory(_category)) {
      _sizeCtrls[sz] = TextEditingController(text: '0');
    }
  }

  @override
  Widget build(BuildContext context) {
    final sizes = sizesForCategory(_category);
    return Padding(
      padding: EdgeInsets.only(
        left: 16, right: 16, top: 16,
        bottom: MediaQuery.of(context).viewInsets.bottom + 16,
      ),
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('+ Add New Stock', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
            const SizedBox(height: 12),
            TextField(controller: _nameCtrl, decoration: const InputDecoration(labelText: 'Dress / Pants Name')),
            DropdownButton<String>(
              value: _category,
              isExpanded: true,
              items: kCategories.map((c) => DropdownMenuItem(value: c, child: Text(c))).toList(),
              onChanged: (v) {
                if (v != null) setState(() { _category = v; _initSizeControllers(); });
              },
            ),
            const SizedBox(height: 8),
            TextField(controller: _colourNameCtrl, decoration: const InputDecoration(labelText: 'Colour Name (e.g. Red, Olive)')),
            const SizedBox(height: 8),
            Wrap(
              spacing: 6,
              runSpacing: 6,
              children: kColourSwatches.map((s) {
                final selected = _selectedHex.toLowerCase() == s.hex.toLowerCase();
                return GestureDetector(
                  onTap: () => setState(() {
                    _selectedHex = s.hex;
                    _colourNameCtrl.text = s.name;
                  }),
                  child: Container(
                    width: 26,
                    height: 26,
                    decoration: BoxDecoration(
                      color: s.color,
                      shape: BoxShape.circle,
                      border: Border.all(color: selected ? Colors.amber : Colors.grey, width: selected ? 2.5 : 1),
                    ),
                  ),
                );
              }).toList(),
            ),
            const SizedBox(height: 12),
            Wrap(
              spacing: 8,
              children: sizes.map((sz) => SizedBox(
                width: 64,
                child: TextField(
                  controller: _sizeCtrls[sz],
                  keyboardType: TextInputType.number,
                  decoration: InputDecoration(labelText: sz),
                ),
              )).toList(),
            ),
            Row(
              children: [
                Expanded(child: TextField(controller: _costCtrl, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Cost Price (₹)'))),
                const SizedBox(width: 12),
                Expanded(child: TextField(controller: _sellCtrl, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Selling MRP (₹)'))),
              ],
            ),
            const SizedBox(height: 16),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: () async {
                  final sizeMap = <String, int>{};
                  int total = 0;
                  _sizeCtrls.forEach((k, ctrl) {
                    final cnt = int.tryParse(ctrl.text) ?? 0;
                    sizeMap[k] = cnt;
                    total += cnt;
                  });
                  if (_nameCtrl.text.trim().isEmpty || total <= 0) return;
                  final authUser = ref.read(authStateProvider);
                  final item = StockItem(
                    id: makeId('STK'),
                    name: _nameCtrl.text.trim(),
                    category: _category,
                    colour: _selectedHex,
                    colourName: _colourNameCtrl.text.trim(),
                    sizes: sizeMap,
                    qty: total,
                    costPrice: double.tryParse(_costCtrl.text) ?? 0,
                    sellPrice: double.tryParse(_sellCtrl.text) ?? 0,
                    addedBy: authUser.name,
                    date: getLocalDateString(),
                    createdAt: DateTime.now().toIso8601String(),
                  );
                  await ref.read(firestoreServiceProvider).saveStock(item);
                  if (context.mounted) Navigator.pop(context);
                },
                child: const Text('Save Stock'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
