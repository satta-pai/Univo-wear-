class Sale {
  final String id;
  final String stockId;
  final String itemName;
  final String size;
  final int qty;
  final double mrpTotal;
  final double discount;
  final double unitSellPrice;
  final double totalSellPrice;
  final double costPrice;
  final double profit;
  final String payment;
  final String partnerId;
  final String soldBy;
  final String date;
  final String time;
  final String createdAt;

  Sale({
    required this.id,
    required this.stockId,
    required this.itemName,
    required this.size,
    required this.qty,
    required this.mrpTotal,
    required this.discount,
    required this.unitSellPrice,
    required this.totalSellPrice,
    required this.costPrice,
    required this.profit,
    required this.payment,
    required this.partnerId,
    required this.soldBy,
    required this.date,
    required this.time,
    required this.createdAt,
  });

  Map<String, dynamic> toMap() => {
    'id': id,
    'stockId': stockId,
    'itemName': itemName,
    'size': size,
    'qty': qty,
    'mrpTotal': mrpTotal,
    'discount': discount,
    'unitSellPrice': unitSellPrice,
    'totalSellPrice': totalSellPrice,
    'costPrice': costPrice,
    'profit': profit,
    'payment': payment,
    'partnerId': partnerId,
    'soldBy': soldBy,
    'date': date,
    'time': time,
    'createdAt': createdAt,
  };

  factory Sale.fromMap(Map<String, dynamic> map) => Sale(
    id: map['id'] ?? '',
    stockId: map['stockId'] ?? '',
    itemName: map['itemName'] ?? '',
    size: map['size'] ?? 'Free Size',
    qty: (map['qty'] as num? ?? 1).toInt(),
    mrpTotal: (map['mrpTotal'] as num? ?? 0).toDouble(),
    discount: (map['discount'] as num? ?? 0).toDouble(),
    unitSellPrice: (map['unitSellPrice'] as num? ?? 0).toDouble(),
    totalSellPrice: (map['totalSellPrice'] as num? ?? 0).toDouble(),
    costPrice: (map['costPrice'] as num? ?? 0).toDouble(),
    profit: (map['profit'] as num? ?? 0).toDouble(),
    payment: map['payment'] ?? 'Cash',
    partnerId: map['partnerId'] ?? '',
    soldBy: map['soldBy'] ?? '',
    date: map['date'] ?? '',
    time: map['time'] ?? '',
    createdAt: map['createdAt'] ?? DateTime.now().toIso8601String(),
  );
}
