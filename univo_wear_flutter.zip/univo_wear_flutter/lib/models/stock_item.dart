class StockItem {
  final String id;
  final String name;
  final String category;
  final String colour;
  final String colourName;
  final Map<String, int> sizes;
  final int qty;
  final double costPrice;
  final double sellPrice;
  final String addedBy;
  final String date;
  final String createdAt;

  StockItem({
    required this.id,
    required this.name,
    required this.category,
    required this.colour,
    required this.colourName,
    required this.sizes,
    required this.qty,
    required this.costPrice,
    required this.sellPrice,
    required this.addedBy,
    required this.date,
    required this.createdAt,
  });

  Map<String, dynamic> toMap() => {
    'id': id,
    'name': name,
    'category': category,
    'colour': colour,
    'colourName': colourName,
    'sizes': sizes,
    'qty': qty,
    'costPrice': costPrice,
    'sellPrice': sellPrice,
    'addedBy': addedBy,
    'date': date,
    'createdAt': createdAt,
  };

  factory StockItem.fromMap(Map<String, dynamic> map) {
    final rawSizes = map['sizes'] as Map<String, dynamic>?;
    final parsedSizes = rawSizes != null
        ? rawSizes.map((k, v) => MapEntry(k, (v as num).toInt()))
        : <String, int>{'Free Size': (map['qty'] as num? ?? 0).toInt()};
    final total = parsedSizes.values.fold<int>(0, (a, b) => a + (b > 0 ? b : 0));
    return StockItem(
      id: map['id'] ?? '',
      name: map['name'] ?? '',
      category: map['category'] ?? 'Shirts',
      colour: map['colour'] ?? '#eab308',
      colourName: map['colourName'] ?? '',
      sizes: parsedSizes,
      qty: total,
      costPrice: (map['costPrice'] as num? ?? 0).toDouble(),
      sellPrice: (map['sellPrice'] as num? ?? 0).toDouble(),
      addedBy: map['addedBy'] ?? 'Owner',
      date: map['date'] ?? '',
      createdAt: map['createdAt'] ?? DateTime.now().toIso8601String(),
    );
  }
}
