class Partner {
  final String id;
  final String name;
  final String role;
  final double share;
  final String createdAt;

  Partner({
    required this.id,
    required this.name,
    required this.role,
    required this.share,
    required this.createdAt,
  });

  Map<String, dynamic> toMap() => {
    'id': id,
    'name': name,
    'role': role,
    'share': share,
    'createdAt': createdAt,
  };

  factory Partner.fromMap(Map<String, dynamic> map) => Partner(
    id: map['id'] ?? '',
    name: map['name'] ?? '',
    role: map['role'] ?? 'Staff',
    share: (map['share'] as num? ?? 0).toDouble(),
    createdAt: map['createdAt'] ?? DateTime.now().toIso8601String(),
  );
}
