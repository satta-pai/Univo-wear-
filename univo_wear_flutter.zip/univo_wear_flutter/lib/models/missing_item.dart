class MissingItem {
  final String id;
  final String stockId;
  final String itemName;
  final String size;
  final int qty;
  final double costPrice;
  final double lossAmount;
  final String reason;
  final String reportedBy;
  final String date;
  final String createdAt;

  MissingItem({
    required this.id,
    required this.stockId,
    required this.itemName,
    required this.size,
    required this.qty,
    required this.costPrice,
    required this.lossAmount,
    required this.reason,
    required this.reportedBy,
    required this.date,
    required this.createdAt,
  });

  Map<String, dynamic> toMap() => {
    'id': id,
    'stockId': stockId,
    'itemName': itemName,
    'size': size,
    'qty': qty,
    'costPrice': costPrice,
    'lossAmount': lossAmount,
    'reason': reason,
    'reportedBy': reportedBy,
    'date': date,
    'createdAt': createdAt,
  };

  factory MissingItem.fromMap(Map<String, dynamic> map) => MissingItem(
    id: map['id'] ?? '',
    stockId: map['stockId'] ?? '',
    itemName: map['itemName'] ?? '',
    size: map['size'] ?? 'Free Size',
    qty: (map['qty'] as num? ?? 1).toInt(),
    costPrice: (map['costPrice'] as num? ?? 0).toDouble(),
    lossAmount: (map['lossAmount'] as num? ?? 0).toDouble(),
    reason: map['reason'] ?? '',
    reportedBy: map['reportedBy'] ?? '',
    date: map['date'] ?? '',
    createdAt: map['createdAt'] ?? DateTime.now().toIso8601String(),
  );
}
