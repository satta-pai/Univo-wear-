import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:google_sign_in/google_sign_in.dart';

enum AppRole { owner, admin, staff, guest }

class AuthUserState {
  final String uid;
  final String name;
  final String email;
  final AppRole role;

  const AuthUserState({
    required this.uid,
    required this.name,
    required this.email,
    required this.role,
  });

  bool get isAdmin => role == AppRole.owner || role == AppRole.admin;
  bool get isGuest => role == AppRole.guest;
}

class AuthService {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _db = FirebaseFirestore.instance;
  final GoogleSignIn _googleSignIn = GoogleSignIn();

  Stream<User?> get authStateChanges => _auth.authStateChanges();

  Future<AuthUserState> resolveUserRole(User? user) async {
    if (user == null) {
      return const AuthUserState(
        uid: 'Not Signed In',
        name: 'Guest Visitor',
        email: 'Not signed in',
        role: AppRole.guest,
      );
    }

    final ownerDoc = await _db.collection('owner').doc(user.uid).get();
    if (ownerDoc.exists) {
      return AuthUserState(
        uid: user.uid,
        name: user.displayName ?? 'Owner',
        email: user.email ?? '',
        role: AppRole.owner,
      );
    }

    final adminDoc = await _db.collection('admin').doc(user.uid).get();
    if (adminDoc.exists) {
      return AuthUserState(
        uid: user.uid,
        name: user.displayName ?? 'Admin',
        email: user.email ?? '',
        role: AppRole.admin,
      );
    }

    final allOwners = await _db.collection('owner').limit(1).get();
    final allAdmins = await _db.collection('admin').limit(1).get();
    if (allOwners.docs.isEmpty && allAdmins.docs.isEmpty) {
      await _db.collection('owner').doc(user.uid).set({
        'uid': user.uid,
        'name': user.displayName ?? 'Owner',
        'email': user.email ?? '',
        'role': 'owner',
        'createdAt': DateTime.now().toIso8601String(),
      });
      return AuthUserState(
        uid: user.uid,
        name: user.displayName ?? 'Owner',
        email: user.email ?? '',
        role: AppRole.owner,
      );
    }

    return AuthUserState(
      uid: user.uid,
      name: user.displayName ?? 'Staff',
      email: user.email ?? '',
      role: AppRole.staff,
    );
  }

  Future<void> signInWithGoogle() async {
    final GoogleSignInAccount? googleUser = await _googleSignIn.signIn();
    if (googleUser == null) return;
    final GoogleSignInAuthentication googleAuth = await googleUser.authentication;
    final OAuthCredential credential = GoogleAuthProvider.credential(
      accessToken: googleAuth.accessToken,
      idToken: googleAuth.idToken,
    );
    await _auth.signInWithCredential(credential);
  }

  Future<void> signInWithEmail(String email, String password) async {
    try {
      await _auth.signInWithEmailAndPassword(email: email, password: password);
    } on FirebaseAuthException catch (e) {
      if (e.code == 'user-not-found' || e.code == 'invalid-credential') {
        await _auth.createUserWithEmailAndPassword(email: email, password: password);
      } else {
        rethrow;
      }
    }
  }

  Future<void> signOut() async {
    await _googleSignIn.signOut();
    await _auth.signOut();
  }
}
