import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/stock_item.dart';
import '../models/sale.dart';
import '../models/missing_item.dart';
import '../models/partner.dart';

class FirestoreService {
  final FirebaseFirestore _db = FirebaseFirestore.instance;

  Stream<List<StockItem>> watchStock() {
    return _db.collection('stock').snapshots().map(
          (snap) => snap.docs.map((d) => StockItem.fromMap(d.data())).toList(),
        );
  }

  Stream<List<Sale>> watchSales() {
    return _db.collection('sales').snapshots().map((snap) {
      final list = snap.docs.map((d) => Sale.fromMap(d.data())).toList();
      list.sort((a, b) => b.createdAt.compareTo(a.createdAt));
      return list;
    });
  }

  Stream<List<MissingItem>> watchMissing() {
    return _db.collection('missing_loss').snapshots().map((snap) {
      final list = snap.docs.map((d) => MissingItem.fromMap(d.data())).toList();
      list.sort((a, b) => b.createdAt.compareTo(a.createdAt));
      return list;
    });
  }

  Stream<List<Partner>> watchPartners() {
    return _db.collection('partners').snapshots().map(
          (snap) => snap.docs.map((d) => Partner.fromMap(d.data())).toList(),
        );
  }

  Future<void> saveStock(StockItem item) async {
    await _db.collection('stock').doc(item.id).set(item.toMap());
  }

  Future<void> deleteStock(String id) async {
    await _db.collection('stock').doc(id).delete();
  }

  Future<void> recordSale(Sale sale, StockItem updatedStock) async {
    final batch = _db.batch();
    batch.set(_db.collection('sales').doc(sale.id), sale.toMap());
    batch.set(_db.collection('stock').doc(updatedStock.id), updatedStock.toMap());
    await batch.commit();
  }

  Future<void> refundSale(Sale sale, StockItem? stockItem) async {
    final batch = _db.batch();
    if (stockItem != null) {
      final newSizes = Map<String, int>.from(stockItem.sizes);
      newSizes[sale.size] = (newSizes[sale.size] ?? 0) + sale.qty;
      final newQty = newSizes.values.fold<int>(0, (a, b) => a + b);
      final restored = StockItem(
        id: stockItem.id,
        name: stockItem.name,
        category: stockItem.category,
        colour: stockItem.colour,
        colourName: stockItem.colourName,
        sizes: newSizes,
        qty: newQty,
        costPrice: stockItem.costPrice,
        sellPrice: stockItem.sellPrice,
        addedBy: stockItem.addedBy,
        date: stockItem.date,
        createdAt: stockItem.createdAt,
      );
      batch.set(_db.collection('stock').doc(restored.id), restored.toMap());
    }
    batch.delete(_db.collection('sales').doc(sale.id));
    await batch.commit();
  }

  Future<void> recordMissing(MissingItem miss, StockItem updatedStock) async {
    final batch = _db.batch();
    batch.set(_db.collection('missing_loss').doc(miss.id), miss.toMap());
    batch.set(_db.collection('stock').doc(updatedStock.id), updatedStock.toMap());
    await batch.commit();
  }

  Future<void> restoreMissing(MissingItem miss, StockItem? stockItem) async {
    final batch = _db.batch();
    if (stockItem != null) {
      final newSizes = Map<String, int>.from(stockItem.sizes);
      newSizes[miss.size] = (newSizes[miss.size] ?? 0) + miss.qty;
      final newQty = newSizes.values.fold<int>(0, (a, b) => a + b);
      final restored = StockItem(
        id: stockItem.id,
        name: stockItem.name,
        category: stockItem.category,
        colour: stockItem.colour,
        colourName: stockItem.colourName,
        sizes: newSizes,
        qty: newQty,
        costPrice: stockItem.costPrice,
        sellPrice: stockItem.sellPrice,
        addedBy: stockItem.addedBy,
        date: stockItem.date,
        createdAt: stockItem.createdAt,
      );
      batch.set(_db.collection('stock').doc(restored.id), restored.toMap());
    }
    batch.delete(_db.collection('missing_loss').doc(miss.id));
    await batch.commit();
  }

  Future<void> savePartner(Partner partner) async {
    await _db.collection('partners').doc(partner.id).set(partner.toMap());
  }

  Future<void> deletePartner(String id) async {
    await _db.collection('partners').doc(id).delete();
  }

  Future<void> clearAllData() async {
    for (final col in ['stock', 'sales', 'missing_loss', 'partners']) {
      final snap = await _db.collection(col).get();
      final batch = _db.batch();
      for (final d in snap.docs) {
        batch.delete(d.reference);
      }
      await batch.commit();
    }
  }
}
