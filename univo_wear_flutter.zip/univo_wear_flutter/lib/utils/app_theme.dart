import 'package:flutter/material.dart';

class AppTheme {
  static const Color gold = Color(0xFFF59E0B);
  static const Color accentGreen = Color(0xFF10B981);
  static const Color darkBg = Color(0xFF07080C);
  static const Color darkCard = Color(0xFF12151F);

  static ThemeData get darkTheme => ThemeData(
    brightness: Brightness.dark,
    scaffoldBackgroundColor: darkBg,
    cardColor: darkCard,
    colorScheme: const ColorScheme.dark(
      primary: gold,
      secondary: accentGreen,
      surface: darkCard,
    ),
    useMaterial3: true,
  );

  static ThemeData get lightTheme => ThemeData(
    brightness: Brightness.light,
    scaffoldBackgroundColor: const Color(0xFFF8FAFC),
    cardColor: Colors.white,
    colorScheme: const ColorScheme.light(
      primary: Color(0xFFB45309),
      secondary: Color(0xFF059669),
      surface: Colors.white,
    ),
    useMaterial3: true,
  );
}
