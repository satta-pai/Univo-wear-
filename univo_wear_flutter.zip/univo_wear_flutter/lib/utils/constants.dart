import 'package:flutter/material.dart';

class ColourSwatchItem {
  final String name;
  final String hex;
  final Color color;
  const ColourSwatchItem({required this.name, required this.hex, required this.color});
}

const List<ColourSwatchItem> kColourSwatches = [
  ColourSwatchItem(name: 'Red', hex: '#ef4444', color: Color(0xFFEF4444)),
  ColourSwatchItem(name: 'Olive', hex: '#84cc16', color: Color(0xFF84CC16)),
  ColourSwatchItem(name: 'Navy', hex: '#1e3a5f', color: Color(0xFF1E3A5F)),
  ColourSwatchItem(name: 'Black', hex: '#1f2937', color: Color(0xFF1F2937)),
  ColourSwatchItem(name: 'White', hex: '#f8fafc', color: Color(0xFFF8FAFC)),
  ColourSwatchItem(name: 'Beige', hex: '#d4a574', color: Color(0xFFD4A574)),
  ColourSwatchItem(name: 'Burgundy', hex: '#7c1f33', color: Color(0xFF7C1F33)),
  ColourSwatchItem(name: 'Grey', hex: '#6b7280', color: Color(0xFF6B7280)),
  ColourSwatchItem(name: 'Cream', hex: '#fef3c7', color: Color(0xFFFEF3C7)),
  ColourSwatchItem(name: 'Teal', hex: '#0d9488', color: Color(0xFF0D9488)),
  ColourSwatchItem(name: 'Royal Blue', hex: '#2563eb', color: Color(0xFF2563EB)),
  ColourSwatchItem(name: 'Pink', hex: '#ec4899', color: Color(0xFFEC4899)),
  ColourSwatchItem(name: 'Maroon', hex: '#7f1d1d', color: Color(0xFF7F1D1D)),
  ColourSwatchItem(name: 'Sky Blue', hex: '#0ea5e9', color: Color(0xFF0EA5E9)),
  ColourSwatchItem(name: 'Lemon', hex: '#eab308', color: Color(0xFFEAB308)),
  ColourSwatchItem(name: 'Sage', hex: '#86efac', color: Color(0xFF86EFAC)),
];

const List<String> kCategories = ['Pants', 'Shirts', 'T-Shirts', 'Kurtis', 'Sarees'];

List<String> sizesForCategory(String category) {
  if (category == 'Pants') return ['28', '30', '32', '34', '36', '38', '40'];
  if (category == 'Sarees') return ['Free Size'];
  return ['S', 'M', 'L', 'XL', 'XXL'];
}
