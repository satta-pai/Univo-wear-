import 'dart:math';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

String makeId(String prefix) {
  final rand = Random();
  const chars = '0123456789abcdefghijklmnopqrstuvwxyz';
  final suffix = List.generate(6, (_) => chars[rand.nextInt(chars.length)]).join();
  return '$prefix-${DateTime.now().millisecondsSinceEpoch}-$suffix';
}

String formatInr(num amount) {
  final fmt = NumberFormat.currency(locale: 'en_IN', symbol: '₹', decimalDigits: 0);
  return fmt.format(amount);
}

Color parseHexColor(String hexString) {
  final clean = hexString.replaceFirst('#', '');
  if (clean.length == 6) {
    return Color(int.parse('FF$clean', radix: 16));
  }
  return const Color(0xFFEAB308);
}

String getLocalDateString() {
  final d = DateTime.now();
  return '${d.year}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';
}
