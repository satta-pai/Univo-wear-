import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../providers/sales_provider.dart';
import '../utils/helpers.dart';

class SalesScreen extends ConsumerWidget {
  const SalesScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final sales = ref.watch(salesStreamProvider).valueOrNull ?? [];
    if (sales.isEmpty) {
      return const Center(child: Text('No sales bills recorded yet.'));
    }
    return ListView.builder(
      padding: const EdgeInsets.all(12),
      itemCount: sales.length,
      itemBuilder: (ctx, i) {
        final s = sales[i];
        return Card(
          child: ListTile(
            title: Text('${s.itemName} [${s.size} x${s.qty}]', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
            subtitle: Text('${s.id} • ${s.date} • By ${s.soldBy}', style: const TextStyle(fontSize: 11)),
            trailing: Text(formatInr(s.totalSellPrice), style: const TextStyle(fontWeight: FontWeight.bold, color: Color(0xFF10B981))),
          ),
        );
      },
    );
  }
}
