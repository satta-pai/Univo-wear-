import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../providers/auth_provider.dart';

class LoginGateScreen extends ConsumerWidget {
  final VoidCallback onContinue;
  const LoginGateScreen({super.key, required this.onContinue});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Scaffold(
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Card(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
            child: Padding(
              padding: const EdgeInsets.all(24.0),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Text('UNIVO WEAR', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold, letterSpacing: 4)),
                  const SizedBox(height: 8),
                  const Text('Sign in with the Google account your shop owner registered.', textAlign: TextAlign.center, style: TextStyle(fontSize: 12)),
                  const SizedBox(height: 20),
                  ElevatedButton.icon(
                    onPressed: () async {
                      await ref.read(authServiceProvider).signInWithGoogle();
                      onContinue();
                    },
                    icon: const Icon(Icons.login),
                    label: const Text('Sign in with Google'),
                  ),
                  const SizedBox(height: 12),
                  OutlinedButton.icon(
                    onPressed: () {
                      ref.read(authStateProvider.notifier).enterGuestMode();
                      onContinue();
                    },
                    icon: const Icon(Icons.visibility_outlined),
                    label: const Text('Guest Mode (Visit & View Only)'),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
