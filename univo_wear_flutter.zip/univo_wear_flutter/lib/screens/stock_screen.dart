import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../providers/stock_provider.dart';
import '../widgets/colour_tag.dart';
import '../modals/add_stock_sheet.dart';
import '../modals/record_sale_sheet.dart';
import '../utils/helpers.dart';

class StockScreen extends ConsumerWidget {
  const StockScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final stockList = ref.watch(stockStreamProvider).valueOrNull ?? [];
    final search = ref.watch(stockSearchQueryProvider).toLowerCase();

    final filtered = stockList.where((item) {
      final matchName = item.name.toLowerCase().contains(search) || item.colourName.toLowerCase().contains(search);
      final matchSize = search.isNotEmpty && item.sizes.entries.any((e) => e.key.toLowerCase().contains(search) && e.value > 0);
      return search.isEmpty || matchName || matchSize;
    }).toList();

    return Scaffold(
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(12),
            child: TextField(
              decoration: const InputDecoration(prefixIcon: Icon(Icons.search), hintText: 'Search dress, colour, size...'),
              onChanged: (v) => ref.read(stockSearchQueryProvider.notifier).state = v,
            ),
          ),
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              itemCount: filtered.length,
              itemBuilder: (ctx, i) {
                final item = filtered[i];
                return Card(
                  margin: const EdgeInsets.only(bottom: 10),
                  child: Padding(
                    padding: const EdgeInsets.all(12),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Expanded(
                              child: Wrap(
                                crossAxisAlignment: WrapCrossAlignment.center,
                                spacing: 6,
                                children: [
                                  Text(item.name, style: const TextStyle(fontWeight: FontWeight.bold)),
                                  if (item.colour.isNotEmpty) ColourTag(hex: item.colour, label: item.colourName),
                                ],
                              ),
                            ),
                            Text(formatInr(item.sellPrice), style: const TextStyle(fontWeight: FontWeight.bold, color: Color(0xFF10B981))),
                          ],
                        ),
                        const SizedBox(height: 8),
                        Wrap(
                          spacing: 6,
                          children: item.sizes.entries.map((e) {
                            return ActionChip(
                              label: Text('${e.key}: ${e.value}'),
                              onPressed: e.value > 0
                                  ? () => showModalBottomSheet(
                                        context: context,
                                        isScrollControlled: true,
                                        builder: (_) => RecordSaleSheet(item: item, initialSize: e.key),
                                      )
                                  : null,
                            );
                          }).toList(),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => showModalBottomSheet(
          context: context,
          isScrollControlled: true,
          builder: (_) => const AddStockSheet(),
        ),
        child: const Icon(Icons.add),
      ),
    );
  }
}
