import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../providers/theme_provider.dart';
import 'home_screen.dart';
import 'stock_screen.dart';
import 'sales_screen.dart';
import 'admin_screen.dart';

class MainShell extends ConsumerStatefulWidget {
  const MainShell({super.key});

  @override
  ConsumerState<MainShell> createState() => _MainShellState();
}

class _MainShellState extends ConsumerState<MainShell> {
  int _tab = 0;

  @override
  Widget build(BuildContext context) {
    const pages = [HomeScreen(), StockScreen(), SalesScreen(), AdminScreen()];
    return Scaffold(
      appBar: AppBar(
        title: const Text('UNIVO WEAR', style: TextStyle(fontWeight: FontWeight.bold, letterSpacing: 2, fontSize: 15)),
        actions: [
          PopupMenuButton<String>(
            onSelected: (v) {
              if (v == 'theme') {
                final cur = ref.read(themeModeProvider);
                ref.read(themeModeProvider.notifier).state = cur == ThemeMode.dark ? ThemeMode.light : ThemeMode.dark;
              }
            },
            itemBuilder: (_) => const [
              PopupMenuItem(value: 'theme', child: Text('Switch Light / Dark Theme')),
            ],
          ),
        ],
      ),
      body: pages[_tab],
      bottomNavigationBar: NavigationBar(
        selectedIndex: _tab,
        onDestinationSelected: (i) => setState(() => _tab = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.checkroom_outlined), label: 'Stock'),
          NavigationDestination(icon: Icon(Icons.receipt_long_outlined), label: 'Bills'),
          NavigationDestination(icon: Icon(Icons.admin_panel_settings_outlined), label: 'Owner'),
        ],
      ),
    );
  }
}
