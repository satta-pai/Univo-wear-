import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../providers/auth_provider.dart';
import '../providers/stock_provider.dart';
import '../providers/sales_provider.dart';
import '../providers/missing_provider.dart';
import '../widgets/financial_chart.dart';
import '../utils/helpers.dart';

class HomeScreen extends ConsumerWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final authUser = ref.watch(authStateProvider);
    final stockList = ref.watch(stockStreamProvider).valueOrNull ?? [];
    final salesList = ref.watch(salesStreamProvider).valueOrNull ?? [];
    final missingList = ref.watch(missingStreamProvider).valueOrNull ?? [];

    final totalSales = salesList.fold<double>(0, (a, b) => a + b.totalSellPrice);
    final totalProfit = salesList.fold<double>(0, (a, b) => a + b.profit);
    final totalCost = salesList.fold<double>(0, (a, b) => a + (b.costPrice * b.qty));
    final totalDisc = salesList.fold<double>(0, (a, b) => a + b.discount);
    final totalLoss = missingList.fold<double>(0, (a, b) => a + b.lossAmount);
    final totalPcs = stockList.fold<int>(0, (a, b) => a + b.qty);

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text('Total Sales', style: TextStyle(fontSize: 11)),
                        Text(formatInr(totalSales), style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Color(0xFF10B981))),
                      ],
                    ),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        const Text('Net Profit', style: TextStyle(fontSize: 11)),
                        Text(authUser.isAdmin ? formatInr(totalProfit) : '••••••', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Color(0xFFF59E0B))),
                      ],
                    ),
                  ],
                ),
                const Divider(height: 24),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    Text('In-Stock: $totalPcs Pcs', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 12)),
                    Text('Loss: ${formatInr(totalLoss)}', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 12, color: Colors.redAccent)),
                  ],
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 16),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: FinancialChart(
              sales: totalSales,
              cost: totalCost,
              profit: totalProfit,
              discount: totalDisc,
              loss: totalLoss,
              isAdmin: authUser.isAdmin,
            ),
          ),
        ),
      ],
    );
  }
}
