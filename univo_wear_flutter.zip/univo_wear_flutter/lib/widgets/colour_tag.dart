import 'package:flutter/material.dart';
import '../utils/helpers.dart';

class ColourTag extends StatelessWidget {
  final String hex;
  final String label;

  const ColourTag({super.key, required this.hex, required this.label});

  @override
  Widget build(BuildContext context) {
    final color = parseHexColor(hex);
    final isLight = color.computeLuminance() > 0.78;
    final textColor = isLight ? const Color(0xFF0F172A) : color;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
      decoration: BoxDecoration(
        color: isLight ? const Color(0xFFF1F5F9) : color.withOpacity(0.15),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: isLight ? const Color(0xFF64748B) : color.withOpacity(0.4)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 8,
            height: 8,
            decoration: BoxDecoration(color: color, shape: BoxShape.circle),
          ),
          const SizedBox(width: 4),
          Text(
            label.isNotEmpty ? label : hex,
            style: TextStyle(fontSize: 9, fontWeight: FontWeight.bold, color: textColor),
          ),
        ],
      ),
    );
  }
}
