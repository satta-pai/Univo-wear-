import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';

class FinancialChart extends StatelessWidget {
  final double sales;
  final double cost;
  final double profit;
  final double discount;
  final double loss;
  final bool isAdmin;

  const FinancialChart({
    super.key,
    required this.sales,
    required this.cost,
    required this.profit,
    required this.discount,
    required this.loss,
    required this.isAdmin,
  });

  @override
  Widget build(BuildContext context) {
    final isLight = Theme.of(context).brightness == Brightness.light;
    final tickColor = isLight ? const Color(0xFF334155) : const Color(0xFF64748B);
    final values = [
      sales,
      isAdmin ? cost : 0.0,
      isAdmin ? profit : 0.0,
      discount,
      loss,
    ];
    final colors = [
      const Color(0xFF10B981),
      const Color(0xFF6366F1),
      const Color(0xFFF59E0B),
      const Color(0xFF38BDF8),
      const Color(0xFFF43F5E),
    ];
    final labels = ['Sales', 'Cost', 'Profit', 'Less', 'Loss'];

    return SizedBox(
      height: 180,
      child: BarChart(
        BarChartData(
          borderData: FlBorderData(show: false),
          titlesData: FlTitlesData(
            topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
            rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
            bottomTitles: AxisTitles(
              sideTitles: SideTitles(
                showTitles: true,
                getTitlesWidget: (val, meta) {
                  final idx = val.toInt();
                  if (idx < 0 || idx >= labels.length) return const SizedBox.shrink();
                  return Text(labels[idx], style: TextStyle(color: tickColor, fontSize: 10));
                },
              ),
            ),
          ),
          barGroups: List.generate(values.length, (i) {
            return BarChartGroupData(
              x: i,
              barRods: [
                BarChartRodData(
                  toY: values[i],
                  color: colors[i],
                  width: 18,
                  borderRadius: BorderRadius.circular(6),
                ),
              ],
            );
          }),
        ),
      ),
    );
  }
}
