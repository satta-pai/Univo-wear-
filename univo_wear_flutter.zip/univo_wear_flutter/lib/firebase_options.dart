import 'package:firebase_core/firebase_core.dart' show FirebaseOptions;
import 'package:flutter/foundation.dart' show defaultTargetPlatform, kIsWeb, TargetPlatform;

class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    if (kIsWeb) return web;
    switch (defaultTargetPlatform) {
      case TargetPlatform.android:
        return android;
      case TargetPlatform.iOS:
        return ios;
      default:
        return web;
    }
  }

  static const FirebaseOptions web = FirebaseOptions(
    apiKey: 'AIzaSyBWjaEr3EH16gDMbvDoC0SrMk0_zbX0FUY',
    appId: '1:63891231828:web:cbde073751d588aa1e89c1',
    messagingSenderId: '63891231828',
    projectId: 'univo-wear',
    authDomain: 'univo-wear.firebaseapp.com',
    storageBucket: 'univo-wear.firebasestorage.app',
    measurementId: 'G-JKM20L7KFM',
  );

  static const FirebaseOptions android = FirebaseOptions(
    apiKey: 'AIzaSyBWjaEr3EH16gDMbvDoC0SrMk0_zbX0FUY',
    appId: '1:63891231828:android:cbde073751d588aa1e89c1',
    messagingSenderId: '63891231828',
    projectId: 'univo-wear',
    authDomain: 'univo-wear.firebaseapp.com',
    storageBucket: 'univo-wear.firebasestorage.app',
  );

  static const FirebaseOptions ios = FirebaseOptions(
    apiKey: 'AIzaSyBWjaEr3EH16gDMbvDoC0SrMk0_zbX0FUY',
    appId: '1:63891231828:ios:cbde073751d588aa1e89c1',
    messagingSenderId: '63891231828',
    projectId: 'univo-wear',
    storageBucket: 'univo-wear.firebasestorage.app',
    iosBundleId: 'com.univowear.pos',
  );
}
