import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/missing_item.dart';
import 'auth_provider.dart';

final missingStreamProvider = StreamProvider<List<MissingItem>>((ref) {
  return ref.watch(firestoreServiceProvider).watchMissing();
});
