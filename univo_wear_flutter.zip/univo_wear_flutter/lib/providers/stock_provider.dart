import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/stock_item.dart';
import 'auth_provider.dart';

final stockStreamProvider = StreamProvider<List<StockItem>>((ref) {
  return ref.watch(firestoreServiceProvider).watchStock();
});

final selectedCategoryFilterProvider = StateProvider<String>((ref) => 'ALL');
final selectedColourFilterProvider = StateProvider<String>((ref) => 'ALL');
final stockSearchQueryProvider = StateProvider<String>((ref) => '');
