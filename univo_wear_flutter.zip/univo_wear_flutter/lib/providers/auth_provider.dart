import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../services/auth_service.dart';
import '../services/firestore_service.dart';
import '../models/partner.dart';

final authServiceProvider = Provider<AuthService>((ref) => AuthService());
final firestoreServiceProvider = Provider<FirestoreService>((ref) => FirestoreService());

final authStateProvider = StateNotifierProvider<AuthController, AuthUserState>((ref) {
  return AuthController(ref.watch(authServiceProvider));
});

class AuthController extends StateNotifier<AuthUserState> {
  final AuthService _authService;

  AuthController(this._authService)
      : super(const AuthUserState(
          uid: '—',
          name: 'Checking...',
          email: '—',
          role: AppRole.guest,
        )) {
    _authService.authStateChanges.listen((user) async {
      state = await _authService.resolveUserRole(user);
    });
  }

  void enterGuestMode() {
    state = const AuthUserState(
      uid: 'Guest',
      name: 'Guest Visitor',
      email: 'Not signed in',
      role: AppRole.guest,
    );
  }
}

final partnersProvider = StreamProvider<List<Partner>>((ref) {
  return ref.watch(firestoreServiceProvider).watchPartners();
});

final maxStaffDiscountProvider = StateProvider<double>((ref) => 200.0);
