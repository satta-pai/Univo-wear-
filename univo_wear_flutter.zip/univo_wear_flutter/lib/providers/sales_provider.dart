import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/sale.dart';
import 'auth_provider.dart';

final salesStreamProvider = StreamProvider<List<Sale>>((ref) {
  return ref.watch(firestoreServiceProvider).watchSales();
});
