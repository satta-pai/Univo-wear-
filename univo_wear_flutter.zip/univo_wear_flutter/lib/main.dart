import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:firebase_core/firebase_core.dart';
import 'firebase_options.dart';
import 'providers/theme_provider.dart';
import 'screens/login_gate_screen.dart';
import 'screens/main_shell.dart';
import 'utils/app_theme.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
  runApp(const ProviderScope(child: UnivoWearApp()));
}

class UnivoWearApp extends ConsumerStatefulWidget {
  const UnivoWearApp({super.key});

  @override
  ConsumerState<UnivoWearApp> createState() => _UnivoWearAppState();
}

class _UnivoWearAppState extends ConsumerState<UnivoWearApp> {
  bool _entered = false;

  @override
  Widget build(BuildContext context) {
    final themeMode = ref.watch(themeModeProvider);
    return MaterialApp(
      title: 'UNIVO WEAR POS',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.lightTheme,
      darkTheme: AppTheme.darkTheme,
      themeMode: themeMode,
      home: _entered
          ? const MainShell()
          : LoginGateScreen(onContinue: () => setState(() => _entered = true)),
    );
  }
}
