import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:url_launcher/url_launcher.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Color(0xFF07080C),
    statusBarIconBrightness: Brightness.light,
    systemNavigationBarColor: Color(0xFF07080C),
    systemNavigationBarIconBrightness: Brightness.light,
  ));
  runApp(const UnivoWearHybridApp());
}

class UnivoWearHybridApp extends StatelessWidget {
  const UnivoWearHybridApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'UNIVO WEAR',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: const Color(0xFF07080C),
      ),
      home: const UnivoWearWebViewScreen(),
    );
  }
}

class UnivoWearWebViewScreen extends StatefulWidget {
  const UnivoWearWebViewScreen({super.key});

  @override
  State<UnivoWearWebViewScreen> createState() => _UnivoWearWebViewScreenState();
}

class _UnivoWearWebViewScreenState extends State<UnivoWearWebViewScreen> {
  HttpServer? _localServer;
  WebViewController? _controller;
  bool _isReady = false;
  final GoogleSignIn _googleSignIn = GoogleSignIn(scopes: ['email', 'profile']);

  @override
  void initState() {
    super.initState();
    _startLocalPosEngine();
  }

  Future<void> _startLocalPosEngine() async {
    final String htmlContent = await rootBundle.loadString('assets/www/index.html');
    final List<int> htmlBytes = utf8.encode(htmlContent);

    // Fixed port 8765 so localStorage and Firebase Auth session tokens persist permanently across app restarts!
    int port = 8765;
    try {
      _localServer = await HttpServer.bind(InternetAddress.loopbackIPv4, port, shared: true);
    } catch (_) {
      try {
        port = 8766;
        _localServer = await HttpServer.bind(InternetAddress.loopbackIPv4, port, shared: true);
      } catch (_) {
        _localServer = await HttpServer.bind(InternetAddress.loopbackIPv4, 0, shared: true);
        port = _localServer!.port;
      }
    }

    _localServer!.listen((HttpRequest request) async {
      request.response.headers.set('Content-Type', 'text/html; charset=utf-8');
      request.response.headers.set('Access-Control-Allow-Origin', '*');
      request.response.headers.set('Cache-Control', 'no-store');
      request.response.add(htmlBytes);
      await request.response.close();
    });

    final controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(const Color(0xFF07080C))
      ..addJavaScriptChannel(
        'UnivoNativeAuth',
        onMessageReceived: (JavaScriptMessage message) async {
          final msg = message.message;
          if (msg == 'google_login') {
            await _handleNativeGoogleLogin();
          } else if (msg.startsWith('open_url:')) {
            final urlStr = msg.substring('open_url:'.length);
            final uri = Uri.tryParse(urlStr);
            if (uri != null) {
              await launchUrl(uri, mode: LaunchMode.externalApplication);
            }
          }
        },
      )
      ..setNavigationDelegate(
        NavigationDelegate(
          onNavigationRequest: (NavigationRequest request) async {
            final url = request.url;
            if (url.startsWith('https://wa.me/') ||
                url.startsWith('whatsapp://') ||
                url.startsWith('tel:') ||
                url.startsWith('mailto:')) {
              final uri = Uri.tryParse(url);
              if (uri != null) {
                await launchUrl(uri, mode: LaunchMode.externalApplication);
              }
              return NavigationDecision.prevent;
            }
            return NavigationDecision.navigate;
          },
        ),
      )
      ..loadRequest(Uri.parse('http://localhost:$port/'));

    if (mounted) {
      setState(() {
        _controller = controller;
        _isReady = true;
      });
    }
  }

  Future<void> _handleNativeGoogleLogin() async {
    try {
      await _googleSignIn.signOut();
      final GoogleSignInAccount? account = await _googleSignIn.signIn();
      if (account == null) return;
      final GoogleSignInAuthentication auth = await account.authentication;
      final idToken = jsonEncode(auth.idToken ?? '');
      final accessToken = jsonEncode(auth.accessToken ?? '');
      await _controller?.runJavaScript(
        'if (window.onNativeGoogleAuthSuccess) window.onNativeGoogleAuthSuccess($idToken, $accessToken);',
      );
    } catch (e) {
      final errStr = jsonEncode(
        'Google Sign-In-க்கு உங்கள் APK-ன் SHA-1 கோடை Firebase Console -> Project Settings -> Android App (com.univowear.pos)-ல் சேர்க்கவும். அதுவரை கீழே உள்ள Cloud Email & Password மூலம் உடனே லாகின் செய்யலாம்! ($e)',
      );
      await _controller?.runJavaScript(
        'if (window.onNativeGoogleAuthError) window.onNativeGoogleAuthError($errStr);',
      );
    }
  }

  @override
  void dispose() {
    _localServer?.close(force: true);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      onPopInvoked: (didPop) async {
        if (didPop) return;
        if (_controller != null && await _controller!.canGoBack()) {
          await _controller!.goBack();
        }
      },
      child: Scaffold(
        backgroundColor: const Color(0xFF07080C),
        body: SafeArea(
          child: _isReady && _controller != null
              ? WebViewWidget(controller: _controller!)
              : const Center(
                  child: CircularProgressIndicator(color: Color(0xFFF59E0B)),
                ),
        ),
      ),
    );
  }
}
