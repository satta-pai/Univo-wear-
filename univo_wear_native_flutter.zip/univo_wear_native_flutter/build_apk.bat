@echo off
echo ====================================================
echo   UNIVO WEAR POS v16.0 - 1-Click Android APK Builder
echo ====================================================
echo.
flutter create --org com.univowear.pos --project-name univo_wear .
flutter pub get
flutter build apk --release --no-tree-shake-icons
echo.
echo DONE! Your APK is ready at:
echo build\app\outputs\flutter-apk\app-release.apk
pause
