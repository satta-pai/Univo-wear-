class StockItem {
  final String id;
  final String name;
  final String category;
  final String colour;
  final String colourName;
  final String location;
  final String hsnCode;
  final Map<String, int> sizes;
  final int qty;
  final double costPrice;
  final double sellPrice;
  final String addedBy;
  final String date;
  final String createdAt;

  StockItem({
    required this.id,
    required this.name,
    required this.category,
    required this.colour,
    required this.colourName,
    required this.location,
    required this.hsnCode,
    required this.sizes,
    required this.qty,
    required this.costPrice,
    required this.sellPrice,
    required this.addedBy,
    required this.date,
    required this.createdAt,
  });

  Map<String, dynamic> toMap() => {
        'id': id,
        'name': name,
        'category': category,
        'colour': colour,
        'colourName': colourName,
        'location': location,
        'hsnCode': hsnCode,
        'sizes': sizes,
        'qty': qty,
        'costPrice': costPrice,
        'sellPrice': sellPrice,
        'addedBy': addedBy,
        'date': date,
        'createdAt': createdAt,
      };

  factory StockItem.fromMap(Map<String, dynamic> m) {
    final raw = m['sizes'] as Map<String, dynamic>?;
    final parsed = raw != null
        ? raw.map((k, v) => MapEntry(k, (v as num? ?? 0).toInt()))
        : <String, int>{'Free Size': (m['qty'] as num? ?? 0).toInt()};
    final total = parsed.values.fold<int>(0, (a, b) => a + (b > 0 ? b : 0));
    return StockItem(
      id: (m['id'] ?? '').toString(),
      name: (m['name'] ?? '').toString(),
      category: (m['category'] ?? 'Shirts').toString(),
      colour: (m['colour'] ?? '#eab308').toString(),
      colourName: (m['colourName'] ?? '').toString(),
      location: (m['location'] ?? 'Main Shop').toString(),
      hsnCode: (m['hsnCode'] ?? '6203').toString(),
      sizes: parsed,
      qty: total,
      costPrice: (m['costPrice'] as num? ?? 0).toDouble(),
      sellPrice: (m['sellPrice'] as num? ?? 0).toDouble(),
      addedBy: (m['addedBy'] ?? 'Owner').toString(),
      date: (m['date'] ?? '').toString(),
      createdAt: (m['createdAt'] ?? DateTime.now().toIso8601String()).toString(),
    );
  }
}

class CartLine {
  final String stockId;
  final String itemName;
  final String hsnCode;
  final String size;
  final int qty;
  final double unitMrp;
  final double unitSellPrice;
  final double costPrice;

  CartLine({
    required this.stockId,
    required this.itemName,
    required this.hsnCode,
    required this.size,
    required this.qty,
    required this.unitMrp,
    required this.unitSellPrice,
    required this.costPrice,
  });

  double get totalSellPrice => unitSellPrice * qty;
  double get mrpTotal => unitMrp * qty;

  Map<String, dynamic> toMap() => {
        'stockId': stockId,
        'itemName': itemName,
        'hsnCode': hsnCode,
        'size': size,
        'qty': qty,
        'unitMrp': unitMrp,
        'unitSellPrice': unitSellPrice,
        'costPrice': costPrice,
        'totalSellPrice': totalSellPrice,
        'mrpTotal': mrpTotal,
      };

  factory CartLine.fromMap(Map<String, dynamic> m) => CartLine(
        stockId: (m['stockId'] ?? '').toString(),
        itemName: (m['itemName'] ?? '').toString(),
        hsnCode: (m['hsnCode'] ?? '6203').toString(),
        size: (m['size'] ?? 'Free Size').toString(),
        qty: (m['qty'] as num? ?? 1).toInt(),
        unitMrp: (m['unitMrp'] as num? ?? 0).toDouble(),
        unitSellPrice: (m['unitSellPrice'] as num? ?? 0).toDouble(),
        costPrice: (m['costPrice'] as num? ?? 0).toDouble(),
      );
}

class SaleRecord {
  final String id;
  final String stockId;
  final String itemName;
  final List<CartLine> cartItems;
  final String size;
  final int qty;
  final double mrpTotal;
  final double discount;
  final double unitSellPrice;
  final double taxableValue;
  final int gstRate;
  final double gstTotal;
  final double totalSellPrice;
  final double costPrice;
  final double profit;
  final String payment;
  final String soldBy;
  final String customerName;
  final String customerPhone;
  final String date;
  final String time;
  final String createdAt;

  SaleRecord({
    required this.id,
    required this.stockId,
    required this.itemName,
    required this.cartItems,
    required this.size,
    required this.qty,
    required this.mrpTotal,
    required this.discount,
    required this.unitSellPrice,
    required this.taxableValue,
    required this.gstRate,
    required this.gstTotal,
    required this.totalSellPrice,
    required this.costPrice,
    required this.profit,
    required this.payment,
    required this.soldBy,
    required this.customerName,
    required this.customerPhone,
    required this.date,
    required this.time,
    required this.createdAt,
  });

  Map<String, dynamic> toMap() => {
        'id': id,
        'stockId': stockId,
        'itemName': itemName,
        'cartItems': cartItems.map((e) => e.toMap()).toList(),
        'size': size,
        'qty': qty,
        'mrpTotal': mrpTotal,
        'discount': discount,
        'unitSellPrice': unitSellPrice,
        'taxableValue': taxableValue,
        'gstRate': gstRate,
        'gstTotal': gstTotal,
        'totalSellPrice': totalSellPrice,
        'costPrice': costPrice,
        'profit': profit,
        'payment': payment,
        'soldBy': soldBy,
        'customerName': customerName,
        'customerPhone': customerPhone,
        'date': date,
        'time': time,
        'createdAt': createdAt,
      };

  factory SaleRecord.fromMap(Map<String, dynamic> m) {
    final rawCart = m['cartItems'] as List<dynamic>? ?? [];
    return SaleRecord(
      id: (m['id'] ?? '').toString(),
      stockId: (m['stockId'] ?? '').toString(),
      itemName: (m['itemName'] ?? '').toString(),
      cartItems: rawCart.map((e) => CartLine.fromMap(Map<String, dynamic>.from(e as Map))).toList(),
      size: (m['size'] ?? 'Free Size').toString(),
      qty: (m['qty'] as num? ?? 1).toInt(),
      mrpTotal: (m['mrpTotal'] as num? ?? 0).toDouble(),
      discount: (m['discount'] as num? ?? 0).toDouble(),
      unitSellPrice: (m['unitSellPrice'] as num? ?? 0).toDouble(),
      taxableValue: (m['taxableValue'] as num? ?? m['totalSellPrice'] as num? ?? 0).toDouble(),
      gstRate: (m['gstRate'] as num? ?? 0).toInt(),
      gstTotal: (m['gstTotal'] as num? ?? 0).toDouble(),
      totalSellPrice: (m['totalSellPrice'] as num? ?? 0).toDouble(),
      costPrice: (m['costPrice'] as num? ?? 0).toDouble(),
      profit: (m['profit'] as num? ?? 0).toDouble(),
      payment: (m['payment'] ?? 'Cash').toString(),
      soldBy: (m['soldBy'] ?? 'Staff').toString(),
      customerName: (m['customerName'] ?? '').toString(),
      customerPhone: (m['customerPhone'] ?? '').toString(),
      date: (m['date'] ?? '').toString(),
      time: (m['time'] ?? '').toString(),
      createdAt: (m['createdAt'] ?? DateTime.now().toIso8601String()).toString(),
    );
  }
}

class MissingRecord {
  final String id;
  final String stockId;
  final String itemName;
  final String size;
  final int qty;
  final double lossAmount;
  final String reason;
  final String reportedBy;
  final String date;
  final String createdAt;

  MissingRecord({
    required this.id,
    required this.stockId,
    required this.itemName,
    required this.size,
    required this.qty,
    required this.lossAmount,
    required this.reason,
    required this.reportedBy,
    required this.date,
    required this.createdAt,
  });

  Map<String, dynamic> toMap() => {
        'id': id,
        'stockId': stockId,
        'itemName': itemName,
        'size': size,
        'qty': qty,
        'lossAmount': lossAmount,
        'reason': reason,
        'reportedBy': reportedBy,
        'date': date,
        'createdAt': createdAt,
      };

  factory MissingRecord.fromMap(Map<String, dynamic> m) => MissingRecord(
        id: (m['id'] ?? '').toString(),
        stockId: (m['stockId'] ?? '').toString(),
        itemName: (m['itemName'] ?? '').toString(),
        size: (m['size'] ?? '').toString(),
        qty: (m['qty'] as num? ?? 1).toInt(),
        lossAmount: (m['lossAmount'] as num? ?? 0).toDouble(),
        reason: (m['reason'] ?? '').toString(),
        reportedBy: (m['reportedBy'] ?? '').toString(),
        date: (m['date'] ?? '').toString(),
        createdAt: (m['createdAt'] ?? DateTime.now().toIso8601String()).toString(),
      );
}
