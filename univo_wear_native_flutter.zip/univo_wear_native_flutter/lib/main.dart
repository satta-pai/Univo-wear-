import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'core/app_theme.dart';
import 'firebase_options.dart';
import 'screens/home_shell.dart';
import 'screens/login_gate_screen.dart';
import 'services/pos_store.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  try {
    if (Firebase.apps.isEmpty) {
      await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
    }
  } catch (_) {
    try {
      if (Firebase.apps.isEmpty) {
        await Firebase.initializeApp();
      }
    } catch (_) {}
  }
  try {
    FirebaseFirestore.instance.settings = const Settings(persistenceEnabled: true);
  } catch (_) {}
  runApp(const UnivoWearNativeApp());
}

class UnivoWearNativeApp extends StatefulWidget {
  const UnivoWearNativeApp({super.key});

  @override
  State<UnivoWearNativeApp> createState() => _UnivoWearNativeAppState();
}

class _UnivoWearNativeAppState extends State<UnivoWearNativeApp> {
  late final PosStore _store;

  @override
  void initState() {
    super.initState();
    _store = PosStore();
  }

  @override
  void dispose() {
    _store.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _store,
      builder: (_, __) {
        return MaterialApp(
          title: 'UNIVO WEAR',
          debugShowCheckedModeBanner: false,
          theme: AppTheme.light,
          darkTheme: AppTheme.dark,
          themeMode: _store.isDark ? ThemeMode.dark : ThemeMode.light,
          home: _store.enteredApp ? HomeShell(store: _store) : LoginGateScreen(store: _store),
        );
      },
    );
  }
}
