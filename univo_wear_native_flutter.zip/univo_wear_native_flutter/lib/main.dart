import 'dart:ui' show PointerDeviceKind;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'core/app_theme.dart';
import 'firebase_options.dart';
import 'screens/home_shell.dart';
import 'screens/login_gate_screen.dart';
import 'screens/splash_screen.dart';
import 'screens/public_catalog_screen.dart';
import 'services/pos_store.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  PaintingBinding.instance.imageCache.maximumSize = 80;
  PaintingBinding.instance.imageCache.maximumSizeBytes = 40 << 20;
  try {
    if (Firebase.apps.isEmpty) {
      await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
    }
  } catch (_) {
    try {
      if (Firebase.apps.isEmpty) {
        await Firebase.initializeApp();
      }
    } catch (_) {}
  }
  try {
    FirebaseFirestore.instance.settings = const Settings(persistenceEnabled: true);
  } catch (_) {}
  runApp(const UnivoWearNativeApp());
}

class UnivoWearNativeApp extends StatefulWidget {
  const UnivoWearNativeApp({super.key});

  @override
  State<UnivoWearNativeApp> createState() => _UnivoWearNativeAppState();
}

class _UnivoWearNativeAppState extends State<UnivoWearNativeApp> {
  late final PosStore _store;
  bool _showSplash = true;

  @override
  void initState() {
    super.initState();
    _store = PosStore();
  }

  @override
  void dispose() {
    _store.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _store,
      builder: (_, __) {
        return MaterialApp(
          title: 'UNIVO WEAR',
          debugShowCheckedModeBanner: false,
          scrollBehavior: const UnivoScrollBehavior(),
          theme: AppTheme.light,
          darkTheme: AppTheme.dark,
          themeMode: _store.isDark ? ThemeMode.dark : ThemeMode.light,
          home: AnimatedSwitcher(
            duration: const Duration(milliseconds: 420),
            child: _showSplash
                ? LuxurySplashScreen(
                    key: const ValueKey('splash'),
                    isDark: _store.isDark,
                    onFinished: () {
                      if (mounted) setState(() => _showSplash = false);
                    },
                  )
                : (Uri.base.queryParameters['shop'] == 'catalog'
                    ? PublicCatalogScreen(key: const ValueKey('catalog'), store: _store)
                    : (_store.enteredApp
                    ? HomeShell(key: const ValueKey('home'), store: _store)
                    : LoginGateScreen(key: const ValueKey('login'), store: _store))),
          ),
        );
      },
    );
  }
}

class UnivoScrollBehavior extends MaterialScrollBehavior {
  const UnivoScrollBehavior();

  @override
  Set<PointerDeviceKind> get dragDevices => {
        PointerDeviceKind.touch,
        PointerDeviceKind.mouse,
        PointerDeviceKind.trackpad,
        PointerDeviceKind.stylus,
        PointerDeviceKind.unknown,
      };
}
