import 'dart:convert';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:url_launcher/url_launcher.dart';

const String kAppVersionName = '44.0.0';
const int kAppBuildNumber = 47;
const String kGithubOwner = 'satta-pai';
const String kGithubRepo = 'Univo-wear-';

class SwatchItem {
  final String name;
  final String hex;
  final Color color;
  const SwatchItem(this.name, this.hex, this.color);
}

const List<SwatchItem> kColourSwatches = [
  SwatchItem('Black', '#111827', Color(0xFF111827)),
  SwatchItem('Jet Black', '#000000', Color(0xFF000000)),
  SwatchItem('Charcoal', '#374151', Color(0xFF374151)),
  SwatchItem('Dark Grey', '#4b5563', Color(0xFF4B5563)),
  SwatchItem('Grey', '#6b7280', Color(0xFF6B7280)),
  SwatchItem('Ash Grey', '#9ca3af', Color(0xFF9CA3AF)),
  SwatchItem('Silver', '#d1d5db', Color(0xFFD1D5DB)),
  SwatchItem('White', '#ffffff', Color(0xFFFFFFFF)),
  SwatchItem('Off-White', '#f8fafc', Color(0xFFF8FAFC)),
  SwatchItem('Ivory', '#fffff0', Color(0xFFFFFFF0)),
  SwatchItem('Cream', '#fef3c7', Color(0xFFFEF3C7)),
  SwatchItem('Champagne', '#f3e5ab', Color(0xFFF3E5AB)),
  SwatchItem('Beige', '#d4a574', Color(0xFFD4A574)),
  SwatchItem('Sand', '#e2c9a6', Color(0xFFE2C9A6)),
  SwatchItem('Khaki', '#c3b091', Color(0xFFC3B091)),
  SwatchItem('Camel', '#c19a6b', Color(0xFFC19A6B)),
  SwatchItem('Tan', '#a67b5b', Color(0xFFA67B5B)),
  SwatchItem('Coffee', '#6f4e37', Color(0xFF6F4E37)),
  SwatchItem('Brown', '#78350f', Color(0xFF78350F)),
  SwatchItem('Chocolate', '#4a2511', Color(0xFF4A2511)),
  SwatchItem('Navy Blue', '#1e3a5f', Color(0xFF1E3A5F)),
  SwatchItem('Midnight Blue', '#0f172a', Color(0xFF0F172A)),
  SwatchItem('Indigo', '#312e81', Color(0xFF312E81)),
  SwatchItem('Royal Blue', '#2563eb', Color(0xFF2563EB)),
  SwatchItem('Cobalt Blue', '#1d4ed8', Color(0xFF1D4ED8)),
  SwatchItem('Denim Blue', '#3b5998', Color(0xFF3B5998)),
  SwatchItem('Slate Blue', '#475569', Color(0xFF475569)),
  SwatchItem('Sky Blue', '#0ea5e9', Color(0xFF0EA5E9)),
  SwatchItem('Powder Blue', '#93c5fd', Color(0xFF93C5FD)),
  SwatchItem('Aqua', '#22d3ee', Color(0xFF22D3EE)),
  SwatchItem('Turquoise', '#06b6d4', Color(0xFF06B6D4)),
  SwatchItem('Peacock Blue', '#0e7490', Color(0xFF0E7490)),
  SwatchItem('Teal', '#0d9488', Color(0xFF0D9488)),
  SwatchItem('Mint Green', '#a7f3d0', Color(0xFFA7F3D0)),
  SwatchItem('Pistachio', '#bef264', Color(0xFFBEF264)),
  SwatchItem('Sage Green', '#86efac', Color(0xFF86EFAC)),
  SwatchItem('Lime', '#84cc16', Color(0xFF84CC16)),
  SwatchItem('Olive', '#65a30d', Color(0xFF65A30D)),
  SwatchItem('Army Green', '#4b5320', Color(0xFF4B5320)),
  SwatchItem('Moss Green', '#3f6212', Color(0xFF3F6212)),
  SwatchItem('Emerald', '#059669', Color(0xFF059669)),
  SwatchItem('Forest Green', '#14532d', Color(0xFF14532D)),
  SwatchItem('Bottle Green', '#064e3b', Color(0xFF064E3B)),
  SwatchItem('Lemon Yellow', '#fde047', Color(0xFFFDE047)),
  SwatchItem('Yellow', '#eab308', Color(0xFFEAB308)),
  SwatchItem('Turmeric', '#d97706', Color(0xFFD97706)),
  SwatchItem('Mustard', '#ca8a04', Color(0xFFCA8A04)),
  SwatchItem('Gold', '#d4af37', Color(0xFFD4AF37)),
  SwatchItem('Peach', '#fdba74', Color(0xFFFDBA74)),
  SwatchItem('Orange', '#f97316', Color(0xFFF97316)),
  SwatchItem('Rust', '#b45309', Color(0xFFB45309)),
  SwatchItem('Terracotta', '#c2410c', Color(0xFFC2410C)),
  SwatchItem('Brick Red', '#991b1b', Color(0xFF991B1B)),
  SwatchItem('Red', '#ef4444', Color(0xFFEF4444)),
  SwatchItem('Crimson', '#dc2626', Color(0xFFDC2626)),
  SwatchItem('Maroon', '#7f1d1d', Color(0xFF7F1D1D)),
  SwatchItem('Wine', '#722f37', Color(0xFF722F37)),
  SwatchItem('Burgundy', '#7c1f33', Color(0xFF7C1F33)),
  SwatchItem('Coral', '#fb7185', Color(0xFFFB7185)),
  SwatchItem('Dusty Rose', '#be7c89', Color(0xFFBE7C89)),
  SwatchItem('Baby Pink', '#f9a8d4', Color(0xFFF9A8D4)),
  SwatchItem('Rose Pink', '#f472b6', Color(0xFFF472B6)),
  SwatchItem('Hot Pink', '#ec4899', Color(0xFFEC4899)),
  SwatchItem('Magenta', '#d946ef', Color(0xFFD946EF)),
  SwatchItem('Lavender', '#c4b5fd', Color(0xFFC4B5FD)),
  SwatchItem('Lilac', '#d8b4fe', Color(0xFFD8B4FE)),
  SwatchItem('Purple', '#7e22ce', Color(0xFF7E22CE)),
  SwatchItem('Plum', '#581c87', Color(0xFF581C87)),
];

const List<String> kCategories = ['Pants', 'Shirts', 'T-Shirts', 'Kurtis', 'Sarees'];
const List<String> kLocations = ['Main Shop', 'Godown', 'Branch 2'];
const List<String> kPaymentModes = ['Cash', 'UPI / GPay', 'Card', 'Split (Cash+UPI)', 'Credit (Khata)'];

List<String> sizesForCategory(String cat) {
  if (cat == 'Pants') return ['28', '30', '32', '34', '36', '38', '40'];
  if (cat == 'Sarees') return ['Free Size'];
  return ['S', 'M', 'L', 'XL', 'XXL'];
}

String makeId(String prefix) {
  final r = Random();
  const chars = '0123456789abcdefghijklmnopqrstuvwxyz';
  final tail = List.generate(6, (_) => chars[r.nextInt(chars.length)]).join();
  return '$prefix-${DateTime.now().millisecondsSinceEpoch}-$tail';
}

String getLocalDateString() {
  final d = DateTime.now();
  return '${d.year}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';
}

String formatInr(num value) {
  final f = NumberFormat.currency(locale: 'en_IN', symbol: '₹', decimalDigits: 0);
  return f.format(value);
}

Color hexToColor(String hex) {
  final clean = hex.replaceFirst('#', '');
  if (clean.length == 6) {
    final val = int.tryParse('FF$clean', radix: 16);
    if (val != null) return Color(val);
  }
  return const Color(0xFFEAB308);
}

Future<void> openWhatsAppMessage(String message, {String phone = ''}) async {
  final cleanPhone = phone.replaceAll(RegExp(r'\D'), '');
  final target = cleanPhone.length == 10 ? '91$cleanPhone' : cleanPhone;
  final encoded = Uri.encodeComponent(message);
  final uri = Uri.parse(target.isNotEmpty ? 'https://wa.me/$target?text=$encoded' : 'https://wa.me/?text=$encoded');
  await launchUrl(uri, mode: LaunchMode.externalApplication);
}


String decodeHiddenText(String encoded) {
  final raw = base64Decode(encoded);
  return utf8.decode(raw.map((b) => b ^ 73).toList());
}

const String kDevTagEncoded = 'DSw/LCUmOSwtaSswaR8a';
const String kDevMailEncoded = 'Oig9PSh5OSggCS4kKCAlZyomJA==';
const String kDevTelEncoded = 'YnB4aXB5cX54f3h+eXA=';
const String kDevInstaEncoded = 'Pyg6KCc9ITMzFg==';
