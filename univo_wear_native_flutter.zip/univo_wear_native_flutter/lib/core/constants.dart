import 'dart:math';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:url_launcher/url_launcher.dart';

const String kAppVersionName = '37.0.0';
const int kAppBuildNumber = 40;
const String kGithubOwner = 'satta-pai';
const String kGithubRepo = 'Univo-wear-';

class SwatchItem {
  final String name;
  final String hex;
  final Color color;
  const SwatchItem(this.name, this.hex, this.color);
}

const List<SwatchItem> kColourSwatches = [
  SwatchItem('Red', '#ef4444', Color(0xFFEF4444)),
  SwatchItem('Olive', '#84cc16', Color(0xFF84CC16)),
  SwatchItem('Navy', '#1e3a5f', Color(0xFF1E3A5F)),
  SwatchItem('Black', '#1f2937', Color(0xFF1F2937)),
  SwatchItem('White', '#f8fafc', Color(0xFFF8FAFC)),
  SwatchItem('Beige', '#d4a574', Color(0xFFD4A574)),
  SwatchItem('Burgundy', '#7c1f33', Color(0xFF7C1F33)),
  SwatchItem('Grey', '#6b7280', Color(0xFF6B7280)),
  SwatchItem('Cream', '#fef3c7', Color(0xFFFEF3C7)),
  SwatchItem('Teal', '#0d9488', Color(0xFF0D9488)),
  SwatchItem('Royal Blue', '#2563eb', Color(0xFF2563EB)),
  SwatchItem('Pink', '#ec4899', Color(0xFFEC4899)),
  SwatchItem('Maroon', '#7f1d1d', Color(0xFF7F1D1D)),
  SwatchItem('Sky Blue', '#0ea5e9', Color(0xFF0EA5E9)),
  SwatchItem('Lemon', '#eab308', Color(0xFFEAB308)),
  SwatchItem('Sage', '#86efac', Color(0xFF86EFAC)),
];

const List<String> kCategories = ['Pants', 'Shirts', 'T-Shirts', 'Kurtis', 'Sarees'];
const List<String> kLocations = ['Main Shop', 'Godown', 'Branch 2'];
const List<String> kPaymentModes = ['Cash', 'UPI / GPay', 'Card', 'Split (Cash+UPI)', 'Credit (Khata)'];

List<String> sizesForCategory(String cat) {
  if (cat == 'Pants') return ['28', '30', '32', '34', '36', '38', '40'];
  if (cat == 'Sarees') return ['Free Size'];
  return ['S', 'M', 'L', 'XL', 'XXL'];
}

String makeId(String prefix) {
  final r = Random();
  const chars = '0123456789abcdefghijklmnopqrstuvwxyz';
  final tail = List.generate(6, (_) => chars[r.nextInt(chars.length)]).join();
  return '$prefix-${DateTime.now().millisecondsSinceEpoch}-$tail';
}

String getLocalDateString() {
  final d = DateTime.now();
  return '${d.year}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';
}

String formatInr(num value) {
  final f = NumberFormat.currency(locale: 'en_IN', symbol: '₹', decimalDigits: 0);
  return f.format(value);
}

Color hexToColor(String hex) {
  final clean = hex.replaceFirst('#', '');
  if (clean.length == 6) {
    final val = int.tryParse('FF$clean', radix: 16);
    if (val != null) return Color(val);
  }
  return const Color(0xFFEAB308);
}

Future<void> openWhatsAppMessage(String message, {String phone = ''}) async {
  final cleanPhone = phone.replaceAll(RegExp(r'\D'), '');
  final target = cleanPhone.length == 10 ? '91$cleanPhone' : cleanPhone;
  final encoded = Uri.encodeComponent(message);
  final uri = Uri.parse(target.isNotEmpty ? 'https://wa.me/$target?text=$encoded' : 'https://wa.me/?text=$encoded');
  await launchUrl(uri, mode: LaunchMode.externalApplication);
}
