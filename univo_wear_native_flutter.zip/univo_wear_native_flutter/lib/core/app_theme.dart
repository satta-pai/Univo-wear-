import 'package:flutter/material.dart';

class AppTheme {
  static const Color gold = Color(0xFFE5B869);
  static const Color goldLightMode = Color(0xFF9A6B22);
  static const Color green = Color(0xFF34D399);
  static const Color greenLightMode = Color(0xFF059669);
  static const Color rose = Color(0xFFFB7185);
  static const Color roseLightMode = Color(0xFFE11D48);

  static const Color darkBg = Color(0xFF0A0B0E);
  static const Color darkCard = Color(0xFF13151C);
  static const Color darkSurface = Color(0xFF1B1E28);
  static const Color darkBorder = Color(0x14FFFFFF);

  static const Color lightBg = Color(0xFFF6F5F1);
  static const Color lightCard = Color(0xFFFFFFFF);
  static const Color lightSurface = Color(0xFFF0EFEA);
  static const Color lightBorder = Color(0x140F172A);

  static ThemeData get dark => ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: darkBg,
        cardColor: darkCard,
        colorScheme: const ColorScheme.dark(
          primary: gold,
          secondary: green,
          surface: darkCard,
          error: rose,
        ),
        appBarTheme: const AppBarTheme(
          backgroundColor: darkBg,
          foregroundColor: Color(0xFFF8FAFC),
          elevation: 0,
          scrolledUnderElevation: 0,
        ),
        cardTheme: CardThemeData(
          color: darkCard,
          elevation: 0,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(22),
            side: const BorderSide(color: darkBorder, width: 1),
          ),
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: darkSurface,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(16),
            borderSide: const BorderSide(color: darkBorder),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(16),
            borderSide: const BorderSide(color: darkBorder),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(16),
            borderSide: const BorderSide(color: gold, width: 1.2),
          ),
          contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        ),
        useMaterial3: true,
      );

  static ThemeData get light => ThemeData(
        brightness: Brightness.light,
        scaffoldBackgroundColor: lightBg,
        cardColor: lightCard,
        colorScheme: const ColorScheme.light(
          primary: goldLightMode,
          secondary: greenLightMode,
          surface: lightCard,
          error: roseLightMode,
        ),
        appBarTheme: const AppBarTheme(
          backgroundColor: lightBg,
          foregroundColor: Color(0xFF111318),
          elevation: 0,
          scrolledUnderElevation: 0,
        ),
        cardTheme: CardThemeData(
          color: lightCard,
          elevation: 0,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(22),
            side: const BorderSide(color: lightBorder, width: 1),
          ),
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: lightSurface,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(16),
            borderSide: const BorderSide(color: lightBorder),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(16),
            borderSide: const BorderSide(color: lightBorder),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(16),
            borderSide: const BorderSide(color: goldLightMode, width: 1.2),
          ),
          contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        ),
        useMaterial3: true,
      );
}
