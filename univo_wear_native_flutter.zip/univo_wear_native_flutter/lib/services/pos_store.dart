import 'package:flutter/services.dart' show MethodChannel;
import 'dart:io' show Platform;
import 'windows_google_auth.dart';
import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:intl/intl.dart';
import 'dart:async';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:google_sign_in/google_sign_in.dart';
import '../core/constants.dart';
import '../models/pos_models.dart';

enum UserRole { owner, admin, staff, guest }

class PosStore extends ChangeNotifier {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _db = FirebaseFirestore.instance;
  final GoogleSignIn _googleSignIn = GoogleSignIn();

  UserRole role = UserRole.guest;
  String userName = 'Guest Visitor';
  String userEmail = 'Not signed in';
  String userUid = '';
  bool enteredApp = false;
  bool isDark = true;
  bool isTamil = false;

  double maxStaffDiscount = 200;
  double commissionPct = 2;
  double openingCash = 1000;
  double dailyExpense = 0;

  List<StockItem> stock = [];
  List<SaleRecord> sales = [];
  List<MissingRecord> missing = [];
  List<Map<String, dynamic>> partners = [];
  List<Map<String, dynamic>> khata = [];
  List<Map<String, dynamic>> suppliers = [];
  List<Map<String, dynamic>> alterations = [];
  List<Map<String, dynamic>> customers = [];
  List<Map<String, dynamic>> restoreLogs = [];
  bool autoDeleteMonthlyBills = true;
  String lastAutoDeleteMonth = '';
  String lastPdfBackupMonth = '';
  String? lastAutoCleanupNotice;
  bool _cleanupRunning = false;
  Map<String, dynamic> remoteUpdateConfig = {};
  bool hasPendingSync = false;
  String shopName = 'UNIVO WEAR';
  String shopGstin = '';
  String shopWhatsapp = '';
  bool promoEnabled = false;
  String promoTitle = 'FESTIVAL OFFER';
  double promoMinBill = 2000;
  double promoDiscountPct = 10;

  final List<StreamSubscription<dynamic>> _subs = [];
  static const MethodChannel _alertChannel = MethodChannel('com.univowear.pos/updater');

  void _pushAppAlert(String title, String body) {
    if (kIsWeb) return;
    try {
      _alertChannel.invokeMethod('showLocalNotification', {'title': title, 'body': body});
    } catch (_) {}
  }

  bool get isAdmin => role == UserRole.owner || role == UserRole.admin;
  bool get isGuest => role == UserRole.guest;

  String get currentMonthKey {
    final now = DateTime.now();
    return '${now.year.toString().padLeft(4, '0')}-${now.month.toString().padLeft(2, '0')}';
  }

  int get daysUntilMonthlyAutoDelete {
    final now = DateTime.now();
    final lastDay = DateTime(now.year, now.month + 1, 0).day;
    return lastDay - now.day;
  }

  String _saleMonthKey(SaleRecord x) {
    if (x.date.length >= 7) return x.date.substring(0, 7);
    if (x.createdAt.length >= 7) return x.createdAt.substring(0, 7);
    return currentMonthKey;
  }

  List<SaleRecord> get currentMonthBills =>
      sales.where((x) => _saleMonthKey(x) == currentMonthKey).toList();

  List<SaleRecord> get expiredPreviousMonthBills =>
      sales.where((x) => _saleMonthKey(x).compareTo(currentMonthKey) < 0).toList();

  bool get isWithin3DayDeleteWarning =>
      isAdmin &&
      autoDeleteMonthlyBills &&
      daysUntilMonthlyAutoDelete <= 3 &&
      currentMonthBills.isNotEmpty &&
      lastPdfBackupMonth != currentMonthKey;

  String t(String en, String ta) => isTamil ? ta : en;

  PosStore() {
    final current = _auth.currentUser;
    if (current != null) {
      enteredApp = true;
      userUid = current.uid;
      userEmail = current.email ?? '';
      userName = current.displayName ?? (userEmail.isNotEmpty ? userEmail.split('@').first : 'User');
      _resolveRole(current);
    }
    _initListeners();
  }

  void _initListeners() {
    _subs.add(_auth.authStateChanges().listen((user) async {
      if (user != null) {
        await _resolveRole(user);
      } else {
        role = UserRole.guest;
        userName = 'Guest Visitor';
        userEmail = 'Not signed in';
        userUid = '';
        notifyListeners();
      }
    }));

    _subs.add(_db.collection('stock').snapshots().listen((snap) {
      stock = snap.docs.map((d) => StockItem.fromMap(d.data())).toList();
      notifyListeners();
    }));

    _subs.add(_db.collection('sales').snapshots(includeMetadataChanges: true).listen((snap) {
      hasPendingSync = snap.metadata.hasPendingWrites;
      sales = snap.docs.map((d) => SaleRecord.fromMap(d.data())).toList()
        ..sort((a, b) => b.createdAt.compareTo(a.createdAt));
      notifyListeners();
    }));

    _subs.add(_db.collection('missing_loss').snapshots().listen((snap) {
      missing = snap.docs.map((d) => MissingRecord.fromMap(d.data())).toList()
        ..sort((a, b) => b.createdAt.compareTo(a.createdAt));
      notifyListeners();
    }));

    _subs.add(_db.collection('partners').snapshots().listen((snap) {
      partners = snap.docs.map((d) => d.data()).toList();
      notifyListeners();
    }));

    _subs.add(_db.collection('khata').snapshots().listen((snap) {
      khata = snap.docs.map((d) => d.data()).toList();
      notifyListeners();
    }));

    _subs.add(_db.collection('suppliers').snapshots().listen((snap) {
      suppliers = snap.docs.map((d) => d.data()).toList();
      notifyListeners();
    }));

    _subs.add(_db.collection('alterations').snapshots().listen((snap) {
      alterations = snap.docs.map((d) => d.data()).toList();
      notifyListeners();
    }));

    _subs.add(_db.collection('customers').snapshots().listen((snap) {
      customers = snap.docs.map((d) => d.data()).toList();
      notifyListeners();
    }));

    _subs.add(_db.collection('restore_logs').snapshots().listen((snap) {
      restoreLogs = snap.docs.map((d) => d.data()).toList()
        ..sort((a, b) => (b['createdAt'] ?? '').toString().compareTo((a['createdAt'] ?? '').toString()));
      notifyListeners();
    }));

    _subs.add(_db.collection('settings').doc('shop_config').snapshots().listen((doc) {
      if (doc.exists) {
        final d = doc.data() ?? {};
        if (d['maxStaffDiscount'] != null) {
          maxStaffDiscount = (d['maxStaffDiscount'] as num).toDouble();
        }
        if (d['commissionPct'] != null) {
          commissionPct = (d['commissionPct'] as num).toDouble();
        }
        if (d['autoDeleteMonthlyBills'] != null) {
          autoDeleteMonthlyBills = d['autoDeleteMonthlyBills'] == true;
        }
        if (d['lastAutoDeleteMonth'] != null) {
          lastAutoDeleteMonth = d['lastAutoDeleteMonth'].toString();
        }
        if (d['lastPdfBackupMonth'] != null) {
          lastPdfBackupMonth = d['lastPdfBackupMonth'].toString();
        }
        if (d['shopName'] != null) shopName = d['shopName'].toString();
        if (d['shopGstin'] != null) shopGstin = d['shopGstin'].toString();
        if (d['shopWhatsapp'] != null) shopWhatsapp = d['shopWhatsapp'].toString();
        if (d['promoEnabled'] != null) promoEnabled = d['promoEnabled'] == true;
        if (d['promoTitle'] != null) promoTitle = d['promoTitle'].toString();
        if (d['promoMinBill'] != null) promoMinBill = (d['promoMinBill'] as num).toDouble();
        if (d['promoDiscountPct'] != null) promoDiscountPct = (d['promoDiscountPct'] as num).toDouble();
        notifyListeners();
      }
    }));

    _subs.add(_db.collection('settings').doc('app_update').snapshots().listen((doc) {
      if (doc.exists) {
        remoteUpdateConfig = doc.data() ?? {};
        notifyListeners();
      }
    }));
  }

  Future<void> _resolveRole(User user) async {
    UserRole resolved = UserRole.staff;
    try {
      final ownerDoc = await _db.collection('owner').doc(user.uid).get();
      if (ownerDoc.exists) {
        resolved = UserRole.owner;
      } else {
        final adminDoc = await _db.collection('admin').doc(user.uid).get();
        if (adminDoc.exists) {
          resolved = UserRole.admin;
        } else {
          final anyOwners = await _db.collection('owner').limit(1).get();
          if (anyOwners.docs.isEmpty) {
            await _db.collection('owner').doc(user.uid).set({
              'uid': user.uid,
              'name': user.displayName ?? user.email?.split('@').first ?? 'Owner',
              'email': user.email ?? '',
              'role': 'owner',
              'createdAt': DateTime.now().toIso8601String(),
            });
            resolved = UserRole.owner;
          }
        }
      }
    } catch (_) {}

    role = resolved;
    userUid = user.uid;
    userEmail = user.email ?? '';
    userName = user.displayName ?? (userEmail.isNotEmpty ? userEmail.split('@').first : 'User');
    enteredApp = true;
    notifyListeners();
  }

  Future<String?> signInWithGoogle() async {
    try {
      if (kIsWeb) {
        final provider = GoogleAuthProvider();
        provider.setCustomParameters({'prompt': 'select_account'});
        await _auth.signInWithPopup(provider);
        return null;
      }
      if (Platform.isWindows || Platform.isLinux || Platform.isMacOS) {
        final creds = await loadWindowsOAuthCreds();
        if (creds == null) return 'NEED_WIN_OAUTH';
        return await signInWithGoogleWindows(_auth, creds);
      }
      await _googleSignIn.signOut();
      final gUser = await _googleSignIn.signIn();
      if (gUser == null) return null;
      final gAuth = await gUser.authentication;
      final cred = GoogleAuthProvider.credential(
        accessToken: gAuth.accessToken,
        idToken: gAuth.idToken,
      );
      await _auth.signInWithCredential(cred);
      return null;
    } catch (e) {
      return 'Google Sign-In error: Add SHA-1 in Firebase Console or use Cloud Email Login ($e)';
    }
  }

  Future<String?> signInWithEmail(String email, String password) async {
    try {
      await _auth.signInWithEmailAndPassword(email: email.trim(), password: password.trim());
      return null;
    } on FirebaseAuthException catch (e) {
      if (e.code == 'user-not-found' || e.code == 'invalid-credential') {
        try {
          await _auth.createUserWithEmailAndPassword(email: email.trim(), password: password.trim());
          return null;
        } catch (ce) {
          return 'Email sign-in failed: $ce';
        }
      }
      return e.message ?? 'Email sign-in failed';
    } catch (e) {
      return 'Sign-in error: $e';
    }
  }

  void enterGuestMode() {
    role = UserRole.guest;
    userName = 'Guest Visitor';
    userEmail = 'Not signed in';
    enteredApp = true;
    notifyListeners();
  }

  Future<void> signOut() async {
    try {
      if (!kIsWeb && (Platform.isAndroid || Platform.isIOS)) await _googleSignIn.signOut();
    } catch (_) {}
    await _auth.signOut();
    role = UserRole.guest;
    enteredApp = false;
    notifyListeners();
  }

  void toggleTheme() {
    isDark = !isDark;
    notifyListeners();
  }

  void toggleLanguage() {
    isTamil = !isTamil;
    notifyListeners();
  }

  Future<void> saveStock(StockItem item) async {
    await _db.collection('stock').doc(item.id).set(item.toMap());
  }

  Future<void> deleteStock(String id) async {
    await _db.collection('stock').doc(id).delete();
  }

  Future<SaleRecord> completeSale({
    required List<CartLine> lines,
    required String payment,
    required bool gstEnabled,
    required String customerName,
    required String customerPhone,
  }) async {
    final batch = _db.batch();
    int totalQty = 0;
    double taxableTotal = 0;
    double mrpTotal = 0;
    double totalCost = 0;
    final names = <String>[];
    final updatedStocks = <String, StockItem>{};

    for (final line in lines) {
      final current = updatedStocks[line.stockId] ?? stock.firstWhere((s) => s.id == line.stockId);
      final newSizes = Map<String, int>.from(current.sizes);
      final curCnt = newSizes[line.size] ?? 0;
      newSizes[line.size] = (curCnt - line.qty) < 0 ? 0 : (curCnt - line.qty);
      final newQty = newSizes.values.fold<int>(0, (a, b) => a + b);
      updatedStocks[line.stockId] = StockItem(
        id: current.id,
        name: current.name,
        category: current.category,
        colour: current.colour,
        colourName: current.colourName,
        location: current.location,
        hsnCode: current.hsnCode,
        sizes: newSizes,
        qty: newQty,
        costPrice: current.costPrice,
        sellPrice: current.sellPrice,
        addedBy: current.addedBy,
        date: current.date,
        createdAt: current.createdAt,
      );
      totalQty += line.qty;
      taxableTotal += line.totalSellPrice;
      mrpTotal += line.mrpTotal;
      totalCost += line.costPrice * line.qty;
      names.add('${line.itemName} (${line.size}x${line.qty})');
    }

    final avgUnit = totalQty > 0 ? taxableTotal / totalQty : 0.0;
    final gstRate = gstEnabled ? (avgUnit <= 1000 ? 5 : 12) : 0;
    final gstTotal = gstEnabled ? (taxableTotal * gstRate / 100).roundToDouble() : 0.0;
    final grandTotal = taxableTotal + gstTotal;
    final discount = (mrpTotal - taxableTotal) < 0 ? 0.0 : (mrpTotal - taxableTotal);
    final profit = taxableTotal - totalCost;

    final now = DateTime.now();
    final sale = SaleRecord(
      id: makeId('INV'),
      stockId: lines.first.stockId,
      itemName: names.join(' + '),
      cartItems: lines,
      size: lines.length > 1 ? 'MULTI' : lines.first.size,
      qty: totalQty,
      mrpTotal: mrpTotal,
      discount: discount,
      unitSellPrice: avgUnit,
      taxableValue: taxableTotal,
      gstRate: gstRate,
      gstTotal: gstTotal,
      totalSellPrice: grandTotal,
      costPrice: totalQty > 0 ? totalCost / totalQty : 0,
      profit: profit,
      payment: payment,
      soldBy: userName,
      customerName: customerName.trim(),
      customerPhone: customerPhone.trim(),
      date: getLocalDateString(),
      time: DateFormat('hh:mm a').format(now),
      createdAt: now.toIso8601String(),
    );

    await _db.runTransaction((tx) async {
      final liveDocs = <String, Map<String, dynamic>>{};
      for (final stId in updatedStocks.keys) {
        final snap = await tx.get(_db.collection('stock').doc(stId));
        if (!snap.exists) throw Exception('Stock item no longer exists.');
        liveDocs[stId] = Map<String, dynamic>.from(snap.data()!);
      }
      for (final line in lines) {
        final d = liveDocs[line.stockId]!;
        final rawSizes = Map<String, dynamic>.from((d['sizes'] as Map?) ?? {});
        final avail = (rawSizes[line.size] as num? ?? 0).toInt();
        if (avail < line.qty) {
          throw Exception('Only $avail pcs left for ${line.itemName} (${line.size})!');
        }
        rawSizes[line.size] = avail - line.qty;
        d['sizes'] = rawSizes;
      }
      final soldOutNames = <String>[];
      for (final entry in liveDocs.entries) {
        final rawSizes = Map<String, dynamic>.from(entry.value['sizes'] as Map);
        final parsed = rawSizes.map((k, v) => MapEntry(k, (v as num? ?? 0).toInt()));
        final newTotal = parsed.values.fold<int>(0, (a, b) => a + (b > 0 ? b : 0));
        if (newTotal == 0) soldOutNames.add((entry.value['name'] ?? 'Item').toString());
        tx.update(_db.collection('stock').doc(entry.key), {'sizes': parsed, 'qty': newTotal});
      }
      if (soldOutNames.isNotEmpty) {
        _pushAppAlert(
          'UNIVO WEAR • Stock Sold Out!',
          '${soldOutNames.join(", ")} is now 0 pcs — moved to Out of Stock (தீர்ந்து போன ஸ்டாக்).',
        );
      }
      tx.set(_db.collection('sales').doc(sale.id), sale.toMap());
    });

    if (customerPhone.trim().length >= 10) {
      final ph = customerPhone.trim();
      final cid = 'CUST-$ph';
      final existing = customers.where((c) => c['phone'] == ph).toList();
      final prevPts = existing.isNotEmpty ? (existing.first['points'] as num? ?? 0).toInt() : 0;
      final prevSpent = existing.isNotEmpty ? (existing.first['totalSpent'] as num? ?? 0).toDouble() : 0.0;
      batch.set(_db.collection('customers').doc(cid), {
        'id': cid,
        'phone': ph,
        'name': customerName.trim().isNotEmpty ? customerName.trim() : 'VIP Customer',
        'points': prevPts + (grandTotal ~/ 100),
        'totalSpent': prevSpent + grandTotal,
      });
    }

    if (payment == 'Credit (Khata)') {
      final kid = makeId('KHT');
      batch.set(_db.collection('khata').doc(kid), {
        'id': kid,
        'customerName': customerName.trim().isNotEmpty ? customerName.trim() : 'Walk-in Customer',
        'phone': customerPhone.trim(),
        'amount': grandTotal,
        'note': 'Bill ${sale.id}: ${sale.itemName}',
        'status': 'Pending',
        'date': getLocalDateString(),
        'createdAt': now.toIso8601String(),
      });
    }

    await batch.commit();
    return sale;
  }

  Future<void> editSaleDetails({
    required SaleRecord sale,
    required String payment,
    required double discount,
    required String customerName,
    required String customerPhone,
  }) async {
    final mrp = sale.mrpTotal > 0 ? sale.mrpTotal : (sale.totalSellPrice + sale.discount - sale.gstTotal);
    final newTaxable = (mrp - discount) < 0 ? 0.0 : (mrp - discount);
    final newGst = sale.gstRate > 0 ? (newTaxable * sale.gstRate / 100).roundToDouble() : 0.0;
    final newTotal = newTaxable + newGst;
    final newProfit = newTaxable - (sale.costPrice * sale.qty);
    await _db.collection('sales').doc(sale.id).update({
      'payment': payment,
      'discount': discount,
      'taxableValue': newTaxable,
      'gstTotal': newGst,
      'totalSellPrice': newTotal,
      'profit': newProfit,
      'customerName': customerName.trim(),
      'customerPhone': customerPhone.trim(),
      'editedAt': DateTime.now().toIso8601String(),
      'editedBy': userName,
    });
  }

  Future<void> refundSale(SaleRecord sale, {String reason = 'Customer Return'}) async {
    final batch = _db.batch();
    final restoreLines = sale.cartItems.isNotEmpty
        ? sale.cartItems
        : [
            CartLine(
              stockId: sale.stockId,
              itemName: sale.itemName,
              hsnCode: '6203',
              size: sale.size,
              qty: sale.qty,
              unitMrp: sale.unitSellPrice,
              unitSellPrice: sale.unitSellPrice,
              costPrice: sale.costPrice,
            ),
          ];

    final touched = <String, StockItem>{};
    for (final line in restoreLines) {
      final matches = stock.where((s) => s.id == line.stockId).toList();
      if (matches.isEmpty) continue;
      final base = touched[line.stockId] ?? matches.first;
      final newSizes = Map<String, int>.from(base.sizes);
      newSizes[line.size] = (newSizes[line.size] ?? 0) + line.qty;
      final newQty = newSizes.values.fold<int>(0, (a, b) => a + b);
      touched[line.stockId] = StockItem(
        id: base.id,
        name: base.name,
        category: base.category,
        colour: base.colour,
        colourName: base.colourName,
        location: base.location,
        hsnCode: base.hsnCode,
        sizes: newSizes,
        qty: newQty,
        costPrice: base.costPrice,
        sellPrice: base.sellPrice,
        addedBy: base.addedBy,
        date: base.date,
        createdAt: base.createdAt,
        photoBase64: base.photoBase64,
      );
    }

    for (final st in touched.values) {
      batch.set(_db.collection('stock').doc(st.id), st.toMap());
    }
    batch.delete(_db.collection('sales').doc(sale.id));
    final rId = makeId('RST');
    final now = DateTime.now();
    batch.set(_db.collection('restore_logs').doc(rId), {
      'id': rId,
      'type': 'Bill Refund Restore',
      'itemName': sale.itemName,
      'size': sale.size,
      'qty': sale.qty,
      'reason': reason.trim().isEmpty ? 'Bill Cancelled' : reason.trim(),
      'restoredBy': userName,
      'date': getLocalDateString(),
      'time': DateFormat('hh:mm a').format(now),
      'createdAt': now.toIso8601String(),
    });
    await batch.commit();
    _pushAppAlert('UNIVO WEAR • Bill Restored', '${sale.id} (${sale.itemName}) restored to stock. Reason: $reason');
  }

  Future<void> saveShopConfig({required double maxDisc, required double commPct}) async {
    maxStaffDiscount = maxDisc;
    commissionPct = commPct;
    await _db.collection('settings').doc('shop_config').set({
      'maxStaffDiscount': maxDisc,
      'commissionPct': commPct,
      'updatedAt': DateTime.now().toIso8601String(),
    }, SetOptions(merge: true));
    notifyListeners();
  }

  Future<void> saveMonthlyAutoDeleteConfig({bool? enabled, String? lastBackupMonth, String? lastDeletedMonth}) async {
    if (enabled != null) autoDeleteMonthlyBills = enabled;
    if (lastBackupMonth != null) lastPdfBackupMonth = lastBackupMonth;
    if (lastDeletedMonth != null) lastAutoDeleteMonth = lastDeletedMonth;
    await _db.collection('settings').doc('shop_config').set({
      'autoDeleteMonthlyBills': autoDeleteMonthlyBills,
      'lastPdfBackupMonth': lastPdfBackupMonth,
      'lastAutoDeleteMonth': lastAutoDeleteMonth,
      'updatedAt': DateTime.now().toIso8601String(),
    }, SetOptions(merge: true));
    notifyListeners();
  }

  Future<int> runMonthlyAutoCleanupIfNeeded(Future<String?> Function(List<SaleRecord> bills, String label) backupPdfSaver) async {
    if (!isAdmin || !autoDeleteMonthlyBills || _cleanupRunning) return 0;
    final expired = expiredPreviousMonthBills;
    if (expired.isEmpty) return 0;
    _cleanupRunning = true;
    try {
      final prevMonth = _saleMonthKey(expired.first);
      final savedName = await backupPdfSaver(expired, 'AutoBackup_$prevMonth');
      final totalCleared = expired.fold<double>(0, (a, b) => a + b.totalSellPrice);
      // Batch delete in chunks of 400 (Firestore batch limit = 500)
      for (int i = 0; i < expired.length; i += 400) {
        final chunk = expired.sublist(i, (i + 400) > expired.length ? expired.length : (i + 400));
        final batch = _db.batch();
        for (final sale in chunk) {
          batch.delete(_db.collection('sales').doc(sale.id));
        }
        await batch.commit();
      }
      final logId = 'AUTODEL-${DateTime.now().millisecondsSinceEpoch}';
      await _db.collection('restore_logs').doc(logId).set({
        'id': logId,
        'type': 'AUTO_DELETE',
        'itemName': 'Monthly Cleanup ($prevMonth • ${expired.length} bills)',
        'amount': totalCleared,
        'reason': savedName != null
            ? 'Auto-deleted after monthly cycle (Backup PDF saved: $savedName)'
            : 'Auto-deleted after monthly cycle',
        'restoredBy': userName,
        'date': getLocalDateString(),
        'createdAt': DateTime.now().toIso8601String(),
      });
      await saveMonthlyAutoDeleteConfig(lastDeletedMonth: currentMonthKey);
      lastAutoCleanupNotice = 'Auto-deleted ${expired.length} old bills ($prevMonth). Backup PDF saved!';
      notifyListeners();
      return expired.length;
    } catch (_) {
      return 0;
    } finally {
      _cleanupRunning = false;
    }
  }

  Future<void> saveRemoteUpdateConfig({
    required String versionName,
    required int buildNumber,
    required String downloadUrl,
    required String releaseNotes,
    required bool forceUpdate,
  }) async {
    remoteUpdateConfig = {
      'versionName': versionName,
      'buildNumber': buildNumber,
      'downloadUrl': downloadUrl,
      'releaseNotes': releaseNotes,
      'forceUpdate': forceUpdate,
      'updatedAt': DateTime.now().toIso8601String(),
    };
    await _db.collection('settings').doc('app_update').set(remoteUpdateConfig, SetOptions(merge: true));
    notifyListeners();
  }

  Future<void> saveEnterpriseSettings({
    required String shopName,
    required String shopGstin,
    required String shopWhatsapp,
    required bool promoEnabled,
    required String promoTitle,
    required double promoMinBill,
    required double promoDiscountPct,
  }) async {
    this.shopName = shopName;
    this.shopGstin = shopGstin;
    this.shopWhatsapp = shopWhatsapp;
    this.promoEnabled = promoEnabled;
    this.promoTitle = promoTitle;
    this.promoMinBill = promoMinBill;
    this.promoDiscountPct = promoDiscountPct;
    await _db.collection('settings').doc('shop_config').set({
      'shopName': shopName,
      'shopGstin': shopGstin,
      'shopWhatsapp': shopWhatsapp,
      'promoEnabled': promoEnabled,
      'promoTitle': promoTitle,
      'promoMinBill': promoMinBill,
      'promoDiscountPct': promoDiscountPct,
      'updatedAt': DateTime.now().toIso8601String(),
    }, SetOptions(merge: true));
    notifyListeners();
  }

  Future<void> addSimpleDoc(String collection, Map<String, dynamic> data) async {
    await _db.collection(collection).doc(data['id'].toString()).set(data);
  }


  Future<void> recordMissing({
    required StockItem item,
    required String size,
    required int qty,
    required String reason,
  }) async {
    final batch = _db.batch();
    final newSizes = Map<String, int>.from(item.sizes);
    final cur = newSizes[size] ?? 0;
    newSizes[size] = (cur - qty) < 0 ? 0 : (cur - qty);
    final newQty = newSizes.values.fold<int>(0, (a, b) => a + b);
    final updated = StockItem(
      id: item.id,
      name: item.name,
      category: item.category,
      colour: item.colour,
      colourName: item.colourName,
      location: item.location,
      hsnCode: item.hsnCode,
      sizes: newSizes,
      qty: newQty,
      costPrice: item.costPrice,
      sellPrice: item.sellPrice,
      addedBy: item.addedBy,
      date: item.date,
      createdAt: item.createdAt,
    );
    final miss = MissingRecord(
      id: makeId('MIS'),
      stockId: item.id,
      itemName: item.name,
      size: size,
      qty: qty,
      lossAmount: item.costPrice * qty,
      reason: reason.trim().isEmpty ? 'Missing in rack check' : reason.trim(),
      reportedBy: userName,
      date: getLocalDateString(),
      createdAt: DateTime.now().toIso8601String(),
    );
    batch.set(_db.collection('missing_loss').doc(miss.id), miss.toMap());
    batch.update(_db.collection('stock').doc(updated.id), {'sizes': updated.sizes, 'qty': updated.qty});
    await batch.commit();
    _pushAppAlert('UNIVO WEAR • Missing Stock Report', '${item.name} [${size} x$qty] reported missing (-${formatInr(loss)}).');
  }

  Future<void> restoreMissing(MissingRecord miss, {String reason = 'Found in shop'}) async {
    final batch = _db.batch();
    final matches = stock.where((s) => s.id == miss.stockId).toList();
    if (matches.isNotEmpty) {
      final base = matches.first;
      final newSizes = Map<String, int>.from(base.sizes);
      newSizes[miss.size] = (newSizes[miss.size] ?? 0) + miss.qty;
      final newQty = newSizes.values.fold<int>(0, (a, b) => a + b);
      final restored = StockItem(
        id: base.id,
        name: base.name,
        category: base.category,
        colour: base.colour,
        colourName: base.colourName,
        location: base.location,
        hsnCode: base.hsnCode,
        sizes: newSizes,
        qty: newQty,
        costPrice: base.costPrice,
        sellPrice: base.sellPrice,
        addedBy: base.addedBy,
        date: base.date,
        createdAt: base.createdAt,
        photoBase64: base.photoBase64,
      );
      batch.set(_db.collection('stock').doc(restored.id), restored.toMap());
    }
    batch.delete(_db.collection('missing_loss').doc(miss.id));
    final rId = makeId('RST');
    final now = DateTime.now();
    batch.set(_db.collection('restore_logs').doc(rId), {
      'id': rId,
      'type': 'Missing Piece Restore',
      'itemName': miss.itemName,
      'size': miss.size,
      'qty': miss.qty,
      'reason': reason.trim().isEmpty ? 'Found in shop' : reason.trim(),
      'restoredBy': userName,
      'date': getLocalDateString(),
      'time': DateFormat('hh:mm a').format(now),
      'createdAt': now.toIso8601String(),
    });
    await batch.commit();
  }

  Future<String?> exchangeSaleSize(SaleRecord sale, String newSize) async {
    if (newSize == sale.size) return null;
    final matches = stock.where((s) => s.id == sale.stockId).toList();
    if (matches.isEmpty) return 'Original stock item not found';
    final base = matches.first;
    final avail = base.sizes[newSize] ?? 0;
    if (avail < sale.qty) return 'Only $avail pcs available in size $newSize';

    final batch = _db.batch();
    final newSizes = Map<String, int>.from(base.sizes);
    newSizes[sale.size] = (newSizes[sale.size] ?? 0) + sale.qty;
    newSizes[newSize] = avail - sale.qty;
    final newQty = newSizes.values.fold<int>(0, (a, b) => a + b);
    final updatedStock = StockItem(
      id: base.id,
      name: base.name,
      category: base.category,
      colour: base.colour,
      colourName: base.colourName,
      location: base.location,
      hsnCode: base.hsnCode,
      sizes: newSizes,
      qty: newQty,
      costPrice: base.costPrice,
      sellPrice: base.sellPrice,
      addedBy: base.addedBy,
      date: base.date,
      createdAt: base.createdAt,
    );
    final updatedSaleMap = sale.toMap();
    updatedSaleMap['size'] = newSize;
    batch.update(_db.collection('stock').doc(updatedStock.id), {'sizes': updatedStock.sizes, 'qty': updatedStock.qty});
    batch.update(_db.collection('sales').doc(sale.id), {'size': newSize});
    await batch.commit();
    return null;
  }

  Future<void> deleteDoc(String collection, String id) async {
    await _db.collection(collection).doc(id).delete();
  }

  Future<void> grantAdminRole(String targetUid, String name) async {
    await _db.collection('admin').doc(targetUid.trim()).set({
      'uid': targetUid.trim(),
      'name': name.trim().isEmpty ? 'Shop Admin' : name.trim(),
      'role': 'admin',
      'createdAt': DateTime.now().toIso8601String(),
    });
  }

  Future<void> redeemLoyaltyPoints(String phone) async {
    final cid = 'CUST-${phone.trim()}';
    final existing = customers.where((c) => c['phone'] == phone.trim()).toList();
    if (existing.isEmpty) return;
    final updated = Map<String, dynamic>.from(existing.first);
    updated['points'] = 0;
    await _db.collection('customers').doc(cid).set(updated);
  }

  Future<void> clearAllCloudData() async {
    for (final col in ['stock', 'sales', 'missing_loss', 'partners', 'khata', 'suppliers', 'alterations', 'customers']) {
      final snap = await _db.collection(col).get();
      final batch = _db.batch();
      for (final d in snap.docs) {
        batch.delete(d.reference);
      }
      await batch.commit();
    }
  }

  @override
  void dispose() {
    for (final s in _subs) {
      s.cancel();
    }
    super.dispose();
  }
}
