import 'dart:async';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:google_sign_in/google_sign_in.dart';
import '../core/constants.dart';
import '../models/pos_models.dart';

enum UserRole { owner, admin, staff, guest }

class PosStore extends ChangeNotifier {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _db = FirebaseFirestore.instance;
  final GoogleSignIn _googleSignIn = GoogleSignIn();

  UserRole role = UserRole.guest;
  String userName = 'Guest Visitor';
  String userEmail = 'Not signed in';
  String userUid = '';
  bool enteredApp = false;
  bool isDark = true;
  bool isTamil = false;

  double maxStaffDiscount = 200;
  double commissionPct = 2;
  double openingCash = 1000;
  double dailyExpense = 0;

  List<StockItem> stock = [];
  List<SaleRecord> sales = [];
  List<MissingRecord> missing = [];
  List<Map<String, dynamic>> partners = [];
  List<Map<String, dynamic>> khata = [];
  List<Map<String, dynamic>> suppliers = [];
  List<Map<String, dynamic>> alterations = [];
  List<Map<String, dynamic>> customers = [];

  final List<StreamSubscription<dynamic>> _subs = [];

  bool get isAdmin => role == UserRole.owner || role == UserRole.admin;
  bool get isGuest => role == UserRole.guest;

  String t(String en, String ta) => isTamil ? ta : en;

  PosStore() {
    _initListeners();
  }

  void _initListeners() {
    _subs.add(_auth.authStateChanges().listen((user) async {
      if (user != null) {
        await _resolveRole(user);
      } else {
        role = UserRole.guest;
        userName = 'Guest Visitor';
        userEmail = 'Not signed in';
        userUid = '';
        notifyListeners();
      }
    }));

    _subs.add(_db.collection('stock').snapshots().listen((snap) {
      stock = snap.docs.map((d) => StockItem.fromMap(d.data())).toList();
      notifyListeners();
    }));

    _subs.add(_db.collection('sales').snapshots().listen((snap) {
      sales = snap.docs.map((d) => SaleRecord.fromMap(d.data())).toList()
        ..sort((a, b) => b.createdAt.compareTo(a.createdAt));
      notifyListeners();
    }));

    _subs.add(_db.collection('missing_loss').snapshots().listen((snap) {
      missing = snap.docs.map((d) => MissingRecord.fromMap(d.data())).toList()
        ..sort((a, b) => b.createdAt.compareTo(a.createdAt));
      notifyListeners();
    }));

    _subs.add(_db.collection('partners').snapshots().listen((snap) {
      partners = snap.docs.map((d) => d.data()).toList();
      notifyListeners();
    }));

    _subs.add(_db.collection('khata').snapshots().listen((snap) {
      khata = snap.docs.map((d) => d.data()).toList();
      notifyListeners();
    }));

    _subs.add(_db.collection('suppliers').snapshots().listen((snap) {
      suppliers = snap.docs.map((d) => d.data()).toList();
      notifyListeners();
    }));

    _subs.add(_db.collection('alterations').snapshots().listen((snap) {
      alterations = snap.docs.map((d) => d.data()).toList();
      notifyListeners();
    }));

    _subs.add(_db.collection('customers').snapshots().listen((snap) {
      customers = snap.docs.map((d) => d.data()).toList();
      notifyListeners();
    }));

    _subs.add(_db.collection('settings').doc('shop_config').snapshots().listen((doc) {
      if (doc.exists) {
        final d = doc.data() ?? {};
        if (d['maxStaffDiscount'] != null) {
          maxStaffDiscount = (d['maxStaffDiscount'] as num).toDouble();
        }
        if (d['commissionPct'] != null) {
          commissionPct = (d['commissionPct'] as num).toDouble();
        }
        notifyListeners();
      }
    }));
  }

  Future<void> _resolveRole(User user) async {
    UserRole resolved = UserRole.staff;
    try {
      final ownerDoc = await _db.collection('owner').doc(user.uid).get();
      if (ownerDoc.exists) {
        resolved = UserRole.owner;
      } else {
        final adminDoc = await _db.collection('admin').doc(user.uid).get();
        if (adminDoc.exists) {
          resolved = UserRole.admin;
        } else {
          final anyOwners = await _db.collection('owner').limit(1).get();
          if (anyOwners.docs.isEmpty) {
            await _db.collection('owner').doc(user.uid).set({
              'uid': user.uid,
              'name': user.displayName ?? user.email?.split('@').first ?? 'Owner',
              'email': user.email ?? '',
              'role': 'owner',
              'createdAt': DateTime.now().toIso8601String(),
            });
            resolved = UserRole.owner;
          }
        }
      }
    } catch (_) {}

    role = resolved;
    userUid = user.uid;
    userEmail = user.email ?? '';
    userName = user.displayName ?? (userEmail.isNotEmpty ? userEmail.split('@').first : 'User');
    enteredApp = true;
    notifyListeners();
  }

  Future<String?> signInWithGoogle() async {
    try {
      await _googleSignIn.signOut();
      final gUser = await _googleSignIn.signIn();
      if (gUser == null) return null;
      final gAuth = await gUser.authentication;
      final cred = GoogleAuthProvider.credential(
        accessToken: gAuth.accessToken,
        idToken: gAuth.idToken,
      );
      await _auth.signInWithCredential(cred);
      return null;
    } catch (e) {
      return 'Google Sign-In error: Add SHA-1 in Firebase Console or use Cloud Email Login ($e)';
    }
  }

  Future<String?> signInWithEmail(String email, String password) async {
    try {
      await _auth.signInWithEmailAndPassword(email: email.trim(), password: password.trim());
      return null;
    } on FirebaseAuthException catch (e) {
      if (e.code == 'user-not-found' || e.code == 'invalid-credential') {
        try {
          await _auth.createUserWithEmailAndPassword(email: email.trim(), password: password.trim());
          return null;
        } catch (ce) {
          return 'Email sign-in failed: $ce';
        }
      }
      return e.message ?? 'Email sign-in failed';
    } catch (e) {
      return 'Sign-in error: $e';
    }
  }

  void enterGuestMode() {
    role = UserRole.guest;
    userName = 'Guest Visitor';
    userEmail = 'Not signed in';
    enteredApp = true;
    notifyListeners();
  }

  Future<void> signOut() async {
    try {
      await _googleSignIn.signOut();
    } catch (_) {}
    await _auth.signOut();
    role = UserRole.guest;
    enteredApp = false;
    notifyListeners();
  }

  void toggleTheme() {
    isDark = !isDark;
    notifyListeners();
  }

  void toggleLanguage() {
    isTamil = !isTamil;
    notifyListeners();
  }

  Future<void> saveStock(StockItem item) async {
    await _db.collection('stock').doc(item.id).set(item.toMap());
  }

  Future<void> deleteStock(String id) async {
    await _db.collection('stock').doc(id).delete();
  }

  Future<void> completeSale({
    required List<CartLine> lines,
    required String payment,
    required bool gstEnabled,
    required String customerName,
    required String customerPhone,
  }) async {
    final batch = _db.batch();
    int totalQty = 0;
    double taxableTotal = 0;
    double mrpTotal = 0;
    double totalCost = 0;
    final names = <String>[];
    final updatedStocks = <String, StockItem>{};

    for (final line in lines) {
      final current = updatedStocks[line.stockId] ?? stock.firstWhere((s) => s.id == line.stockId);
      final newSizes = Map<String, int>.from(current.sizes);
      final curCnt = newSizes[line.size] ?? 0;
      newSizes[line.size] = (curCnt - line.qty) < 0 ? 0 : (curCnt - line.qty);
      final newQty = newSizes.values.fold<int>(0, (a, b) => a + b);
      updatedStocks[line.stockId] = StockItem(
        id: current.id,
        name: current.name,
        category: current.category,
        colour: current.colour,
        colourName: current.colourName,
        location: current.location,
        hsnCode: current.hsnCode,
        sizes: newSizes,
        qty: newQty,
        costPrice: current.costPrice,
        sellPrice: current.sellPrice,
        addedBy: current.addedBy,
        date: current.date,
        createdAt: current.createdAt,
      );
      totalQty += line.qty;
      taxableTotal += line.totalSellPrice;
      mrpTotal += line.mrpTotal;
      totalCost += line.costPrice * line.qty;
      names.add('${line.itemName} (${line.size}x${line.qty})');
    }

    final avgUnit = totalQty > 0 ? taxableTotal / totalQty : 0.0;
    final gstRate = gstEnabled ? (avgUnit <= 1000 ? 5 : 12) : 0;
    final gstTotal = gstEnabled ? (taxableTotal * gstRate / 100).roundToDouble() : 0.0;
    final grandTotal = taxableTotal + gstTotal;
    final discount = (mrpTotal - taxableTotal) < 0 ? 0.0 : (mrpTotal - taxableTotal);
    final profit = taxableTotal - totalCost;

    final now = DateTime.now();
    final sale = SaleRecord(
      id: makeId('INV'),
      stockId: lines.first.stockId,
      itemName: names.join(' + '),
      cartItems: lines,
      size: lines.length > 1 ? 'MULTI' : lines.first.size,
      qty: totalQty,
      mrpTotal: mrpTotal,
      discount: discount,
      unitSellPrice: avgUnit,
      taxableValue: taxableTotal,
      gstRate: gstRate,
      gstTotal: gstTotal,
      totalSellPrice: grandTotal,
      costPrice: totalQty > 0 ? totalCost / totalQty : 0,
      profit: profit,
      payment: payment,
      soldBy: userName,
      customerName: customerName.trim(),
      customerPhone: customerPhone.trim(),
      date: getLocalDateString(),
      time: DateFormat('hh:mm a').format(now),
      createdAt: now.toIso8601String(),
    );

    batch.set(_db.collection('sales').doc(sale.id), sale.toMap());
    for (final st in updatedStocks.values) {
      batch.set(_db.collection('stock').doc(st.id), st.toMap());
    }

    if (customerPhone.trim().length >= 10) {
      final ph = customerPhone.trim();
      final cid = 'CUST-$ph';
      final existing = customers.where((c) => c['phone'] == ph).toList();
      final prevPts = existing.isNotEmpty ? (existing.first['points'] as num? ?? 0).toInt() : 0;
      final prevSpent = existing.isNotEmpty ? (existing.first['totalSpent'] as num? ?? 0).toDouble() : 0.0;
      batch.set(_db.collection('customers').doc(cid), {
        'id': cid,
        'phone': ph,
        'name': customerName.trim().isNotEmpty ? customerName.trim() : 'VIP Customer',
        'points': prevPts + (grandTotal ~/ 100),
        'totalSpent': prevSpent + grandTotal,
      });
    }

    if (payment == 'Credit (Khata)') {
      final kid = makeId('KHT');
      batch.set(_db.collection('khata').doc(kid), {
        'id': kid,
        'customerName': customerName.trim().isNotEmpty ? customerName.trim() : 'Walk-in Customer',
        'phone': customerPhone.trim(),
        'amount': grandTotal,
        'note': 'Bill ${sale.id}: ${sale.itemName}',
        'status': 'Pending',
        'date': getLocalDateString(),
        'createdAt': now.toIso8601String(),
      });
    }

    await batch.commit();
  }

  Future<void> refundSale(SaleRecord sale) async {
    final batch = _db.batch();
    final restoreLines = sale.cartItems.isNotEmpty
        ? sale.cartItems
        : [
            CartLine(
              stockId: sale.stockId,
              itemName: sale.itemName,
              hsnCode: '6203',
              size: sale.size,
              qty: sale.qty,
              unitMrp: sale.unitSellPrice,
              unitSellPrice: sale.unitSellPrice,
              costPrice: sale.costPrice,
            ),
          ];

    final touched = <String, StockItem>{};
    for (final line in restoreLines) {
      final matches = stock.where((s) => s.id == line.stockId).toList();
      if (matches.isEmpty) continue;
      final base = touched[line.stockId] ?? matches.first;
      final newSizes = Map<String, int>.from(base.sizes);
      newSizes[line.size] = (newSizes[line.size] ?? 0) + line.qty;
      final newQty = newSizes.values.fold<int>(0, (a, b) => a + b);
      touched[line.stockId] = StockItem(
        id: base.id,
        name: base.name,
        category: base.category,
        colour: base.colour,
        colourName: base.colourName,
        location: base.location,
        hsnCode: base.hsnCode,
        sizes: newSizes,
        qty: newQty,
        costPrice: base.costPrice,
        sellPrice: base.sellPrice,
        addedBy: base.addedBy,
        date: base.date,
        createdAt: base.createdAt,
      );
    }

    for (final st in touched.values) {
      batch.set(_db.collection('stock').doc(st.id), st.toMap());
    }
    batch.delete(_db.collection('sales').doc(sale.id));
    await batch.commit();
  }

  Future<void> saveShopConfig({required double maxDisc, required double commPct}) async {
    maxStaffDiscount = maxDisc;
    commissionPct = commPct;
    await _db.collection('settings').doc('shop_config').set({
      'maxStaffDiscount': maxDisc,
      'commissionPct': commPct,
      'updatedAt': DateTime.now().toIso8601String(),
    }, SetOptions(merge: true));
    notifyListeners();
  }

  Future<void> addSimpleDoc(String collection, Map<String, dynamic> data) async {
    await _db.collection(collection).doc(data['id'].toString()).set(data);
  }

  Future<void> clearAllCloudData() async {
    for (final col in ['stock', 'sales', 'missing_loss', 'partners', 'khata', 'suppliers', 'alterations', 'customers']) {
      final snap = await _db.collection(col).get();
      final batch = _db.batch();
      for (final d in snap.docs) {
        batch.delete(d.reference);
      }
      await batch.commit();
    }
  }

  @override
  void dispose() {
    for (final s in _subs) {
      s.cancel();
    }
    super.dispose();
  }
}
