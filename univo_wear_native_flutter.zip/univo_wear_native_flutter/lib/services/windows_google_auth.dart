import 'dart:convert';
import 'dart:io';
import 'dart:math';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:path_provider/path_provider.dart';
import 'package:url_launcher/url_launcher.dart';

class WindowsOAuthCreds {
  final String clientId;
  final String clientSecret;
  WindowsOAuthCreds({required this.clientId, required this.clientSecret});
}

Future<File> _oauthCredsFile() async {
  final dir = await getApplicationSupportDirectory();
  if (!await dir.exists()) await dir.create(recursive: true);
  return File('${dir.path}${Platform.pathSeparator}univo_win_oauth.json');
}

Future<WindowsOAuthCreds?> loadWindowsOAuthCreds() async {
  try {
    final f = await _oauthCredsFile();
    if (!await f.exists()) return null;
    final m = jsonDecode(await f.readAsString()) as Map<String, dynamic>;
    final cid = (m['clientId'] ?? '').toString().trim();
    final csec = (m['clientSecret'] ?? '').toString().trim();
    if (cid.isEmpty || csec.isEmpty) return null;
    return WindowsOAuthCreds(clientId: cid, clientSecret: csec);
  } catch (_) {
    return null;
  }
}

Future<void> saveWindowsOAuthCreds(String clientId, String clientSecret) async {
  final f = await _oauthCredsFile();
  await f.writeAsString(jsonEncode({
    'clientId': clientId.trim(),
    'clientSecret': clientSecret.trim(),
  }));
}

String _randomState(int len) {
  const chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  final r = Random.secure();
  return List.generate(len, (_) => chars[r.nextInt(chars.length)]).join();
}

/// Native Windows EXE Google Sign-In via OAuth 2.0 Loopback (127.0.0.1) + Firebase Auth
Future<String?> signInWithGoogleWindows(FirebaseAuth auth, WindowsOAuthCreds creds) async {
  HttpServer? server;
  try {
    server = await HttpServer.bind(InternetAddress.loopbackIPv4, 0);
    final port = server.port;
    final redirectUri = 'http://127.0.0.1:$port/callback';
    final state = _randomState(24);

    final authUri = Uri.https('accounts.google.com', '/o/oauth2/v2/auth', {
      'client_id': creds.clientId,
      'redirect_uri': redirectUri,
      'response_type': 'code',
      'scope': 'openid email profile',
      'state': state,
      'prompt': 'select_account',
      'access_type': 'offline',
    });

    await launchUrl(authUri, mode: LaunchMode.externalApplication);

    // Wait up to 3 minutes for user to finish Google login
    String? authCode;
    await for (final req in server.timeout(const Duration(minutes: 3))) {
      if (req.uri.path == '/callback') {
        final q = req.uri.queryParameters;
        final err = q['error'];
        final returnedState = q['state'];
        final code = q['code'];

        req.response.headers.contentType = ContentType.html;
        if (err != null || code == null || returnedState != state) {
          req.response.write(
            '<html><body style="font-family:sans-serif;background:#0A0B0E;color:#fff;text-align:center;padding:60px;">'
            '<h2 style="color:#FB7185;">Sign-In Cancelled</h2><p>You can close this tab and return to UNIVO WEAR.</p></body></html>',
          );
          await req.response.close();
          await server.close();
          return err != null ? 'Google Sign-In cancelled ($err)' : 'Invalid Google OAuth response';
        }

        req.response.write(
          '<html><body style="font-family:sans-serif;background:#0A0B0E;color:#fff;text-align:center;padding:60px;">'
          '<h2 style="color:#E5B869;">UNIVO WEAR Signed In!</h2>'
          '<p style="color:#34D399;">Login successful. You can close this tab and return to UNIVO WEAR app.</p></body></html>',
        );
        await req.response.close();
        authCode = code;
        break;
      } else {
        req.response.statusCode = 404;
        await req.response.close();
      }
    }
    await server.close();
    server = null;

    if (authCode == null) return 'Google Sign-In timed out. Please try again.';

    // Exchange authorization code for id_token + access_token
    final httpClient = HttpClient();
    final tokenReq = await httpClient.postUrl(Uri.parse('https://oauth2.googleapis.com/token'));
    tokenReq.headers.contentType = ContentType('application', 'x-www-form-urlencoded', charset: 'utf-8');
    final body = Uri(queryParameters: {
      'code': authCode,
      'client_id': creds.clientId,
      'client_secret': creds.clientSecret,
      'redirect_uri': redirectUri,
      'grant_type': 'authorization_code',
    }).query;
    tokenReq.write(body);
    final tokenRes = await tokenReq.close();
    final raw = await tokenRes.transform(utf8.decoder).join();
    httpClient.close();

    if (tokenRes.statusCode != 200) {
      return 'Google Token Error (${tokenRes.statusCode}): Check Desktop Client ID & Secret.';
    }
    final tok = jsonDecode(raw) as Map<String, dynamic>;
    final idToken = tok['id_token']?.toString();
    final accessToken = tok['access_token']?.toString();
    if (idToken == null && accessToken == null) {
      return 'Google did not return an ID token.';
    }

    final cred = GoogleAuthProvider.credential(idToken: idToken, accessToken: accessToken);
    await auth.signInWithCredential(cred);
    return null;
  } catch (e) {
    return 'Windows Google Sign-In error: $e';
  } finally {
    try {
      await server?.close(force: true);
    } catch (_) {}
  }
}
