import '../services/windows_google_auth.dart';
import 'package:flutter/material.dart';
import '../core/app_theme.dart';
import '../services/pos_store.dart';

class LoginGateScreen extends StatefulWidget {
  final PosStore store;
  const LoginGateScreen({super.key, required this.store});

  @override
  State<LoginGateScreen> createState() => _LoginGateScreenState();
}

class _LoginGateScreenState extends State<LoginGateScreen> {
  final _emailCtrl = TextEditingController();
  final _passCtrl = TextEditingController();
  String? _error;
  bool _busy = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 400),
              child: Card(
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
                child: Padding(
                  padding: const EdgeInsets.all(24),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      ClipRRect(
                        borderRadius: BorderRadius.circular(24),
                        child: Image.asset(
                          'assets/images/univo_logo.png',
                          width: 104,
                          height: 104,
                          fit: BoxFit.cover,
                        ),
                      ),
                      const SizedBox(height: 12),
                      const Text(
                        'UNIVO WEAR',
                        style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800, letterSpacing: 4),
                      ),
                      const SizedBox(height: 4),
                      const Text(
                        'Pure Native POS & Inventory',
                        style: TextStyle(fontSize: 12, color: Colors.grey),
                      ),
                      const SizedBox(height: 20),
                      SizedBox(
                        width: double.infinity,
                        child: ElevatedButton.icon(
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.white,
                            foregroundColor: Colors.black,
                            padding: const EdgeInsets.symmetric(vertical: 14),
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                          ),
                          onPressed: _busy
                              ? null
                              : () async {
                                  setState(() {
                                    _busy = true;
                                    _error = null;
                                  });
                                  String? err = await widget.store.signInWithGoogle();
                                  if (err == 'NEED_WIN_OAUTH' && mounted) {
                                    final saved = await _promptWindowsOAuthSetup(context);
                                    if (saved == true) {
                                      err = await widget.store.signInWithGoogle();
                                    } else {
                                      err = null;
                                    }
                                  }
                                  if (mounted) {
                                    setState(() {
                                      _busy = false;
                                      _error = err;
                                    });
                                  }
                                },
                          icon: Container(width: 22, height: 22, alignment: Alignment.center, decoration: const BoxDecoration(color: Color(0xFF4285F4), shape: BoxShape.circle), child: const Text('G', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 13))),
                          label: const Text('Sign in with Google', style: TextStyle(fontWeight: FontWeight.bold)),
                        ),
                      ),
                      if (_error != null) ...[
                        const SizedBox(height: 10),
                        Text(_error!, style: const TextStyle(color: Colors.redAccent, fontSize: 11), textAlign: TextAlign.center),
                      ],
                      const Divider(height: 28),
                      TextField(
                        controller: _emailCtrl,
                        keyboardType: TextInputType.emailAddress,
                        decoration: const InputDecoration(labelText: 'Shop Email'),
                      ),
                      const SizedBox(height: 10),
                      TextField(
                        controller: _passCtrl,
                        obscureText: true,
                        decoration: const InputDecoration(labelText: 'Password (min 6 chars)'),
                      ),
                      const SizedBox(height: 12),
                      SizedBox(
                        width: double.infinity,
                        child: ElevatedButton(
                          style: ElevatedButton.styleFrom(
                            backgroundColor: AppTheme.gold,
                            foregroundColor: Colors.black,
                            padding: const EdgeInsets.symmetric(vertical: 13),
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                          ),
                          onPressed: _busy
                              ? null
                              : () async {
                                  if (_emailCtrl.text.trim().isEmpty || _passCtrl.text.length < 6) {
                                    setState(() => _error = 'Enter valid email and 6+ char password');
                                    return;
                                  }
                                  setState(() {
                                    _busy = true;
                                    _error = null;
                                  });
                                  final err = await widget.store.signInWithEmail(_emailCtrl.text, _passCtrl.text);
                                  if (mounted) {
                                    setState(() {
                                      _busy = false;
                                      _error = err;
                                    });
                                  }
                                },
                          child: const Text('Sign In / Register with Email', style: TextStyle(fontWeight: FontWeight.bold)),
                        ),
                      ),
                      const SizedBox(height: 12),
                      SizedBox(
                        width: double.infinity,
                        child: OutlinedButton.icon(
                          onPressed: _busy ? null : () => widget.store.enterGuestMode(),
                          icon: const Icon(Icons.visibility_outlined),
                          label: const Text('Guest Mode (View Only)'),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Future<bool?> _promptWindowsOAuthSetup(BuildContext context) async {
    final idCtrl = TextEditingController();
    final secCtrl = TextEditingController();
    return showDialog<bool>(
      context: context,
      builder: (dCtx) => AlertDialog(
        title: const Text('One-Time Windows Google Setup', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                '1. Open Google Cloud Console → Project: univo-wear\n'
                '2. APIs & Services → Credentials → + Create Credentials → OAuth client ID\n'
                '3. Choose "Desktop app" → Paste Client ID & Client Secret below (saved privately on this PC):',
                style: TextStyle(fontSize: 11.5),
              ),
              const SizedBox(height: 12),
              TextField(controller: idCtrl, decoration: const InputDecoration(labelText: 'Desktop Client ID *')),
              const SizedBox(height: 10),
              TextField(controller: secCtrl, decoration: const InputDecoration(labelText: 'Client Secret *')),
            ],
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dCtx, false), child: const Text('Cancel')),
          ElevatedButton(
            onPressed: () async {
              if (idCtrl.text.trim().isEmpty || secCtrl.text.trim().isEmpty) return;
              await saveWindowsOAuthCreds(idCtrl.text, secCtrl.text);
              if (dCtx.mounted) Navigator.pop(dCtx, true);
            },
            child: const Text('Save & Sign In'),
          ),
        ],
      ),
    );
  }
}
