import 'package:flutter/material.dart';
import '../core/app_theme.dart';
import '../services/pos_store.dart';

class LoginGateScreen extends StatefulWidget {
  final PosStore store;
  const LoginGateScreen({super.key, required this.store});

  @override
  State<LoginGateScreen> createState() => _LoginGateScreenState();
}

class _LoginGateScreenState extends State<LoginGateScreen> {
  final _emailCtrl = TextEditingController();
  final _passCtrl = TextEditingController();
  String? _error;
  bool _busy = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 400),
              child: Card(
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
                child: Padding(
                  padding: const EdgeInsets.all(24),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Container(
                        width: 68,
                        height: 68,
                        decoration: BoxDecoration(
                          color: Colors.black,
                          borderRadius: BorderRadius.circular(18),
                          border: Border.all(color: AppTheme.gold, width: 1.5),
                        ),
                        alignment: Alignment.center,
                        child: const Text(
                          'UW',
                          style: TextStyle(fontSize: 28, fontWeight: FontWeight.w800, color: AppTheme.gold),
                        ),
                      ),
                      const SizedBox(height: 12),
                      const Text(
                        'UNIVO WEAR',
                        style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800, letterSpacing: 4),
                      ),
                      const SizedBox(height: 4),
                      const Text(
                        'Pure Native POS & Inventory',
                        style: TextStyle(fontSize: 12, color: Colors.grey),
                      ),
                      const SizedBox(height: 20),
                      SizedBox(
                        width: double.infinity,
                        child: ElevatedButton.icon(
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.white,
                            foregroundColor: Colors.black,
                            padding: const EdgeInsets.symmetric(vertical: 14),
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                          ),
                          onPressed: _busy
                              ? null
                              : () async {
                                  setState(() {
                                    _busy = true;
                                    _error = null;
                                  });
                                  final err = await widget.store.signInWithGoogle();
                                  if (mounted) {
                                    setState(() {
                                      _busy = false;
                                      _error = err;
                                    });
                                  }
                                },
                          icon: const Icon(Icons.login, color: Colors.redAccent),
                          label: const Text('Sign in with Google', style: TextStyle(fontWeight: FontWeight.bold)),
                        ),
                      ),
                      if (_error != null) ...[
                        const SizedBox(height: 10),
                        Text(_error!, style: const TextStyle(color: Colors.redAccent, fontSize: 11), textAlign: TextAlign.center),
                      ],
                      const Divider(height: 28),
                      TextField(
                        controller: _emailCtrl,
                        keyboardType: TextInputType.emailAddress,
                        decoration: const InputDecoration(labelText: 'Shop Email'),
                      ),
                      const SizedBox(height: 10),
                      TextField(
                        controller: _passCtrl,
                        obscureText: true,
                        decoration: const InputDecoration(labelText: 'Password (min 6 chars)'),
                      ),
                      const SizedBox(height: 12),
                      SizedBox(
                        width: double.infinity,
                        child: ElevatedButton(
                          style: ElevatedButton.styleFrom(
                            backgroundColor: AppTheme.gold,
                            foregroundColor: Colors.black,
                            padding: const EdgeInsets.symmetric(vertical: 13),
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                          ),
                          onPressed: _busy
                              ? null
                              : () async {
                                  if (_emailCtrl.text.trim().isEmpty || _passCtrl.text.length < 6) {
                                    setState(() => _error = 'Enter valid email and 6+ char password');
                                    return;
                                  }
                                  setState(() {
                                    _busy = true;
                                    _error = null;
                                  });
                                  final err = await widget.store.signInWithEmail(_emailCtrl.text, _passCtrl.text);
                                  if (mounted) {
                                    setState(() {
                                      _busy = false;
                                      _error = err;
                                    });
                                  }
                                },
                          child: const Text('Sign In / Register with Email', style: TextStyle(fontWeight: FontWeight.bold)),
                        ),
                      ),
                      const SizedBox(height: 12),
                      SizedBox(
                        width: double.infinity,
                        child: OutlinedButton.icon(
                          onPressed: _busy ? null : () => widget.store.enterGuestMode(),
                          icon: const Icon(Icons.visibility_outlined),
                          label: const Text('Guest Mode (View Only)'),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
