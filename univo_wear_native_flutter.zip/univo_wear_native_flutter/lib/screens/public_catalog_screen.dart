import 'dart:convert';
import 'package:flutter/material.dart';
import '../core/app_theme.dart';
import '../core/constants.dart';
import '../services/pos_store.dart';

class PublicCatalogScreen extends StatefulWidget {
  final PosStore store;
  const PublicCatalogScreen({super.key, required this.store});

  @override
  State<PublicCatalogScreen> createState() => _PublicCatalogScreenState();
}

class _PublicCatalogScreenState extends State<PublicCatalogScreen> {
  String _cat = 'ALL';
  String _search = '';

  @override
  Widget build(BuildContext context) {
    final s = widget.store;
    final accent = s.isDark ? AppTheme.gold : AppTheme.goldLightMode;
    final muted = s.isDark ? const Color(0xFF94A3B8) : const Color(0xFF64748B);
    final items = s.stock.where((i) {
      if (i.qty <= 0) return false;
      if (_cat != 'ALL' && i.category != _cat) return false;
      if (_search.isNotEmpty && !i.name.toLowerCase().contains(_search.toLowerCase())) return false;
      return true;
    }).toList();

    return Scaffold(
      appBar: AppBar(
        title: Row(
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(10),
              child: Image.asset('assets/images/univo_logo.png', width: 32, height: 32, fit: BoxFit.cover),
            ),
            const SizedBox(width: 10),
            Text('${s.shopName} CATALOG', style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 15, letterSpacing: 1.5)),
          ],
        ),
        actions: [
          IconButton(
            icon: Icon(s.isDark ? Icons.wb_sunny_outlined : Icons.dark_mode_outlined, color: accent),
            onPressed: s.toggleTheme,
          ),
        ],
      ),
      body: Column(
        children: [
          if (s.promoEnabled)
            Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
              color: accent.withAlpha(32),
              child: Text(
                '${s.promoTitle} • ${s.promoDiscountPct.toStringAsFixed(0)}% OFF on orders above ${formatInr(s.promoMinBill)}',
                textAlign: TextAlign.center,
                style: TextStyle(fontWeight: FontWeight.w900, fontSize: 12, color: accent),
              ),
            ),
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
            child: TextField(
              decoration: const InputDecoration(prefixIcon: Icon(Icons.search_rounded), hintText: 'Search available styles...'),
              onChanged: (v) => setState(() => _search = v),
            ),
          ),
          SizedBox(
            height: 38,
            child: ListView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 16),
              children: ['ALL', ...kCategories].map((c) {
                final act = _cat == c;
                return Padding(
                  padding: const EdgeInsets.only(right: 8),
                  child: ChoiceChip(
                    label: Text(c, style: const TextStyle(fontSize: 11.5, fontWeight: FontWeight.w700)),
                    selected: act,
                    onSelected: (_) => setState(() => _cat = c),
                  ),
                );
              }).toList(),
            ),
          ),
          const SizedBox(height: 8),
          Expanded(
            child: items.isEmpty
                ? Center(child: Text('Loading live showroom collection...', style: TextStyle(color: muted)))
                : GridView.builder(
                    padding: const EdgeInsets.all(16),
                    gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: MediaQuery.of(context).size.width >= 900 ? 4 : 2,
                      crossAxisSpacing: 12,
                      mainAxisSpacing: 12,
                      childAspectRatio: 0.68,
                    ),
                    itemCount: items.length,
                    itemBuilder: (_, idx) {
                      final item = items[idx];
                      final availSizes = item.sizes.entries.where((e) => e.value > 0).map((e) => e.key).join(', ');
                      return Card(
                        clipBehavior: Clip.antiAlias,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Expanded(
                              child: item.photoBase64.isNotEmpty
                                  ? Image.memory(base64Decode(item.photoBase64), width: double.infinity, fit: BoxFit.cover)
                                  : Container(
                                      color: hexToColor(item.colour),
                                      alignment: Alignment.center,
                                      child: const Icon(Icons.checkroom_rounded, color: Colors.white70, size: 44),
                                    ),
                            ),
                            Padding(
                              padding: const EdgeInsets.all(10),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(item.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 13)),
                                  Text('Sizes: $availSizes', maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 10.5, color: muted)),
                                  const SizedBox(height: 6),
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    children: [
                                      Text(formatInr(item.sellPrice), style: TextStyle(fontWeight: FontWeight.w900, fontSize: 14, color: accent)),
                                      InkWell(
                                        onTap: () => openWhatsAppMessage(
                                          'Hi ${s.shopName}! I want to reserve: ${item.name} (${formatInr(item.sellPrice)}) • Available Sizes: $availSizes',
                                          phone: s.shopWhatsapp,
                                        ),
                                        child: Container(
                                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                                          decoration: BoxDecoration(color: AppTheme.green.withAlpha(32), borderRadius: BorderRadius.circular(8)),
                                          child: const Text('Reserve', style: TextStyle(fontSize: 10.5, fontWeight: FontWeight.w800, color: AppTheme.green)),
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }
}
