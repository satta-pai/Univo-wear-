import 'dart:ui';
import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../core/app_theme.dart';
import '../core/constants.dart';
import '../models/pos_models.dart';
import '../services/pos_store.dart';
import '../sheets/add_stock_sheet.dart';
import '../sheets/pro_suite_sheets.dart';

class HomeShell extends StatefulWidget {
  final PosStore store;
  const HomeShell({super.key, required this.store});

  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int _tab = 0;
  String _stockSearch = '';
  String _stockCat = 'ALL';
  String _salesFilter = 'ALL';
  final List<CartLine> _quickCart = [];

  Color get _accent => widget.store.isDark ? AppTheme.gold : AppTheme.goldLightMode;
  Color get _green => widget.store.isDark ? AppTheme.green : AppTheme.greenLightMode;
  Color get _rose => widget.store.isDark ? AppTheme.rose : AppTheme.roseLightMode;
  Color get _surface => widget.store.isDark ? AppTheme.darkSurface : AppTheme.lightSurface;
  Color get _card => widget.store.isDark ? AppTheme.darkCard : AppTheme.lightCard;
  Color get _border => widget.store.isDark ? AppTheme.darkBorder : AppTheme.lightBorder;
  Color get _ctaBg => widget.store.isDark ? const Color(0xFFF8FAFC) : const Color(0xFF111318);
  Color get _ctaFg => widget.store.isDark ? const Color(0xFF0A0B0E) : Colors.white;
  Color get _muted => widget.store.isDark ? const Color(0xFF8B92A5) : const Color(0xFF667085);

  void _openAddStock(PosStore s, {StockItem? existing}) {
    if (s.isGuest) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Guest Mode is View Only! Sign in to add stock.')),
      );
      return;
    }
    HapticFeedback.lightImpact();
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(28))),
      builder: (_) => AddStockSheet(store: s, existing: existing),
    );
  }


  void _addToQuickCart(PosStore s, StockItem item, String sz) {
    if (s.isGuest) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Guest Mode is View Only! Sign in to bill.')),
      );
      return;
    }
    final already = _quickCart.where((c) => c.stockId == item.id && c.size == sz).fold<int>(0, (a, b) => a + b.qty);
    final avail = (item.sizes[sz] ?? 0) - already;
    if (avail <= 0) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('No more $sz left in stock')));
      return;
    }
    HapticFeedback.lightImpact();
    setState(() {
      _quickCart.add(CartLine(
        stockId: item.id,
        itemName: item.name,
        hsnCode: item.hsnCode,
        size: sz,
        qty: 1,
        unitMrp: item.sellPrice,
        unitSellPrice: item.sellPrice,
        costPrice: item.costPrice,
      ));
    });
  }

  void _openQuickCheckoutDrawer(PosStore s) {
    if (_quickCart.isEmpty) {
      setState(() => _tab = 1);
      return;
    }
    final discCtrl = TextEditingController(text: '0');
    final phoneCtrl = TextEditingController();
    final nameCtrl = TextEditingController();
    String payment = 'UPI / GPay';
    bool gst = false;

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(28))),
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setSt) {
          final sub = _quickCart.fold<double>(0, (a, b) => a + b.totalSellPrice);
          final disc = double.tryParse(discCtrl.text) ?? 0;
          final afterDisc = (sub - disc) < 0 ? 0.0 : (sub - disc);
          final gstAmt = gst ? (afterDisc * 0.05).roundToDouble() : 0.0;
          final payable = afterDisc + gstAmt;

          return Padding(
            padding: EdgeInsets.only(left: 20, right: 20, top: 16, bottom: MediaQuery.of(ctx).viewInsets.bottom + 24),
            child: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Center(child: Container(width: 40, height: 4, decoration: BoxDecoration(color: _muted.withAlpha(80), borderRadius: BorderRadius.circular(8)))),
                  const SizedBox(height: 14),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text('Checkout (${_quickCart.length} items)', style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
                      TextButton(
                        onPressed: () {
                          setState(() => _quickCart.clear());
                          Navigator.pop(ctx);
                        },
                        child: Text('Clear', style: TextStyle(color: _rose)),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  ..._quickCart.asMap().entries.map((entry) => Container(
                        margin: const EdgeInsets.only(bottom: 8),
                        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                        decoration: BoxDecoration(color: _surface, borderRadius: BorderRadius.circular(16), border: Border.all(color: _border)),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Expanded(
                              child: Text('${entry.value.itemName} (${entry.value.size})', style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13)),
                            ),
                            Text(formatInr(entry.value.totalSellPrice), style: const TextStyle(fontWeight: FontWeight.w800)),
                            IconButton(
                              icon: Icon(Icons.close, size: 16, color: _rose),
                              onPressed: () {
                                setState(() => _quickCart.removeAt(entry.key));
                                if (_quickCart.isEmpty) {
                                  Navigator.pop(ctx);
                                } else {
                                  setSt(() {});
                                }
                              },
                            ),
                          ],
                        ),
                      )),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      Expanded(
                        child: TextField(
                          controller: discCtrl,
                          keyboardType: TextInputType.number,
                          decoration: const InputDecoration(labelText: 'Bargain / Less (₹)'),
                          onChanged: (_) => setSt(() {}),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: DropdownButtonFormField<String>(
                          initialValue: payment,
                          decoration: const InputDecoration(labelText: 'Payment'),
                          items: kPaymentModes.map((m) => DropdownMenuItem(value: m, child: Text(m))).toList(),
                          onChanged: (v) {
                            if (v != null) setSt(() => payment = v);
                          },
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      Expanded(child: TextField(controller: phoneCtrl, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: 'Customer Mobile'))),
                      const SizedBox(width: 10),
                      Expanded(child: TextField(controller: nameCtrl, decoration: const InputDecoration(labelText: 'Customer Name'))),
                    ],
                  ),
                  CheckboxListTile(
                    contentPadding: EdgeInsets.zero,
                    title: const Text('Include GST (CGST + SGST)', style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
                    value: gst,
                    onChanged: (v) => setSt(() => gst = v ?? false),
                  ),
                  const Divider(),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text('Total Payable', style: TextStyle(color: _muted, fontWeight: FontWeight.w600)),
                      Text(formatInr(payable), style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900, color: _green)),
                    ],
                  ),
                  const SizedBox(height: 14),
                  SizedBox(
                    width: double.infinity,
                    height: 52,
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: _ctaBg,
                        foregroundColor: _ctaFg,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                      ),
                      onPressed: () async {
                        if (!s.isAdmin && disc > s.maxStaffDiscount * _quickCart.length) {
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(content: Text('Blocked: Max staff discount is ₹${s.maxStaffDiscount.toStringAsFixed(0)}/item')),
                          );
                          return;
                        }
                        final ratio = sub > 0 ? (afterDisc / sub) : 1.0;
                        final adjustedLines = _quickCart
                            .map((c) => CartLine(
                                  stockId: c.stockId,
                                  itemName: c.itemName,
                                  hsnCode: c.hsnCode,
                                  size: c.size,
                                  qty: c.qty,
                                  unitMrp: c.unitMrp,
                                  unitSellPrice: (c.unitSellPrice * ratio).roundToDouble(),
                                  costPrice: c.costPrice,
                                ))
                            .toList();
                        await s.completeSale(
                          lines: adjustedLines,
                          payment: payment,
                          gstEnabled: gst,
                          customerName: nameCtrl.text,
                          customerPhone: phoneCtrl.text,
                        );
                        setState(() => _quickCart.clear());
                        if (ctx.mounted) Navigator.pop(ctx);
                        if (mounted) {
                          ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Bill completed • ${formatInr(payable)}')));
                        }
                      },
                      child: const Text('Complete Bill & Save', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 14)),
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final s = widget.store;
    final cartTotal = _quickCart.fold<double>(0, (a, b) => a + b.totalSellPrice);

    return Scaffold(
      appBar: AppBar(
        toolbarHeight: 66,
        title: Row(
          children: [
            Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                color: _card,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: _border),
              ),
              alignment: Alignment.center,
              child: Text('UW', style: TextStyle(color: _accent, fontWeight: FontWeight.w800, fontSize: 16, fontFamily: 'Georgia')),
            ),
            const SizedBox(width: 12),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    const Text('UNIVO WEAR', style: TextStyle(fontWeight: FontWeight.w800, letterSpacing: 1.2, fontSize: 16, fontFamily: 'Georgia')),
                    const SizedBox(width: 8),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                      decoration: BoxDecoration(
                        color: _accent.withAlpha(34),
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Text(
                        s.role.name.toUpperCase(),
                        style: TextStyle(color: _accent, fontSize: 9, fontWeight: FontWeight.w800),
                      ),
                    ),
                  ],
                ),
                Text('Atelier POS • ${s.userName}', style: TextStyle(fontSize: 11, color: _muted)),
              ],
            ),
          ],
        ),
        actions: [
          InkWell(
            borderRadius: BorderRadius.circular(20),
            onTap: () {
              HapticFeedback.selectionClick();
              s.toggleLanguage();
            },
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
              decoration: BoxDecoration(color: _surface, borderRadius: BorderRadius.circular(20), border: Border.all(color: _border)),
              child: Text(s.isTamil ? 'EN' : 'தமிழ்', style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700)),
            ),
          ),
          const SizedBox(width: 8),
          InkWell(
            borderRadius: BorderRadius.circular(20),
            onTap: () {
              HapticFeedback.selectionClick();
              s.toggleTheme();
            },
            child: Container(
              width: 36,
              height: 36,
              decoration: BoxDecoration(color: _surface, shape: BoxShape.circle, border: Border.all(color: _border)),
              child: Icon(s.isDark ? Icons.wb_sunny_outlined : Icons.dark_mode_outlined, size: 17, color: _accent),
            ),
          ),
          const SizedBox(width: 12),
        ],
      ),
      body: Stack(
        children: [
          IndexedStack(
            index: _tab,
            children: [
              _buildHomeTab(s),
              _buildStockTab(s),
              _buildBillsTab(s),
              _buildAdminTab(s),
            ],
          ),

          // Floating Live Cart Bar (Shopify POS / Swiggy style!)
          if (_quickCart.isNotEmpty)
            Positioned(
              left: 16,
              right: 16,
              bottom: 92,
              child: InkWell(
                borderRadius: BorderRadius.circular(18),
                onTap: () => _openQuickCheckoutDrawer(s),
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14),
                  decoration: BoxDecoration(
                    color: _ctaBg,
                    borderRadius: BorderRadius.circular(18),
                    boxShadow: const [BoxShadow(color: Colors.black45, blurRadius: 24, offset: Offset(0, 10))],
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        children: [
                          Container(
                            width: 26,
                            height: 26,
                            decoration: BoxDecoration(color: _accent, shape: BoxShape.circle),
                            alignment: Alignment.center,
                            child: Text('${_quickCart.length}', style: const TextStyle(color: Color(0xFF0A0B0E), fontWeight: FontWeight.w900, fontSize: 12)),
                          ),
                          const SizedBox(width: 10),
                          Text(
                            '${_quickCart.length} ${_quickCart.length == 1 ? 'item' : 'items'} in bill',
                            style: TextStyle(color: _ctaFg, fontWeight: FontWeight.w700, fontSize: 14),
                          ),
                        ],
                      ),
                      Row(
                        children: [
                          Text(formatInr(cartTotal), style: TextStyle(color: _ctaFg, fontWeight: FontWeight.w900, fontSize: 15)),
                          const SizedBox(width: 6),
                          Icon(Icons.arrow_forward_rounded, color: _ctaFg, size: 18),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ),

          // Floating Capsule Bottom Navigation Bar
          Positioned(
            left: 16,
            right: 16,
            bottom: 14,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
              decoration: BoxDecoration(
                color: _card.withAlpha(242),
                borderRadius: BorderRadius.circular(28),
                border: Border.all(color: _border),
                boxShadow: const [BoxShadow(color: Colors.black38, blurRadius: 24, offset: Offset(0, 10))],
              ),
              child: Row(
                children: [
                  _navItem(0, Icons.home_rounded, s.t('Home', 'முகப்பு')),
                  _navItem(1, Icons.checkroom_rounded, s.t('Stock', 'ஸ்டாக்')),
                  _navItem(2, Icons.receipt_long_rounded, s.t('Bills', 'பில்கள்')),
                  _navItem(3, Icons.tune_rounded, s.t('Admin', 'நிர்வாகம்')),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _navItem(int idx, IconData icon, String label) {
    final active = _tab == idx;
    return Expanded(
      child: InkWell(
        borderRadius: BorderRadius.circular(20),
        onTap: () {
          HapticFeedback.selectionClick();
          setState(() => _tab = idx);
        },
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 8),
          decoration: BoxDecoration(
            color: active ? _accent.withAlpha(34) : Colors.transparent,
            borderRadius: BorderRadius.circular(20),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(icon, size: 20, color: active ? _accent : _muted),
              const SizedBox(height: 3),
              Text(label, style: TextStyle(fontSize: 10, fontWeight: active ? FontWeight.w700 : FontWeight.w500, color: active ? _accent : _muted)),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildHomeTab(PosStore s) {
    final totalSales = s.sales.fold<double>(0, (a, b) => a + b.totalSellPrice);
    final totalProfit = s.sales.fold<double>(0, (a, b) => a + b.profit);
    final totalPcs = s.stock.fold<int>(0, (a, b) => a + b.qty);
    final khataDue = s.khata
        .where((k) => k['status'] != 'Paid')
        .fold<double>(0, (a, b) => a + ((b['amount'] as num? ?? 0).toDouble()));

    final recentSpots = <FlSpot>[];
    final last7 = s.sales.take(7).toList().reversed.toList();
    if (last7.isEmpty) {
      recentSpots.addAll(const [FlSpot(0, 0), FlSpot(1, 0), FlSpot(2, 0)]);
    } else {
      for (int i = 0; i < last7.length; i++) {
        recentSpots.add(FlSpot(i.toDouble(), last7[i].totalSellPrice));
      }
    }

    return ListView(
      padding: const EdgeInsets.fromLTRB(18, 12, 18, 160),
      children: [
        // Editorial Hero Card
        Card(
          child: Padding(
            padding: const EdgeInsets.all(22),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(s.t("Store Revenue", "மொத்த விற்பனை"), style: TextStyle(fontSize: 12, color: _muted, fontWeight: FontWeight.w500)),
                        const SizedBox(height: 4),
                        Text(
                          formatInr(totalSales),
                          style: const TextStyle(fontSize: 34, fontWeight: FontWeight.w900, letterSpacing: -1, fontFeatures: [FontFeature.tabularFigures()]),
                        ),
                      ],
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                      decoration: BoxDecoration(color: _green.withAlpha(32), borderRadius: BorderRadius.circular(20)),
                      child: Text('${s.sales.length} ${s.t('bills', 'பில்கள்')}', style: TextStyle(color: _green, fontSize: 11, fontWeight: FontWeight.w700)),
                    ),
                  ],
                ),
                const SizedBox(height: 18),
                Divider(color: _border, height: 1),
                const SizedBox(height: 16),
                Row(
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(s.t('Net Profit', 'நிகர லாபம்'), style: TextStyle(fontSize: 11, color: _muted)),
                          const SizedBox(height: 2),
                          Text(s.isAdmin ? formatInr(totalProfit) : '••••••', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: _accent)),
                        ],
                      ),
                    ),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(s.t('In-Stock', 'கையிருப்பு'), style: TextStyle(fontSize: 11, color: _muted)),
                          const SizedBox(height: 2),
                          Text('$totalPcs pcs', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
                        ],
                      ),
                    ),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(s.t('Khata Due', 'கடன் பாக்கி'), style: TextStyle(fontSize: 11, color: _muted)),
                          const SizedBox(height: 2),
                          Text(formatInr(khataDue), style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: _rose)),
                        ],
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 20),
                Row(
                  children: [
                    Expanded(
                      child: SizedBox(
                        height: 48,
                        child: ElevatedButton.icon(
                          style: ElevatedButton.styleFrom(
                            backgroundColor: _ctaBg,
                            foregroundColor: _ctaFg,
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                          ),
                          onPressed: () => setState(() => _tab = 1),
                          icon: const Icon(Icons.shopping_bag_outlined, size: 17),
                          label: Text(s.t('New Bill', 'புது பில்'), style: const TextStyle(fontWeight: FontWeight.w800)),
                        ),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: SizedBox(
                        height: 48,
                        child: OutlinedButton.icon(
                          style: OutlinedButton.styleFrom(
                            side: BorderSide(color: _border),
                            backgroundColor: _surface,
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                          ),
                          onPressed: () => _openAddStock(s),
                          icon: Icon(Icons.add_rounded, size: 18, color: _accent),
                          label: Text(s.t('Add Stock', 'ஸ்டாக் சேர்'), style: TextStyle(fontWeight: FontWeight.w700, color: s.isDark ? Colors.white : Colors.black)),
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 20),

        // Clean Horizontal Shop Tools Pill Strip
        Padding(
          padding: const EdgeInsets.only(left: 4, bottom: 10),
          child: Text(s.t('SHOP TOOLS', 'கடை கருவிகள்'), style: TextStyle(fontSize: 11, fontWeight: FontWeight.w700, letterSpacing: 1, color: _muted)),
        ),
        SizedBox(
          height: 48,
          child: ListView(
            scrollDirection: Axis.horizontal,
            children: [
              _toolPill(Icons.menu_book_rounded, s.t('Day-Book', 'தினசரி கணக்கு'), _green, () => showDayBookSheet(context, s)),
              _toolPill(Icons.account_balance_wallet_rounded, s.t('Khata Ledger', 'கடன் கணக்கு'), _accent, () => showKhataSheet(context, s)),
              _toolPill(Icons.content_cut_rounded, s.t('Alterations', 'டெய்லரிங்'), Colors.indigoAccent, () => showAlterationsSheet(context, s)),
              _toolPill(Icons.local_shipping_rounded, s.t('Suppliers', 'மொத்த பில்'), Colors.lightBlueAccent, () => showSuppliersSheet(context, s)),
              _toolPill(Icons.swap_horiz_rounded, s.t('Godown', 'குடோன்'), _accent, () => showGodownTransferSheet(context, s)),
              _toolPill(Icons.star_rounded, s.t('VIP Club', 'VIP கிளப்'), Colors.pinkAccent, () => showVipLoyaltySheet(context, s)),
            ],
          ),
        ),
        const SizedBox(height: 20),

        // Smooth Curved Champagne Line Chart
        Card(
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(s.t('Sales Trend', 'விற்பனை நிலவரம்'), style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
                    Text(s.t('Recent Bills', 'சமீபத்திய பில்கள்'), style: TextStyle(fontSize: 11, color: _accent, fontWeight: FontWeight.w600)),
                  ],
                ),
                const SizedBox(height: 16),
                SizedBox(
                  height: 150,
                  child: LineChart(
                    LineChartData(
                      gridData: const FlGridData(show: false),
                      borderData: FlBorderData(show: false),
                      titlesData: const FlTitlesData(show: false),
                      lineBarsData: [
                        LineChartBarData(
                          spots: recentSpots,
                          isCurved: true,
                          color: _accent,
                          barWidth: 3,
                          belowBarData: BarAreaData(show: true, color: _accent.withAlpha(32)),
                          dotData: const FlDotData(show: true),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _toolPill(IconData icon, String label, Color color, VoidCallback onTap) {
    return Padding(
      padding: const EdgeInsets.only(right: 10),
      child: InkWell(
        borderRadius: BorderRadius.circular(18),
        onTap: () {
          HapticFeedback.lightImpact();
          onTap();
        },
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          decoration: BoxDecoration(
            color: _card,
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: _border),
          ),
          child: Row(
            children: [
              Icon(icon, size: 16, color: color),
              const SizedBox(width: 8),
              Text(label, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700)),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildStockTab(PosStore s) {
    final q = _stockSearch.toLowerCase();
    final filtered = s.stock.where((i) {
      final matchCat = _stockCat == 'ALL' || i.category == _stockCat;
      final matchQ = q.isEmpty ||
          i.name.toLowerCase().contains(q) ||
          i.colourName.toLowerCase().contains(q) ||
          i.sizes.entries.any((e) => e.key.toLowerCase().contains(q) && e.value > 0);
      return matchCat && matchQ;
    }).toList();

    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(18, 12, 18, 10),
          child: TextField(
            decoration: InputDecoration(
              prefixIcon: const Icon(Icons.search_rounded, size: 20),
              hintText: s.t('Search garment, colour, size (M, 32)...', 'டிரஸ், கலர், சைஸ் தேடு...'),
            ),
            onChanged: (v) => setState(() => _stockSearch = v),
          ),
        ),
        SizedBox(
          height: 40,
          child: ListView(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 18),
            children: ['ALL', ...kCategories].map((c) {
              final act = _stockCat == c;
              return Padding(
                padding: const EdgeInsets.only(right: 8),
                child: InkWell(
                  borderRadius: BorderRadius.circular(20),
                  onTap: () => setState(() => _stockCat = c),
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      color: act ? _ctaBg : _surface,
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: _border),
                    ),
                    child: Text(c, style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: act ? _ctaFg : null)),
                  ),
                ),
              );
            }).toList(),
          ),
        ),
        const SizedBox(height: 10),
        Expanded(
          child: filtered.isEmpty
              ? Center(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.checkroom_rounded, size: 48, color: _muted),
                      const SizedBox(height: 8),
                      Text(s.t('No garments in stock yet', 'ஸ்டாக் எதுவும் இல்லை'), style: TextStyle(color: _muted, fontWeight: FontWeight.w600)),
                      const SizedBox(height: 12),
                      if (!s.isGuest)
                        ElevatedButton.icon(
                          style: ElevatedButton.styleFrom(backgroundColor: _ctaBg, foregroundColor: _ctaFg),
                          onPressed: () => _openAddStock(s),
                          icon: const Icon(Icons.add),
                          label: Text(s.t('Add First Garment', 'முதல் ஆடை சேர்')),
                        ),
                    ],
                  ),
                )
              : ListView.builder(
                  padding: const EdgeInsets.fromLTRB(18, 4, 18, 160),
                  itemCount: filtered.length,
                  itemBuilder: (_, idx) {
                    final item = filtered[idx];
                    final swColor = hexToColor(item.colour);
                    return Card(
                      margin: const EdgeInsets.only(bottom: 12),
                      child: Padding(
                        padding: const EdgeInsets.all(16),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                Container(
                                  width: 52,
                                  height: 52,
                                  decoration: BoxDecoration(
                                    color: swColor,
                                    borderRadius: BorderRadius.circular(16),
                                    border: Border.all(color: Colors.white24),
                                  ),
                                  child: const Icon(Icons.checkroom_rounded, color: Colors.white, size: 24),
                                ),
                                const SizedBox(width: 14),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Row(
                                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                        children: [
                                          Expanded(child: Text(item.name, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15), overflow: TextOverflow.ellipsis)),
                                          Text(formatInr(item.sellPrice), style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 15)),
                                        ],
                                      ),
                                      const SizedBox(height: 3),
                                      Text('${item.colourName.isNotEmpty ? item.colourName : item.category} • ${item.qty} pcs • ${item.location}', style: TextStyle(fontSize: 12, color: _muted)),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 12),
                            Wrap(
                              spacing: 8,
                              runSpacing: 8,
                              children: item.sizes.entries.map((e) {
                                final cnt = e.value;
                                final low = cnt > 0 && cnt <= 2;
                                return InkWell(
                                  borderRadius: BorderRadius.circular(12),
                                  onTap: cnt > 0 ? () => _addToQuickCart(s, item, e.key) : null,
                                  child: Container(
                                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
                                    decoration: BoxDecoration(
                                      color: _surface,
                                      borderRadius: BorderRadius.circular(12),
                                      border: Border.all(color: low ? _accent : _border),
                                    ),
                                    child: Row(
                                      mainAxisSize: MainAxisSize.min,
                                      children: [
                                        Text(e.key, style: TextStyle(fontWeight: FontWeight.w700, fontSize: 12, color: cnt == 0 ? _muted : null)),
                                        const SizedBox(width: 6),
                                        Text('$cnt', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 11, color: cnt == 0 ? _rose : (low ? _accent : _green))),
                                      ],
                                    ),
                                  ),
                                );
                              }).toList(),
                            ),
                            const SizedBox(height: 6),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.end,
                              children: [
                                IconButton(
                                  icon: Icon(Icons.share_outlined, size: 18, color: _green),
                                  onPressed: () {
                                    final avail = item.sizes.entries.where((e) => e.value > 0).map((e) => e.key).join(', ');
                                    openWhatsAppMessage('✨ UNIVO WEAR NEW ARRIVAL ✨\n👕 ${item.name}\n🎨 ${item.colourName}\n📏 Sizes: $avail\n🏷️ Price: ${formatInr(item.sellPrice)}');
                                  },
                                ),
                                if (s.isAdmin)
                                  IconButton(
                                    icon: Icon(Icons.edit_outlined, size: 18, color: _accent),
                                    onPressed: () => _openAddStock(s, existing: item),
                                  ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
        ),
      ],
    );
  }

  Widget _buildBillsTab(PosStore s) {
    final filtered = s.sales.where((sale) => _salesFilter == 'ALL' || sale.payment == _salesFilter).toList();
    final sum = filtered.fold<double>(0, (a, b) => a + b.totalSellPrice);

    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(18, 14, 18, 10),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(s.t('Bills Register', 'பில் பதிவேடு'), style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
                decoration: BoxDecoration(color: _green.withAlpha(30), borderRadius: BorderRadius.circular(20)),
                child: Text(formatInr(sum), style: TextStyle(color: _green, fontWeight: FontWeight.w800, fontSize: 13)),
              ),
            ],
          ),
        ),
        SizedBox(
          height: 38,
          child: ListView(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 18),
            children: ['ALL', ...kPaymentModes].map((p) {
              final act = _salesFilter == p;
              return Padding(
                padding: const EdgeInsets.only(right: 8),
                child: InkWell(
                  borderRadius: BorderRadius.circular(20),
                  onTap: () => setState(() => _salesFilter = p),
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 14),
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      color: act ? _ctaBg : _surface,
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: _border),
                    ),
                    child: Text(p, style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: act ? _ctaFg : null)),
                  ),
                ),
              );
            }).toList(),
          ),
        ),
        const SizedBox(height: 10),
        Expanded(
          child: ListView.builder(
            padding: const EdgeInsets.fromLTRB(18, 4, 18, 160),
            itemCount: filtered.length,
            itemBuilder: (_, idx) {
              final sale = filtered[idx];
              return Card(
                margin: const EdgeInsets.only(bottom: 10),
                child: ListTile(
                  contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                  title: Text(sale.itemName, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14), maxLines: 1, overflow: TextOverflow.ellipsis),
                  subtitle: Text('${sale.id} • ${sale.date} ${sale.time} • ${sale.payment}', style: TextStyle(fontSize: 11, color: _muted)),
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(formatInr(sale.totalSellPrice), style: TextStyle(fontWeight: FontWeight.w800, color: _green, fontSize: 14)),
                      IconButton(
                        icon: Icon(Icons.share_outlined, size: 18, color: _green),
                        onPressed: () => openWhatsAppMessage(
                          'UNIVO WEAR\nBill: ${sale.id} | ${sale.date}\nItem: ${sale.itemName}\nPaid: ${formatInr(sale.totalSellPrice)} (${sale.payment})',
                          phone: sale.customerPhone,
                        ),
                      ),
                      if (s.isAdmin)
                        IconButton(
                          icon: Icon(Icons.delete_outline_rounded, size: 18, color: _rose),
                          onPressed: () => s.refundSale(sale),
                        ),
                    ],
                  ),
                ),
              );
            },
          ),
        ),
      ],
    );
  }

  Widget _buildAdminTab(PosStore s) {
    final discCtrl = TextEditingController(text: s.maxStaffDiscount.toStringAsFixed(0));
    final commCtrl = TextEditingController(text: s.commissionPct.toStringAsFixed(1));
    return ListView(
      padding: const EdgeInsets.fromLTRB(18, 14, 18, 160),
      children: [
        Card(
          child: ListTile(
            contentPadding: const EdgeInsets.all(16),
            leading: Container(
              width: 48,
              height: 48,
              decoration: BoxDecoration(color: _accent.withAlpha(35), borderRadius: BorderRadius.circular(16)),
              child: Icon(Icons.verified_user_rounded, color: _accent),
            ),
            title: Text(s.userName, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
            subtitle: Text('${s.role.name.toUpperCase()} • ${s.userEmail}', style: TextStyle(color: _muted, fontSize: 12)),
            trailing: IconButton(icon: Icon(Icons.logout_rounded, color: _rose), onPressed: s.signOut),
          ),
        ),
        const SizedBox(height: 14),
        if (s.isAdmin) ...[
          Card(
            child: Padding(
              padding: const EdgeInsets.all(18),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Staff Counter Controls', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
                  Text('Changes sync immediately to all staff phones', style: TextStyle(fontSize: 12, color: _muted)),
                  const SizedBox(height: 16),
                  Row(
                    children: [
                      Expanded(child: TextField(controller: discCtrl, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Max Staff Bargain (₹)'))),
                      const SizedBox(width: 12),
                      Expanded(child: TextField(controller: commCtrl, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Staff Commission (%)'))),
                    ],
                  ),
                  const SizedBox(height: 16),
                  SizedBox(
                    width: double.infinity,
                    height: 48,
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: _ctaBg,
                        foregroundColor: _ctaFg,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                      ),
                      onPressed: () async {
                        final d = double.tryParse(discCtrl.text) ?? 200;
                        final c = double.tryParse(commCtrl.text) ?? 2;
                        await s.saveShopConfig(maxDisc: d < 0 ? 0 : d, commPct: c < 0 ? 0 : c);
                        if (mounted) {
                          ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Shop rules synced to all staff devices!')));
                        }
                      },
                      child: const Text('Save & Sync Shop Rules', style: TextStyle(fontWeight: FontWeight.w800)),
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 14),
          Card(
            child: ListTile(
              leading: Icon(Icons.delete_forever_rounded, color: _rose),
              title: Text('Clear All Cloud Data', style: TextStyle(color: _rose, fontWeight: FontWeight.w700)),
              onTap: () async {
                final ok = await showDialog<bool>(
                  context: context,
                  builder: (ctx) => AlertDialog(
                    title: const Text('Delete All Cloud Data?'),
                    content: const Text('All stock, sales, khata, and records will be permanently deleted.'),
                    actions: [
                      TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
                      ElevatedButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Delete All')),
                    ],
                  ),
                );
                if (ok == true) await s.clearAllCloudData();
              },
            ),
          ),
        ],
      ],
    );
  }
}
