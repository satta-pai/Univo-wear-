import 'dart:io' show File, InternetAddress, Platform, exit;
import 'package:path_provider/path_provider.dart';
import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:url_launcher/url_launcher.dart';
import 'dart:typed_data';
import 'dart:convert';
import 'package:intl/intl.dart';
import 'dart:async';
import 'dart:ui';
import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../core/app_theme.dart';
import '../core/constants.dart';
import '../models/pos_models.dart';
import '../services/pos_store.dart';
import '../sheets/add_stock_sheet.dart';
import '../sheets/pro_suite_sheets.dart';
import '../sheets/receipt_png_sheet.dart';
import '../sheets/old_bills_pdf_sheet.dart';
import '../sheets/app_updater_sheet.dart';
import '../sheets/smart_erp_sheet.dart';
import '../sheets/gst_multishop_sheet.dart';
import '../sheets/how_to_use_sheet.dart';
import '../sheets/out_of_stock_sheet.dart';
import '../sheets/live_tour_overlay.dart';
import 'calculator_screen.dart';

class HomeShell extends StatefulWidget {
  final PosStore store;
  const HomeShell({super.key, required this.store});

  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int _tab = 0;
  String _stockSearch = '';
  String _stockCat = 'ALL';
  bool _stockGridView = false;
  final Map<String, String> _selectedColourByGroup = {};

  String _baseDesignName(StockItem item) {
    final n = item.name.trim();
    final c = item.colourName.trim();
    if (c.isNotEmpty && n.toLowerCase().endsWith(' - ${c.toLowerCase()}')) {
      return n.substring(0, n.length - (' - $c').length).trim();
    }
    return n;
  }
  static final Map<String, Uint8List> _photoCache = {};

  Uint8List? _decodePhoto(String id, String b64) {
    if (b64.isEmpty) return null;
    final key = '$id:${b64.length}';
    final cached = _photoCache[key];
    if (cached != null) return cached;
    try {
      if (_photoCache.length > 60) _photoCache.clear();
      final bytes = base64Decode(b64);
      _photoCache[key] = bytes;
      return bytes;
    } catch (_) {
      return null;
    }
  }
  String _salesSearch = '';
  String _salesFilter = 'ALL';
  String _billsWindowMode = 'TODAY';
  String _periodMode = 'TODAY';
  String _chartMode = 'WEEK';
  DateTime _now = DateTime.now();
  Timer? _clockTimer;
  Timer? _netTimer;
  bool _isOffline = false;
  bool _showBackOnline = false;
  bool _monthlyAlertChecked = false;
  final List<int> _tabHistory = [0];
  DateTime? _lastBackPress;
  bool _tourChecked = false;

  // Live Spotlight Arrow Tour GlobalKeys
  final GlobalKey _keyLangBtn = GlobalKey();
  final GlobalKey _keyBulbBtn = GlobalKey();
  final GlobalKey _keyThemeBtn = GlobalKey();
  final GlobalKey _keyHomeKpi = GlobalKey();
  final GlobalKey _keyHomeNewBill = GlobalKey();
  final GlobalKey _keyHomeTools = GlobalKey();
  final GlobalKey _keyMobileNav = GlobalKey();
  final GlobalKey _keyDesktopSidebar = GlobalKey();
  final GlobalKey _keyStockSearch = GlobalKey();
  final GlobalKey _keyBillsHeader = GlobalKey();
  final GlobalKey _keyBillsSearch = GlobalKey();
  final GlobalKey _keyAdminProfile = GlobalKey();

  bool get _isWindowsDesktop => !kIsWeb && (Platform.isWindows || Platform.isLinux || Platform.isMacOS);

  void _goToTab(int idx) {
    if (_tab == idx) return;
    setState(() {
      _tab = idx;
      if (_tabHistory.isEmpty || _tabHistory.last != idx) {
        _tabHistory.add(idx);
        if (_tabHistory.length > 25) _tabHistory.removeAt(0);
      }
    });
  }

  Future<void> _handleBackNavigation(PosStore s) async {
    if (_tabHistory.length > 1) {
      setState(() {
        _tabHistory.removeLast();
        _tab = _tabHistory.last;
      });
      return;
    }
    if (_tab != 0) {
      setState(() {
        _tab = 0;
        _tabHistory
          ..clear()
          ..add(0);
      });
      return;
    }
    final now = DateTime.now();
    if (_lastBackPress == null || now.difference(_lastBackPress!) > const Duration(seconds: 2)) {
      _lastBackPress = now;
      if (!mounted) return;
      ScaffoldMessenger.of(context).hideCurrentSnackBar();
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          duration: const Duration(seconds: 2),
          content: Text(
            _isWindowsDesktop
                ? s.t('Press Esc again to exit UNIVO WEAR', 'வெளியேற மீண்டும் Esc அழுத்தவும்')
                : s.t('Press Back again to exit UNIVO WEAR', 'வெளியேற மீண்டும் Back அழுத்தவும்'),
          ),
        ),
      );
      return;
    }
    _lastBackPress = null;
    await _showExitConfirmDialog(s);
  }

  Future<void> _showExitConfirmDialog(PosStore s) async {
    if (!mounted) return;
    final shouldExit = await showDialog<bool>(
      context: context,
      builder: (dCtx) => AlertDialog(
        title: Row(
          children: [
            if (_tabHistory.length > 1) ...[
              Tooltip(
                message: _isWindowsDesktop ? 'Back (Esc)' : s.t('Back', 'பின்'),
                child: InkWell(
                  borderRadius: BorderRadius.circular(18),
                  onTap: () => _handleBackNavigation(s),
                  child: Container(
                    width: 34,
                    height: 34,
                    margin: const EdgeInsets.only(right: 8),
                    decoration: BoxDecoration(
                      color: _surface,
                      shape: BoxShape.circle,
                      border: Border.all(color: _border),
                    ),
                    child: Icon(Icons.arrow_back_rounded, size: 17, color: _accent),
                  ),
                ),
              ),
            ],
            Icon(Icons.exit_to_app_rounded, color: _rose),
            const SizedBox(width: 8),
            Expanded(child: Text(s.t('Exit UNIVO WEAR?', 'UNIVO WEAR-லிருந்து வெளியேறவா?'), style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800))),
          ],
        ),
        content: Text(
          s.t('Are you sure you want to close the app?', 'செயலியை மூடி வெளியேற விரும்புகிறீர்களா?'),
          style: const TextStyle(fontSize: 13),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dCtx, false),
            child: Text(s.t('Cancel', 'ரத்து')),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: _rose, foregroundColor: Colors.white),
            onPressed: () => Navigator.pop(dCtx, true),
            child: Text(s.t('Exit App', 'வெளியேறு')),
          ),
        ],
      ),
    );
    if (shouldExit == true) {
      if (_isWindowsDesktop) {
        exit(0);
      } else {
        SystemNavigator.pop();
      }
    }
  }

  Future<void> _maybeRunFirstTimeTour() async {
    if (_tourChecked || kIsWeb) return;
    _tourChecked = true;
    try {
      final dir = await getApplicationDocumentsDirectory();
      final flagFile = File('${dir.path}${Platform.pathSeparator}univo_live_tour_seen_v45.flag');
      if (await flagFile.exists()) return;
      await flagFile.writeAsString('seen');
      if (!mounted) return;
      await Future.delayed(const Duration(milliseconds: 900));
      if (!mounted) return;
      _showLivePageBulbTip(widget.store);
    } catch (_) {}
  }
  final List<CartLine> _quickCart = [];
  final List<Map<String, dynamic>> _heldCarts = [];
  late final TextEditingController _discCtrl;
  late final TextEditingController _commCtrl;

  @override
  void initState() {
    super.initState();
    _discCtrl = TextEditingController(text: widget.store.maxStaffDiscount.toStringAsFixed(0));
    _commCtrl = TextEditingController(text: widget.store.commissionPct.toStringAsFixed(1));
    _clockTimer = Timer.periodic(const Duration(seconds: 30), (_) {
      final n = DateTime.now();
      if (mounted && (n.minute != _now.minute || n.day != _now.day)) {
        setState(() => _now = n);
      }
    });
    Future.delayed(const Duration(seconds: 3), _checkMonthlyBillsLifecycle);
    Future.delayed(const Duration(seconds: 4), _runStartupUpdateCheck);
    _startConnectivityMonitor();
    WidgetsBinding.instance.addPostFrameCallback((_) => _maybeRunFirstTimeTour());
  }

  Future<void> _checkConnectivityOnce() async {
    if (kIsWeb) return;
    bool nowOffline = false;
    try {
      final res = await InternetAddress.lookup('clients3.google.com').timeout(const Duration(seconds: 3));
      nowOffline = res.isEmpty || res.first.rawAddress.isEmpty;
    } catch (_) {
      nowOffline = true;
    }
    if (!mounted) return;
    if (nowOffline && !_isOffline) {
      setState(() {
        _isOffline = true;
        _showBackOnline = false;
      });
    } else if (!nowOffline && _isOffline) {
      setState(() {
        _isOffline = false;
        _showBackOnline = true;
      });
      Future.delayed(const Duration(seconds: 3), () {
        if (mounted) setState(() => _showBackOnline = false);
      });
    }
  }

  void _startConnectivityMonitor() {
    if (kIsWeb) return;
    _checkConnectivityOnce();
    _netTimer = Timer.periodic(const Duration(seconds: 5), (_) => _checkConnectivityOnce());
  }

  Future<void> _runStartupUpdateCheck() async {
    await cleanOldApkCache();
    if (!mounted) return;
    final info = await checkForAppUpdate(widget.store);
    if (info != null && mounted) {
      await showUpdateAvailableSheet(context, widget.store, info);
    }
  }

  Future<void> _checkMonthlyBillsLifecycle() async {
    if (!mounted || _monthlyAlertChecked) return;
    final s = widget.store;
    if (!s.isAdmin) return;
    _monthlyAlertChecked = true;
    final deleted = await s.runMonthlyAutoCleanupIfNeeded((expired, label) async {
      final res = await generateAndSaveBillsPdf(
        bills: expired,
        periodLabel: label,
        generatedBy: s.userName,
      );
      return res.fileName;
    });
    if (deleted > 0 && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Monthly Auto-Cleanup: $deleted old bills cleared (Backup PDF saved to storage!)')),
      );
    }
    if (mounted && s.isWithin3DayDeleteWarning) {
      await showDeleteWarningPopupIfNeeded(context, s);
    }
  }

  @override
  void dispose() {
    _clockTimer?.cancel();
    _netTimer?.cancel();
    _discCtrl.dispose();
    _commCtrl.dispose();
    super.dispose();
  }

  List<SaleRecord> _salesForPeriod(PosStore s) {
    final todayIso = DateFormat('yyyy-MM-dd').format(_now);
    final monthPrefix = DateFormat('yyyy-MM').format(_now);
    if (_periodMode == 'TODAY') {
      return s.sales.where((x) => x.date == todayIso || x.createdAt.startsWith(todayIso)).toList();
    } else if (_periodMode == 'MONTH') {
      return s.sales.where((x) => x.date.startsWith(monthPrefix) || x.createdAt.startsWith(monthPrefix)).toList();
    }
    return s.sales;
  }

  Color get _accent => widget.store.isDark ? AppTheme.gold : AppTheme.goldLightMode;
  Color get _green => widget.store.isDark ? AppTheme.green : AppTheme.greenLightMode;
  Color get _rose => widget.store.isDark ? AppTheme.rose : AppTheme.roseLightMode;
  Color get _surface => widget.store.isDark ? AppTheme.darkSurface : AppTheme.lightSurface;
  Color get _card => widget.store.isDark ? AppTheme.darkCard : AppTheme.lightCard;
  Color get _border => widget.store.isDark ? AppTheme.darkBorder : AppTheme.lightBorder;
  Color get _ctaBg => widget.store.isDark ? const Color(0xFFF8FAFC) : const Color(0xFF111318);
  Color get _ctaFg => widget.store.isDark ? const Color(0xFF0A0B0E) : Colors.white;
  Color get _muted => widget.store.isDark ? const Color(0xFF8B92A5) : const Color(0xFF667085);

  void _openAddStock(PosStore s, {StockItem? existing}) {
    if (s.isGuest) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Guest Mode is View Only! Sign in to add stock.')),
      );
      return;
    }
    HapticFeedback.lightImpact();
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(28))),
      builder: (_) => AddStockSheet(store: s, existing: existing),
    );
  }


  void _addToQuickCart(PosStore s, StockItem item, String sz) {
    if (s.isGuest) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Guest Mode is View Only! Sign in to bill.')),
      );
      return;
    }
    final already = _quickCart.where((c) => c.stockId == item.id && c.size == sz).fold<int>(0, (a, b) => a + b.qty);
    final avail = (item.sizes[sz] ?? 0) - already;
    if (avail <= 0) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('No more $sz left in stock')));
      return;
    }
    HapticFeedback.lightImpact();
    setState(() {
      _quickCart.add(CartLine(
        stockId: item.id,
        itemName: item.name,
        hsnCode: item.hsnCode,
        size: sz,
        qty: 1,
        unitMrp: item.sellPrice,
        unitSellPrice: item.sellPrice,
        costPrice: item.costPrice,
      ));
    });
  }

  void _openQuickCheckoutDrawer(PosStore s) {
    if (_quickCart.isEmpty) {
      _goToTab(1);
      return;
    }
    final initSub = _quickCart.fold<double>(0, (a, b) => a + b.totalSellPrice);
    final autoPromoOff = (s.promoEnabled && initSub >= s.promoMinBill)
        ? (initSub * s.promoDiscountPct / 100).roundToDouble()
        : 0.0;
    final checkoutDiscCtrl = TextEditingController(text: autoPromoOff.toStringAsFixed(0));
    final finalPriceCtrl = TextEditingController(text: ((initSub - autoPromoOff) < 0 ? 0 : (initSub - autoPromoOff)).toStringAsFixed(0));
    final phoneCtrl = TextEditingController();
    final cashGivenCtrl = TextEditingController();
    final nameCtrl = TextEditingController();
    String payment = 'UPI / GPay';
    bool gst = false;
    bool submitting = false;

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(28))),
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setSt) {
          final sub = _quickCart.fold<double>(0, (a, b) => a + b.totalSellPrice);
          final disc = double.tryParse(checkoutDiscCtrl.text) ?? 0;
          final afterDisc = (sub - disc) < 0 ? 0.0 : (sub - disc);
          final gstAmt = gst ? (afterDisc * 0.05).roundToDouble() : 0.0;
          final payable = afterDisc + gstAmt;

          return Padding(
            padding: EdgeInsets.only(left: 20, right: 20, top: 16, bottom: MediaQuery.of(ctx).viewInsets.bottom + 24),
            child: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Center(child: Container(width: 40, height: 4, decoration: BoxDecoration(color: _muted.withAlpha(80), borderRadius: BorderRadius.circular(8)))),
                  const SizedBox(height: 14),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text('Checkout (${_quickCart.length} items)', style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
                      Row(
                        children: [
                          TextButton.icon(
                            onPressed: () {
                              final label = nameCtrl.text.trim().isNotEmpty
                                  ? nameCtrl.text.trim()
                                  : 'Trial #${_heldCarts.length + 1}';
                              setState(() {
                                _heldCarts.add({
                                  'label': label,
                                  'time': DateFormat('hh:mm a').format(DateTime.now()),
                                  'items': List<CartLine>.from(_quickCart),
                                });
                                _quickCart.clear();
                              });
                              Navigator.pop(ctx);
                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(content: Text('Bill parked ($label). Tap Held badge to resume!')),
                              );
                            },
                            icon: Icon(Icons.pause_circle_outline_rounded, size: 16, color: _accent),
                            label: Text('Hold', style: TextStyle(color: _accent, fontWeight: FontWeight.w700)),
                          ),
                          TextButton(
                            onPressed: () async {
                              final ok = await showDialog<bool>(
                                context: ctx,
                                builder: (dCtx) => AlertDialog(
                                  title: const Text('Clear Cart?'),
                                  content: const Text('Remove all items from this bill?'),
                                  actions: [
                                    TextButton(onPressed: () => Navigator.pop(dCtx, false), child: const Text('Cancel')),
                                    ElevatedButton(onPressed: () => Navigator.pop(dCtx, true), child: const Text('Clear')),
                                  ],
                                ),
                              );
                              if (ok == true) {
                                setState(() => _quickCart.clear());
                                if (ctx.mounted) Navigator.pop(ctx);
                              }
                            },
                            child: Text('Clear', style: TextStyle(color: _rose)),
                          ),
                        ],
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  ..._quickCart.asMap().entries.map((entry) => Container(
                        margin: const EdgeInsets.only(bottom: 8),
                        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                        decoration: BoxDecoration(color: _surface, borderRadius: BorderRadius.circular(16), border: Border.all(color: _border)),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Expanded(
                              child: Text('${entry.value.itemName} (${entry.value.size})', style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13)),
                            ),
                            Text(formatInr(entry.value.totalSellPrice), style: const TextStyle(fontWeight: FontWeight.w800)),
                            IconButton(
                              icon: Icon(Icons.close, size: 16, color: _rose),
                              onPressed: () {
                                setState(() => _quickCart.removeAt(entry.key));
                                if (_quickCart.isEmpty) {
                                  Navigator.pop(ctx);
                                } else {
                                  setSt(() {});
                                }
                              },
                            ),
                          ],
                        ),
                      )),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      Expanded(
                        child: TextField(
                          controller: checkoutDiscCtrl,
                          keyboardType: TextInputType.number,
                          decoration: const InputDecoration(labelText: 'Less / Reduce (₹)'),
                          onChanged: (v) {
                            final d = double.tryParse(v) ?? 0;
                            final f = (sub - d) < 0 ? 0.0 : (sub - d);
                            finalPriceCtrl.text = f.toStringAsFixed(0);
                            setSt(() {});
                          },
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: TextField(
                          controller: finalPriceCtrl,
                          keyboardType: TextInputType.number,
                          decoration: const InputDecoration(labelText: 'Final Price (₹)'),
                          onChanged: (v) {
                            final f = double.tryParse(v) ?? sub;
                            final d = (sub - f) < 0 ? 0.0 : (sub - f);
                            checkoutDiscCtrl.text = d.toStringAsFixed(0);
                            setSt(() {});
                          },
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  DropdownButtonFormField<String>(
                    initialValue: payment,
                    decoration: const InputDecoration(labelText: 'Payment Mode'),
                    items: kPaymentModes.map((m) => DropdownMenuItem(value: m, child: Text(m))).toList(),
                    onChanged: (v) {
                      if (v != null) setSt(() => payment = v);
                    },
                  ),
                  if (payment == 'Cash') ...[
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        Expanded(
                          child: TextField(
                            controller: cashGivenCtrl,
                            keyboardType: TextInputType.number,
                            decoration: const InputDecoration(labelText: 'Cash Given (₹)'),
                            onChanged: (_) => setSt(() {}),
                          ),
                        ),
                        const SizedBox(width: 10),
                        Builder(builder: (_) {
                          final given = double.tryParse(cashGivenCtrl.text) ?? 0;
                          final change = given - payable;
                          return Container(
                            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                            decoration: BoxDecoration(
                              color: (change >= 0 && given > 0 ? _green : _surface).withAlpha(35),
                              borderRadius: BorderRadius.circular(12),
                              border: Border.all(color: _border),
                            ),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.end,
                              children: [
                                Text('Return Change', style: TextStyle(fontSize: 9.5, color: _muted)),
                                Text(
                                  given <= 0 ? '₹0' : (change >= 0 ? formatInr(change) : 'Short ${formatInr(-change)}'),
                                  style: TextStyle(
                                    fontWeight: FontWeight.w900,
                                    fontSize: 13,
                                    color: given <= 0 ? _muted : (change >= 0 ? _green : _rose),
                                  ),
                                ),
                              ],
                            ),
                          );
                        }),
                      ],
                    ),
                    const SizedBox(height: 6),
                    Wrap(
                      spacing: 6,
                      children: [
                        ActionChip(
                          label: const Text('Exact', style: TextStyle(fontSize: 10.5, fontWeight: FontWeight.bold)),
                          onPressed: () => setSt(() => cashGivenCtrl.text = payable.toStringAsFixed(0)),
                        ),
                        ...[500, 1000, 2000].map((note) => ActionChip(
                              label: Text('₹$note', style: const TextStyle(fontSize: 10.5, fontWeight: FontWeight.bold)),
                              onPressed: () => setSt(() => cashGivenCtrl.text = '$note'),
                            )),
                      ],
                    ),
                  ],
                  const SizedBox(height: 8),
                  Wrap(
                    spacing: 6,
                    children: [50, 100, 200].map((amt) => ActionChip(
                      label: Text('-₹$amt', style: const TextStyle(fontSize: 11, fontWeight: FontWeight.bold)),
                      onPressed: () {
                        checkoutDiscCtrl.text = '$amt';
                        finalPriceCtrl.text = ((sub - amt) < 0 ? 0 : (sub - amt)).toStringAsFixed(0);
                        setSt(() {});
                      },
                    )).toList()
                      ..add(ActionChip(
                        label: const Text('-10%', style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold)),
                        onPressed: () {
                          final d10 = (sub * 0.10).round();
                          checkoutDiscCtrl.text = '$d10';
                          finalPriceCtrl.text = ((sub - d10) < 0 ? 0 : (sub - d10)).toStringAsFixed(0);
                          setSt(() {});
                        },
                      )),
                  ),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      Expanded(
                        child: TextField(
                          controller: phoneCtrl,
                          keyboardType: TextInputType.phone,
                          decoration: const InputDecoration(labelText: 'Customer Mobile'),
                          onChanged: (ph) {
                            final found = s.customers.where((c) => c['phone'] == ph.trim()).toList();
                            if (found.isNotEmpty && nameCtrl.text.isEmpty) {
                              nameCtrl.text = (found.first['name'] ?? '').toString();
                            }
                            setSt(() {});
                          },
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(child: TextField(controller: nameCtrl, decoration: const InputDecoration(labelText: 'Customer Name'))),
                    ],
                  ),
                  CheckboxListTile(
                    contentPadding: EdgeInsets.zero,
                    title: const Text('Include GST (CGST + SGST)', style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
                    value: gst,
                    onChanged: (v) => setSt(() => gst = v ?? false),
                  ),
                  const Divider(),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text('Total Payable', style: TextStyle(color: _muted, fontWeight: FontWeight.w600)),
                      Text(formatInr(payable), style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900, color: _green)),
                    ],
                  ),
                  const SizedBox(height: 14),
                  SizedBox(
                    width: double.infinity,
                    height: 52,
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: _ctaBg,
                        foregroundColor: _ctaFg,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                      ),
                      onPressed: submitting
                          ? null
                          : () async {
                              final totalCost = _quickCart.fold<double>(0, (a, b) => a + (b.costPrice * b.qty));
                              if (!s.isAdmin) {
                                if (afterDisc < totalCost) {
                                  ScaffoldMessenger.of(context).showSnackBar(
                                    const SnackBar(content: Text('Blocked: Staff cannot sell below Cost Price! Owner required.')),
                                  );
                                  return;
                                }
                                if (disc > s.maxStaffDiscount * _quickCart.length) {
                                  ScaffoldMessenger.of(context).showSnackBar(
                                    SnackBar(content: Text('Blocked: Max staff discount is ₹${s.maxStaffDiscount.toStringAsFixed(0)}/item')),
                                  );
                                  return;
                                }
                              }
                              setSt(() => submitting = true);
                              try {
                                final ratio = sub > 0 ? (afterDisc / sub) : 1.0;
                                final adjustedLines = _quickCart
                                    .map((c) => CartLine(
                                          stockId: c.stockId,
                                          itemName: c.itemName,
                                          hsnCode: c.hsnCode,
                                          size: c.size,
                                          qty: c.qty,
                                          unitMrp: c.unitMrp,
                                          unitSellPrice: (c.unitSellPrice * ratio).roundToDouble(),
                                          costPrice: c.costPrice,
                                        ))
                                    .toList();
                                final createdSale = await s.completeSale(
                                  lines: adjustedLines,
                                  payment: payment,
                                  gstEnabled: gst,
                                  customerName: nameCtrl.text,
                                  customerPhone: phoneCtrl.text,
                                );
                                setState(() => _quickCart.clear());
                                if (ctx.mounted) Navigator.pop(ctx);
                                if (mounted) {
                                  showBillReceiptPngSheet(context, s, createdSale);
                                }
                              } catch (e) {
                                setSt(() => submitting = false);
                                if (mounted) {
                                  ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Bill sync failed: $e')));
                                }
                              }
                            },
                      child: submitting
                          ? SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2, color: _ctaFg))
                          : const Text('Complete Bill & Save', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 14)),
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final s = widget.store;
    final cartTotal = _quickCart.fold<double>(0, (a, b) => a + b.totalSellPrice);

    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, _) {
        if (!didPop) _handleBackNavigation(s);
      },
      child: CallbackShortcuts(
        bindings: <ShortcutActivator, VoidCallback>{
          const SingleActivator(LogicalKeyboardKey.digit1, control: true): () => _goToTab(0),
          const SingleActivator(LogicalKeyboardKey.digit2, control: true): () => _goToTab(1),
          const SingleActivator(LogicalKeyboardKey.digit3, control: true): () => _goToTab(2),
          const SingleActivator(LogicalKeyboardKey.digit4, control: true): () => _goToTab(3),
          const SingleActivator(LogicalKeyboardKey.keyN, control: true): () {
            if (s.isAdmin) _openAddStock(s);
          },
          const SingleActivator(LogicalKeyboardKey.keyB, control: true): () {
            if (_quickCart.isNotEmpty) {
              _openQuickCheckoutDrawer(s);
            } else {
              _goToTab(1);
            }
          },
          const SingleActivator(LogicalKeyboardKey.keyK, control: true): () {
            Navigator.push(context, MaterialPageRoute(builder: (_) => ShopCalculatorScreen(store: s)));
          },
          const SingleActivator(LogicalKeyboardKey.keyT, control: true): () => s.toggleTheme(),
          const SingleActivator(LogicalKeyboardKey.keyL, control: true): () => s.toggleLanguage(),
          const SingleActivator(LogicalKeyboardKey.f1): () => _showLivePageBulbTip(s),
          const SingleActivator(LogicalKeyboardKey.escape): () => _handleBackNavigation(s),
          const SingleActivator(LogicalKeyboardKey.keyQ, control: true): () => _showExitConfirmDialog(s),
        },
        child: Focus(
          autofocus: true,
          child: Scaffold(
      appBar: AppBar(
        toolbarHeight: 66,
        title: Row(
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(12),
              child: Image.asset('assets/images/univo_logo.png', width: 42, height: 42, fit: BoxFit.cover),
            ),
            const SizedBox(width: 12),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    const Text('UNIVO WEAR', style: TextStyle(fontWeight: FontWeight.w800, letterSpacing: 1.2, fontSize: 16, fontFamily: 'Georgia')),
                    const SizedBox(width: 8),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                      decoration: BoxDecoration(
                        color: _accent.withAlpha(34),
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Text(
                        s.role.name.toUpperCase(),
                        style: TextStyle(color: _accent, fontSize: 9, fontWeight: FontWeight.w800),
                      ),
                    ),
                  ],
                ),
                Text(s.userName, style: TextStyle(fontSize: 11.5, fontWeight: FontWeight.w600, color: _muted)),
              ],
            ),
          ],
        ),
        actions: [
          Tooltip(
            message: _isWindowsDesktop ? 'Language (Ctrl+L)' : 'English / தமிழ்',
            child: InkWell(
            key: _keyLangBtn,
            borderRadius: BorderRadius.circular(20),
            onTap: () {
              HapticFeedback.selectionClick();
              s.toggleLanguage();
            },
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
              decoration: BoxDecoration(color: _surface, borderRadius: BorderRadius.circular(20), border: Border.all(color: _border)),
              child: Text(s.isTamil ? 'EN' : 'தமிழ்', style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700)),
            ),
          ),
          ),
          const SizedBox(width: 8),
          Tooltip(
            message: _isWindowsDesktop ? 'Live Step-by-Step Guide (F1)' : s.t('Live Page Guide', 'லைவ் வழிகாட்டி'),
            child: InkWell(
            key: _keyBulbBtn,
            borderRadius: BorderRadius.circular(20),
            onTap: () {
              HapticFeedback.selectionClick();
              _showLivePageBulbTip(s);
            },
            child: Container(
              width: 36,
              height: 36,
              decoration: BoxDecoration(color: _surface, shape: BoxShape.circle, border: Border.all(color: _accent.withAlpha(110))),
              child: Icon(Icons.lightbulb_outline_rounded, size: 18, color: _accent),
            ),
          ),
          ),
          if (s.isAdmin) ...[
            const SizedBox(width: 8),
            InkWell(
              borderRadius: BorderRadius.circular(20),
              onTap: () {
                HapticFeedback.selectionClick();
                showOldBillsArchiveSheet(context, s);
              },
              child: Stack(
                clipBehavior: Clip.none,
                children: [
                  Container(
                    width: 36,
                    height: 36,
                    decoration: BoxDecoration(color: _surface, shape: BoxShape.circle, border: Border.all(color: _border)),
                    child: Icon(
                      s.isWithin3DayDeleteWarning ? Icons.notifications_active_rounded : Icons.notifications_none_rounded,
                      size: 17,
                      color: s.isWithin3DayDeleteWarning ? _rose : _accent,
                    ),
                  ),
                  if (s.isWithin3DayDeleteWarning)
                    Positioned(
                      right: 2,
                      top: 2,
                      child: Container(
                        width: 9,
                        height: 9,
                        decoration: BoxDecoration(color: _rose, shape: BoxShape.circle, border: Border.all(color: _surface, width: 1.5)),
                      ),
                    ),
                ],
              ),
            ),
          ],
          const SizedBox(width: 8),
          Tooltip(
            message: _isWindowsDesktop ? 'Theme (Ctrl+T)' : s.t('Theme', 'தீம்'),
            child: InkWell(
            key: _keyThemeBtn,
            borderRadius: BorderRadius.circular(20),
            onTap: () {
              HapticFeedback.selectionClick();
              s.toggleTheme();
            },
            child: Container(
              width: 36,
              height: 36,
              decoration: BoxDecoration(color: _surface, shape: BoxShape.circle, border: Border.all(color: _border)),
              child: Icon(s.isDark ? Icons.wb_sunny_outlined : Icons.dark_mode_outlined, size: 17, color: _accent),
            ),
          ),
          ),
          const SizedBox(width: 12),
        ],
      ),
      body: Column(
        children: [
          AnimatedSize(
            duration: const Duration(milliseconds: 260),
            curve: Curves.easeInOut,
            child: (_isOffline || _showBackOnline)
                ? Container(
                    width: double.infinity,
                    padding: const EdgeInsets.symmetric(vertical: 7, horizontal: 14),
                    decoration: BoxDecoration(
                      color: _isOffline ? const Color(0xFFDC2626) : const Color(0xFF059669),
                      boxShadow: const [BoxShadow(color: Colors.black26, blurRadius: 6, offset: Offset(0, 2))],
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(
                          _isOffline ? Icons.wifi_off_rounded : Icons.wifi_rounded,
                          size: 15,
                          color: Colors.white,
                        ),
                        const SizedBox(width: 8),
                        Flexible(
                          child: Text(
                            _isOffline
                                ? s.t('You are offline • Saved locally', 'இணையம் இல்லை (Offline) • லோக்கலில் சேமிக்கப்படும்')
                                : s.t('Back online • Cloud synced', 'இணையம் இணைந்தது (Back Online) • சிங்க் ஆனது'),
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 12,
                              fontWeight: FontWeight.w800,
                              letterSpacing: 0.2,
                            ),
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                      ],
                    ),
                  )
                : const SizedBox.shrink(),
          ),
          Expanded(
            child: LayoutBuilder(
              builder: (context, constraints) {
          final isDesktop = constraints.maxWidth >= 840;
          final mainStack = Stack(
            children: [
              Center(
                child: ConstrainedBox(
                  constraints: BoxConstraints(maxWidth: isDesktop ? 1160 : double.infinity),
                  child: IndexedStack(
                    index: _tab,
                    children: [
                      _buildHomeTab(s),
                      _buildStockTab(s),
                      _buildBillsTab(s),
                      _buildAdminTab(s),
                    ],
                  ),
                ),
              ),

              // Floating Live Cart Bar (Docked right on Desktop, full-width on Mobile)
              if (_quickCart.isNotEmpty)
                Positioned(
                  left: isDesktop ? null : 16,
                  right: isDesktop ? 24 : 16,
                  width: isDesktop ? 360 : null,
                  bottom: isDesktop ? 22 : 92,
              child: InkWell(
                borderRadius: BorderRadius.circular(18),
                onTap: () => _openQuickCheckoutDrawer(s),
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14),
                  decoration: BoxDecoration(
                    color: _ctaBg,
                    borderRadius: BorderRadius.circular(18),
                    boxShadow: const [BoxShadow(color: Colors.black45, blurRadius: 24, offset: Offset(0, 10))],
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        children: [
                          Container(
                            width: 26,
                            height: 26,
                            decoration: BoxDecoration(color: _accent, shape: BoxShape.circle),
                            alignment: Alignment.center,
                            child: Text('${_quickCart.length}', style: const TextStyle(color: Color(0xFF0A0B0E), fontWeight: FontWeight.w900, fontSize: 12)),
                          ),
                          const SizedBox(width: 10),
                          Text(
                            '${_quickCart.length} ${_quickCart.length == 1 ? 'item' : 'items'} in bill',
                            style: TextStyle(color: _ctaFg, fontWeight: FontWeight.w700, fontSize: 14),
                          ),
                        ],
                      ),
                      Row(
                        children: [
                          Text(formatInr(cartTotal), style: TextStyle(color: _ctaFg, fontWeight: FontWeight.w900, fontSize: 15)),
                          const SizedBox(width: 6),
                          Icon(Icons.arrow_forward_rounded, color: _ctaFg, size: 18),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ),

              // Floating Capsule Bottom Navigation Bar (Mobile Only)
              if (!isDesktop)
                Positioned(
                  left: 16,
                  right: 16,
                  bottom: 14,
                  child: Container(
                    key: _keyMobileNav,
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
                    decoration: BoxDecoration(
                      color: _card.withAlpha(242),
                      borderRadius: BorderRadius.circular(28),
                      border: Border.all(color: _border),
                      boxShadow: const [BoxShadow(color: Colors.black38, blurRadius: 20, offset: Offset(0, 8))],
                    ),
                    child: Row(
                      children: [
                        _navItem(0, Icons.home_rounded, s.t('Home', 'முகப்பு')),
                        _navItem(1, Icons.checkroom_rounded, s.t('Stock', 'ஸ்டாக்')),
                        _navItem(2, Icons.receipt_long_rounded, s.t('Bills', 'பில்கள்')),
                        _navItem(3, Icons.tune_rounded, s.t('Admin', 'நிர்வாகம்')),
                      ],
                    ),
                  ),
                ),
            ],
          );

          if (!isDesktop) return mainStack;
          return Row(
            children: [
              Container(
                key: _keyDesktopSidebar,
                width: 244,
                decoration: BoxDecoration(
                  color: _card,
                  border: Border(right: BorderSide(color: _border)),
                ),
                padding: const EdgeInsets.fromLTRB(14, 18, 14, 16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        ClipRRect(
                          borderRadius: BorderRadius.circular(12),
                          child: Image.asset('assets/images/univo_logo.png', width: 38, height: 38, fit: BoxFit.cover),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text('UNIVO WEAR', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 13.5, letterSpacing: 1.2)),
                              Text(s.role.name.toUpperCase(), style: TextStyle(fontSize: 10, fontWeight: FontWeight.w800, color: _accent)),
                            ],
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 20),
                    _desktopNavItem(0, Icons.home_rounded, s.t('Home', 'முகப்பு'), shortcut: 'Ctrl+1'),
                    _desktopNavItem(1, Icons.checkroom_rounded, s.t('Stock', 'ஸ்டாக்'), shortcut: 'Ctrl+2'),
                    _desktopNavItem(2, Icons.receipt_long_rounded, s.t('Bills', 'பில்கள்'), shortcut: 'Ctrl+3'),
                    _desktopNavItem(3, Icons.tune_rounded, s.t('Admin', 'நிர்வாகம்'), shortcut: 'Ctrl+4'),
                    const Spacer(),
                    if (s.isAdmin)
                      SizedBox(
                        width: double.infinity,
                        child: ElevatedButton.icon(
                          style: ElevatedButton.styleFrom(
                            backgroundColor: _accent,
                            foregroundColor: const Color(0xFF0A0B0E),
                            padding: const EdgeInsets.symmetric(vertical: 11, horizontal: 12),
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                          ),
                          icon: const Icon(Icons.add_rounded, size: 18),
                          label: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Text(s.t('Add Stock', 'ஸ்டாக் சேர்'), style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 12.5)),
                              const SizedBox(width: 6),
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 1.5),
                                decoration: BoxDecoration(color: Colors.black26, borderRadius: BorderRadius.circular(5)),
                                child: const Text('Ctrl+N', style: TextStyle(fontSize: 9, fontWeight: FontWeight.w900)),
                              ),
                            ],
                          ),
                          onPressed: () => _openAddStock(s),
                        ),
                      ),
                    const SizedBox(height: 10),
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                      decoration: BoxDecoration(
                        color: _surface,
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: _border),
                      ),
                      child: Text(
                        'Ctrl+B Bill • Ctrl+K Calc • F1 Tour\nCtrl+L Lang • Ctrl+T Theme • Esc Back',
                        style: TextStyle(fontSize: 9.5, height: 1.45, color: _muted, fontWeight: FontWeight.w600),
                      ),
                    ),
                  ],
                ),
              ),
              Expanded(child: mainStack),
            ],
          );
              },
            ),
          ),
        ],
      ),
    ),
        ),
      ),
    );
  }

  Widget _desktopNavItem(int idx, IconData icon, String label, {String? shortcut}) {
    final active = _tab == idx;
    return Padding(
      padding: const EdgeInsets.only(bottom: 6),
      child: InkWell(
        borderRadius: BorderRadius.circular(14),
        onTap: () {
          HapticFeedback.selectionClick();
          _goToTab(idx);
        },
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 11),
          decoration: BoxDecoration(
            color: active ? _accent.withAlpha(30) : Colors.transparent,
            borderRadius: BorderRadius.circular(14),
            border: active ? Border.all(color: _accent.withAlpha(90)) : null,
          ),
          child: Row(
            children: [
              Icon(icon, size: 19, color: active ? _accent : _muted),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  label,
                  style: TextStyle(
                    fontSize: 13,
                    fontWeight: active ? FontWeight.w800 : FontWeight.w600,
                    color: active ? _accent : null,
                  ),
                  overflow: TextOverflow.ellipsis,
                ),
              ),
              if (shortcut != null)
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 5.5, vertical: 2),
                  decoration: BoxDecoration(
                    color: _surface,
                    borderRadius: BorderRadius.circular(6),
                    border: Border.all(color: _border),
                  ),
                  child: Text(
                    shortcut,
                    style: TextStyle(fontSize: 9, fontWeight: FontWeight.w800, color: _muted),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _navItem(int idx, IconData icon, String label) {
    final active = _tab == idx;
    return Expanded(
      child: InkWell(
        borderRadius: BorderRadius.circular(20),
        onTap: () {
          HapticFeedback.selectionClick();
          _goToTab(idx);
        },
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 8),
          decoration: BoxDecoration(
            color: active ? _accent.withAlpha(34) : Colors.transparent,
            borderRadius: BorderRadius.circular(20),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(icon, size: 20, color: active ? _accent : _muted),
              const SizedBox(height: 3),
              Text(label, style: TextStyle(fontSize: 10, fontWeight: active ? FontWeight.w700 : FontWeight.w500, color: active ? _accent : _muted)),
            ],
          ),
        ),
      ),
    );
  }

  void _openDressPreview(PosStore s, StockItem item) {
    final swColor = hexToColor(item.colour);
    showDialog(
      context: context,
      builder: (dCtx) => Dialog(
        backgroundColor: _card,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
        clipBehavior: Clip.antiAlias,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(
              height: 250,
              width: double.infinity,
              child: item.photoBase64.isNotEmpty
                  ? Image.memory(_decodePhoto(item.id, item.photoBase64)!, fit: BoxFit.cover, cacheWidth: 260, gaplessPlayback: true, filterQuality: FilterQuality.low)
                  : Container(
                      color: swColor,
                      alignment: Alignment.center,
                      child: const Icon(Icons.checkroom_rounded, color: Colors.white70, size: 72),
                    ),
            ),
            Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Expanded(child: Text(item.name, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16))),
                      Text(formatInr(item.sellPrice), style: TextStyle(fontWeight: FontWeight.w900, fontSize: 16, color: _accent)),
                    ],
                  ),
                  const SizedBox(height: 4),
                  Text('${item.category} • ${item.colourName.isNotEmpty ? item.colourName : 'Standard'} • ${item.qty} pcs • ${item.location}', style: TextStyle(fontSize: 11.5, color: _muted)),
                  const SizedBox(height: 12),
                  Text('Tap a size to add to bill:', style: TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: _muted)),
                  const SizedBox(height: 8),
                  Wrap(
                    spacing: 6,
                    runSpacing: 6,
                    children: item.sizes.entries.map((e) {
                      final cnt = e.value;
                      return ActionChip(
                        label: Text('${e.key} ($cnt)', style: TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: cnt == 0 ? _muted : null)),
                        onPressed: cnt <= 0
                            ? null
                            : () {
                                Navigator.pop(dCtx);
                                _addToQuickCart(s, item, e.key);
                              },
                      );
                    }).toList(),
                  ),
                  const SizedBox(height: 10),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      if (s.isAdmin)
                        TextButton.icon(
                          icon: const Icon(Icons.edit_outlined, size: 16),
                          label: const Text('Edit Photo / Stock'),
                          onPressed: () {
                            Navigator.pop(dCtx);
                            _openAddStock(s, existing: item);
                          },
                        ),
                      TextButton(onPressed: () => Navigator.pop(dCtx), child: const Text('Close')),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showLivePageBulbTip(PosStore s) {
    final isDesk = MediaQuery.of(context).size.width >= 840 || _isWindowsDesktop;
    final steps = <LiveTourStep>[];

    if (_tab == 0) {
      steps.addAll([
        LiveTourStep(
          targetKey: _keyHomeKpi,
          title: s.t('Live Sales & Profit Card', 'இன்றைய விற்பனை & லாபம்'),
          description: s.t(
            'Switch Today / Month / All to check live revenue, profit & bills. Tap any chart bar to see exact figures.',
            'இன்று / மாதம் / மொத்தம் மாத்தி விற்பனை & லாபம் பார்க்கலாம். கிராஃப் பாரைத் தொட்டா துல்லியமான அமௌன்ட் காட்டும்.',
          ),
          shortcutHint: isDesk ? 'Ctrl+1' : null,
        ),
        LiveTourStep(
          targetKey: _keyHomeNewBill,
          title: s.t('Start New Bill Quickly', 'உடனே புது பில் போடுங்க'),
          description: s.t(
            'Tap "New Bill" to jump straight to Stock, pick dress colour + size, and generate a PNG/Print bill in seconds.',
            '"புது பில்" தட்டுனா நேரா ஸ்டாக் பேஜ் போய் டிரஸ் கலர் & சைஸ் செலக்ட் பண்ணி நொடியில் பில் போடலாம்.',
          ),
          shortcutHint: isDesk ? 'Ctrl+B' : null,
        ),
        LiveTourStep(
          targetKey: _keyHomeTools,
          title: s.t('Shop Tools Strip', 'கடை கருவிகள் (Shop Tools)'),
          description: s.isAdmin
              ? s.t(
                  'Open Day-Book, Smart ERP, GST & Promo, Calculator, Stock Tally, Out of Stock (0 pcs) & Missing Log right here.',
                  'Day-Book, Smart ERP, GST/ஆஃபர், கால்குலேட்டர், ஸ்டாக் கணக்கு, தீர்ந்து போனவை & காணாமல் போனவை எல்லாம் இங்கே இருக்கு.',
                )
              : s.t(
                  'Open Day-Book closing PNG, Shop Calculator, Stock Tally, Out of Stock list & Missing Log right here.',
                  'தினசரி கணக்கு (Day-Book), கால்குலேட்டர், ஸ்டாக் கணக்கு, தீர்ந்து போனவை & காணாமல் போனவை இங்க ஓபன் பண்ணலாம்.',
                ),
          shortcutHint: isDesk ? 'Ctrl+K Calc' : null,
        ),
        LiveTourStep(
          targetKey: isDesk ? _keyDesktopSidebar : _keyMobileNav,
          title: isDesk
              ? s.t('Desktop Sidebar & Shortcuts', 'விண்டோஸ் சைட்பார் & ஷார்ட்கட்கள்')
              : s.t('Bottom Navigation Bar', 'கீழ் நேவிகேஷன் பார்'),
          description: isDesk
              ? s.t(
                  'Switch pages with clicks or Ctrl+1 / Ctrl+2 / Ctrl+3 / Ctrl+4. Press Esc anytime to step back; press Esc twice to Exit.',
                  'கிளிக் அல்லது Ctrl+1, 2, 3, 4 வழியா பேஜ் மாத்தலாம். Esc அழுத்துனா படிப்படியா பின் போகும்; 2 முறை Esc அழுத்துனா Exit கேட்கும்.',
                )
              : s.t(
                  'Switch between Home, Stock, Bills & Admin. Pressing Back steps reverse through pages; pressing Back twice on Home asks to Exit.',
                  'முகப்பு, ஸ்டாக், பில்கள் & நிர்வாகம் மாறலாம். Back அழுத்துனா படிப்படியா பின் வரும்; Home-ல 2 முறை Back அழுத்துனா Exit கேட்கும்.',
                ),
          shortcutHint: isDesk ? 'Esc Back' : null,
        ),
        LiveTourStep(
          targetKey: _keyLangBtn,
          title: s.t('Switch Tamil / English', 'தமிழ் / English மாற்றம்'),
          description: s.t(
            'Tap here anytime to switch the entire app between Tamil and English instantly.',
            'இதைத் தொட்டு முழு செயலியையும் உடனே தமிழ் அல்லது English-க்கு மாற்றலாம்.',
          ),
          shortcutHint: isDesk ? 'Ctrl+L' : null,
        ),
        LiveTourStep(
          targetKey: _keyBulbBtn,
          title: s.t('Replay Live Guide Anytime', 'எப்ப வேணாலும் 💡 வழிகாட்டி'),
          description: s.t(
            'Tap this 💡 bulb on ANY page (Home, Stock, Bills, Admin, Calculator) to see this live arrow tour again!',
            'எந்தப் பக்கத்திலும் இந்த 💡 பல்பைத் தொட்டா மறுபடியும் இப்படி அம்புக்குறியோட லைவ் வழிகாட்டி காட்டும்!',
          ),
          shortcutHint: isDesk ? 'F1' : null,
        ),
      ]);
    } else if (_tab == 1) {
      steps.addAll([
        LiveTourStep(
          targetKey: _keyStockSearch,
          title: s.t('Search Dress, Colour or Size', 'டிரஸ், நிறம், சைஸ் தேடுங்க'),
          description: s.t(
            'Type a dress name (e.g. Polo Fit) or colour to find items fast. Tap the grid button beside search to switch Photo Grid view.',
            'டிரஸ் பெயர் (உதா: Polo Fit) அல்லது நிறம் டைப் பண்ணி ஈஸியா தேடுங்க. பக்கத்தில் உள்ள பட்டன் மூலம் போட்டோ கிரிட் மாத்தலாம்.',
          ),
          shortcutHint: isDesk ? 'Ctrl+2' : null,
        ),
        LiveTourStep(
          targetKey: isDesk ? _keyDesktopSidebar : _keyMobileNav,
          title: s.t('Tap Colour → Tap Size → Bill!', 'கலர் → சைஸ் → பில்!'),
          description: s.t(
            'Tap a colour chip (Brown / White) on any dress card, then tap a size (S, M, L, 32) to add to the floating Cart bar & finish the bill.',
            'டிரஸ் கார்டில் கலர் சிப் தொட்டு, சைஸ் (S, M, L, 32) தொட்டா கீழ Cart-ல சேரும். Cart பார் தொட்டு பில் முடிங்க.',
          ),
          shortcutHint: isDesk ? 'Ctrl+B' : null,
        ),
        LiveTourStep(
          targetKey: _keyBulbBtn,
          title: s.t('Need Help Again?', 'மீண்டும் வழிகாட்டி வேண்டுமா?'),
          description: s.t(
            'Tap 💡 anytime for this live guide, or tap Full Guide below for the complete manual.',
            'எப்ப வேணாலும் 💡 தொட்டு பார்க்கலாம், அல்லது கீழ உள்ள "முழு வழிகாட்டி" தட்டுங்க.',
          ),
          shortcutHint: isDesk ? 'F1' : null,
        ),
      ]);
    } else if (_tab == 2) {
      steps.addAll([
        LiveTourStep(
          targetKey: _keyBillsHeader,
          title: s.t("Today's Bills & Old Bills PDF", 'இன்றைய பில்கள் & Old Bills PDF'),
          description: s.t(
            'View today\'s fresh bills total here. Admins can open Old Bills to export Date-Wise or Monthly PDFs.',
            'இன்றைய மொத்த விற்பனை பில்கள் இங்கே காட்டும். அட்மின் Old Bills வழியா தேதி/மாத PDF எடுக்கலாம்.',
          ),
          shortcutHint: isDesk ? 'Ctrl+3' : null,
        ),
        LiveTourStep(
          targetKey: _keyBillsSearch,
          title: s.t('Search, 7-Day Edit & PNG Print', 'தேடு, 7-நாள் எடிட் & PNG பிரிண்ட்'),
          description: s.t(
            'Search by bill ID, dress, or customer. Tap "Today ⇄ 7d" to Edit/Restore bills, or tap any bill to Share PNG / Thermal Print.',
            'பில் எண்/பெயர் தேடுங்க. "Today ⇄ 7d" மூலம் 7 நாள் பில்களை Edit/Restore பண்ணலாம், பில்லைத் தொட்டு PNG ஷேர்/பிரிண்ட் எடுக்கலாம்.',
          ),
        ),
      ]);
    } else {
      steps.addAll([
        LiveTourStep(
          targetKey: _keyAdminProfile,
          title: s.t('Profile, UID & Role Controls', 'ப்ரொஃபைல், UID & நிர்வாகம்'),
          description: s.isAdmin
              ? s.t(
                  'Copy UID, manage Staff Bargain/Commission rules, view Restore History, Check Updates, or open the full User Guide below.',
                  'UID காப்பி பண்ணலாம், ஸ்டாஃப் டிஸ்கவுண்ட்/கமிஷன் செட் பண்ணலாம், ரீஸ்டோர் வரலாறு & அப்டேட் செக் பண்ணலாம்.',
                )
              : s.t(
                  'Copy your User UID if the Owner asks, check for App Updates, or open the User Guide anytime.',
                  'ஓனர் கேட்டா UID காப்பி பண்ணுங்க, ஆப் அப்டேட் செக் பண்ணலாம் அல்லது முழு வழிகாட்டியைப் பாக்கலாம்.',
                ),
          shortcutHint: isDesk ? 'Ctrl+4' : null,
        ),
        LiveTourStep(
          targetKey: _keyThemeBtn,
          title: s.t('Dark / Light Theme', 'டார்க் / லைட் தீம்'),
          description: s.t(
            'Switch between Luxury Dark Mode and Boutique Light Mode anytime.',
            'டார்க் மோட் மற்றும் லைட் மோட் இடையே எப்ப வேணாலும் மாற்றிக்கலாம்.',
          ),
          shortcutHint: isDesk ? 'Ctrl+T' : null,
        ),
      ]);
    }

    showLiveArrowTour(
      context,
      s,
      steps,
      onOpenFullGuide: () => showHowToUseSheet(context, s),
    );
  }

  Widget _buildHomeTab(PosStore s) {
    final periodSales = _salesForPeriod(s);
    final totalSales = periodSales.fold<double>(0, (a, b) => a + b.totalSellPrice);
    final totalProfit = periodSales.fold<double>(0, (a, b) => a + b.profit);
    final totalCost = periodSales.fold<double>(0, (a, b) => a + (b.costPrice * b.qty));
    final totalDisc = periodSales.fold<double>(0, (a, b) => a + b.discount);
    final totalLoss = s.missing.fold<double>(0, (a, b) => a + b.lossAmount);
    final totalPcs = s.stock.fold<int>(0, (a, b) => a + b.qty);
    final khataDue = s.khata
        .where((k) => k['status'] != 'Paid')
        .fold<double>(0, (a, b) => a + ((b['amount'] as num? ?? 0).toDouble()));

    final dayDateHeader = DateFormat('EEEE, dd MMM yyyy • hh:mm a').format(_now);
    final periodTitle = _periodMode == 'TODAY'
        ? s.t("Today's Revenue (24h)", "இன்றைய விற்பனை (24 மணி)")
        : (_periodMode == 'MONTH'
            ? s.t('${DateFormat('MMMM yyyy').format(_now)} Revenue', 'இந்த மாத விற்பனை')
            : s.t('All-Time Store Revenue', 'மொத்த விற்பனை'));

    return ListView(
      padding: const EdgeInsets.fromLTRB(18, 10, 18, 160),
      children: [
        // Live Day / Date / Month / Year Strip (Auto-resets Today at Midnight 00:00)
        Padding(
          padding: const EdgeInsets.only(bottom: 10, left: 2, right: 2),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  Icon(Icons.calendar_today_rounded, size: 13, color: _accent),
                  const SizedBox(width: 6),
                  Text(dayDateHeader, style: TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: _muted)),
                ],
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                decoration: BoxDecoration(color: _green.withAlpha(28), borderRadius: BorderRadius.circular(12)),
                child: Text(s.hasPendingSync ? 'SYNCING' : 'LIVE', style: TextStyle(fontSize: 9, fontWeight: FontWeight.w800, color: s.hasPendingSync ? _accent : _green)),
              ),
            ],
          ),
        ),

        if (s.isWithin3DayDeleteWarning)
          Container(
            margin: const EdgeInsets.only(bottom: 12),
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: _rose.withAlpha(24),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: _rose.withAlpha(120)),
            ),
            child: Row(
              children: [
                Icon(Icons.notifications_active_rounded, color: _rose, size: 22),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Auto-Delete Alert: ${s.daysUntilMonthlyAutoDelete} day(s) left!',
                        style: TextStyle(fontWeight: FontWeight.w900, fontSize: 12.5, color: _rose),
                      ),
                      Text(
                        'Save this month old bills as PDF to storage before automatic monthly cleanup.',
                        style: TextStyle(fontSize: 11, color: _muted),
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 6),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: _rose,
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                    minimumSize: Size.zero,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                  ),
                  onPressed: () => showOldBillsArchiveSheet(context, s),
                  child: const Text('Save PDF', style: TextStyle(fontSize: 11, fontWeight: FontWeight.w800)),
                ),
              ],
            ),
          ),

        // Editorial Hero Card with Today / Month / All-Time Switcher
        Card(
          key: _keyHomeKpi,
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    _periodChip('TODAY', s.t('Today', 'இன்று')),
                    const SizedBox(width: 6),
                    _periodChip('MONTH', s.t('Month', 'மாதம்')),
                    const SizedBox(width: 6),
                    _periodChip('ALL', s.t('All', 'மொத்தம்')),
                  ],
                ),
                const SizedBox(height: 14),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(periodTitle, style: TextStyle(fontSize: 12, color: _muted, fontWeight: FontWeight.w500)),
                        const SizedBox(height: 4),
                        TweenAnimationBuilder<double>(
                          tween: Tween<double>(begin: 0, end: totalSales),
                          duration: const Duration(milliseconds: 550),
                          curve: Curves.easeOutCubic,
                          builder: (_, val, __) => Text(
                            formatInr(val),
                            style: const TextStyle(fontSize: 34, fontWeight: FontWeight.w900, letterSpacing: -1, fontFeatures: [FontFeature.tabularFigures()]),
                          ),
                        ),
                      ],
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                      decoration: BoxDecoration(color: _green.withAlpha(32), borderRadius: BorderRadius.circular(20)),
                      child: Text('${periodSales.length} ${s.t('bills', 'பில்கள்')}', style: TextStyle(color: _green, fontSize: 11, fontWeight: FontWeight.w700)),
                    ),
                  ],
                ),
                const SizedBox(height: 18),
                Divider(color: _border, height: 1),
                const SizedBox(height: 16),
                Row(
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(s.t('Net Profit', 'நிகர லாபம்'), style: TextStyle(fontSize: 11, color: _muted)),
                          const SizedBox(height: 2),
                          s.isAdmin
                              ? TweenAnimationBuilder<double>(
                                  tween: Tween<double>(begin: 0, end: totalProfit),
                                  duration: const Duration(milliseconds: 550),
                                  curve: Curves.easeOutCubic,
                                  builder: (_, val, __) => Text(formatInr(val), style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: _accent)),
                                )
                              : Text('••••••', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: _accent)),
                        ],
                      ),
                    ),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(s.t('In-Stock', 'கையிருப்பு'), style: TextStyle(fontSize: 11, color: _muted)),
                          const SizedBox(height: 2),
                          TweenAnimationBuilder<double>(
                            tween: Tween<double>(begin: 0, end: totalPcs.toDouble()),
                            duration: const Duration(milliseconds: 550),
                            curve: Curves.easeOutCubic,
                            builder: (_, val, __) => Text('${val.round()} pcs', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
                          ),
                        ],
                      ),
                    ),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(s.t('Khata Due', 'கடன் பாக்கி'), style: TextStyle(fontSize: 11, color: _muted)),
                          const SizedBox(height: 2),
                          Text(formatInr(khataDue), style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: _rose)),
                        ],
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 20),
                Row(
                  children: [
                    Expanded(
                      child: SizedBox(
                        height: 48,
                        child: ElevatedButton.icon(
                          key: _keyHomeNewBill,
                          style: ElevatedButton.styleFrom(
                            backgroundColor: _ctaBg,
                            foregroundColor: _ctaFg,
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                          ),
                          onPressed: () => _goToTab(1),
                          icon: const Icon(Icons.shopping_bag_outlined, size: 17),
                          label: Text(s.t('New Bill', 'புது பில்'), style: const TextStyle(fontWeight: FontWeight.w800)),
                        ),
                      ),
                    ),
                    if (s.isAdmin) ...[
                      const SizedBox(width: 12),
                      Expanded(
                        child: SizedBox(
                          height: 48,
                          child: OutlinedButton.icon(
                            style: OutlinedButton.styleFrom(
                              side: BorderSide(color: _border),
                              backgroundColor: _surface,
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                            ),
                            onPressed: () => _openAddStock(s),
                            icon: Icon(Icons.add_rounded, size: 18, color: _accent),
                            label: Text(s.t('Add Stock', 'ஸ்டாக் சேர்'), style: TextStyle(fontWeight: FontWeight.w700, color: s.isDark ? Colors.white : Colors.black)),
                          ),
                        ),
                      ),
                    ],
                  ],
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 20),

        // Clean Horizontal Shop Tools Pill Strip
        Padding(
          key: _keyHomeTools,
          padding: const EdgeInsets.only(left: 4, bottom: 10),
          child: Text(s.t('SHOP TOOLS', 'கடை கருவிகள்'), style: TextStyle(fontSize: 11, fontWeight: FontWeight.w700, letterSpacing: 1, color: _muted)),
        ),
        LayoutBuilder(
          builder: (_, tc) {
            final toolWidgets = <Widget>[
              _toolPill(Icons.menu_book_rounded, s.t('Day-Book', 'தினசரி கணக்கு'), _green, () => showDayBookSheet(context, s)),
                if (s.isAdmin) _toolPill(Icons.insights_rounded, s.t('Smart ERP', 'ERP ஆய்வு'), _accent, () => showSmartErpSheet(context, s)),
                if (s.isAdmin) _toolPill(Icons.storefront_rounded, s.t('GST & Promo', 'GST / ஆஃபர்'), Colors.tealAccent, () => showGstAndEnterpriseSheet(context, s)),
              _toolPill(Icons.account_balance_wallet_rounded, s.t('Khata Ledger', 'கடன் கணக்கு'), _accent, () => showKhataSheet(context, s)),
              _toolPill(Icons.calculate_rounded, s.t('Calculator', 'கால்குலேட்டர்'), Colors.cyanAccent, () => Navigator.push(context, MaterialPageRoute(builder: (_) => ShopCalculatorScreen(store: s)))),
              if (s.isAdmin) _toolPill(Icons.local_shipping_rounded, s.t('Suppliers', 'மொத்த பில்'), Colors.lightBlueAccent, () => showSuppliersSheet(context, s)),
              if (s.isAdmin) _toolPill(Icons.swap_horiz_rounded, s.t('Godown', 'குடோன்'), _accent, () => showGodownTransferSheet(context, s)),
              _toolPill(Icons.fact_check_rounded, s.t('Stock Tally', 'ஸ்டாக் கணக்கு'), _accent, () => showNightTallySheet(context, s)),
              _toolPill(Icons.inventory_2_outlined, s.t('Out of Stock (${s.stock.where((x) => x.qty <= 0).length})', 'தீர்ந்து போனவை (${s.stock.where((x) => x.qty <= 0).length})'), _rose, () => showOutOfStockSheet(context, s)),
              _toolPill(Icons.warning_amber_rounded, s.t('Missing Log', 'காணாமல் போனவை'), _rose, () => showReportMissingSheet(context, s)),
            ];
            if (tc.maxWidth >= 700) {
              return Wrap(
                spacing: 8,
                runSpacing: 10,
                children: toolWidgets.map((w) => SizedBox(height: 46, child: w)).toList(),
              );
            }
            return SizedBox(
              height: 48,
              child: ListView(scrollDirection: Axis.horizontal, children: toolWidgets),
            );
          },
        ),
        const SizedBox(height: 20),

        // Clear 3-Mode Analytics Graph (7-Day Daily / Monthly / P&L Breakdown)
        Card(
          child: Padding(
            padding: const EdgeInsets.all(18),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(s.t('Analytics Graph', 'விற்பனை வரைபடம்'), style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 14)),
                    Row(
                      children: [
                        _chartModeChip('WEEK', '7 Days'),
                        const SizedBox(width: 4),
                        _chartModeChip('MONTH', 'Monthly'),
                        const SizedBox(width: 4),
                        _chartModeChip('PNL', 'P&L'),
                      ],
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                SizedBox(
                  height: 185,
                  child: _buildClearAnalyticsChart(s, totalSales, totalCost, totalProfit, totalDisc, totalLoss),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }


  Widget _periodChip(String key, String label) {
    final active = _periodMode == key;
    return InkWell(
      borderRadius: BorderRadius.circular(14),
      onTap: () => setState(() => _periodMode = key),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 5),
        decoration: BoxDecoration(
          color: active ? _ctaBg : _surface,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: _border),
        ),
        child: Text(label, style: TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: active ? _ctaFg : _muted)),
      ),
    );
  }

  Widget _chartModeChip(String key, String label) {
    final active = _chartMode == key;
    return InkWell(
      borderRadius: BorderRadius.circular(10),
      onTap: () => setState(() => _chartMode = key),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
        decoration: BoxDecoration(
          color: active ? _accent : _surface,
          borderRadius: BorderRadius.circular(10),
        ),
        child: Text(label, style: TextStyle(fontSize: 10, fontWeight: FontWeight.w800, color: active ? const Color(0xFF0A0B0E) : _muted)),
      ),
    );
  }

  Widget _buildClearAnalyticsChart(PosStore s, double rev, double cost, double profit, double disc, double loss) {
    final labels = <String>[];
    final values = <double>[];
    final barColors = <Color>[];

    if (_chartMode == 'WEEK') {
      for (int i = 6; i >= 0; i--) {
        final d = _now.subtract(Duration(days: i));
        final iso = DateFormat('yyyy-MM-dd').format(d);
        final dayTotal = s.sales
            .where((x) => x.date == iso || x.createdAt.startsWith(iso))
            .fold<double>(0, (a, b) => a + b.totalSellPrice);
        labels.add(i == 0 ? 'Today\n${DateFormat('dd').format(d)}' : '${DateFormat('E').format(d)}\n${DateFormat('dd').format(d)}');
        values.add(dayTotal);
        barColors.add(i == 0 ? _green : _accent);
      }
    } else if (_chartMode == 'MONTH') {
      for (int i = 5; i >= 0; i--) {
        final d = DateTime(_now.year, _now.month - i, 1);
        final prefix = DateFormat('yyyy-MM').format(d);
        final mTotal = s.sales
            .where((x) => x.date.startsWith(prefix) || x.createdAt.startsWith(prefix))
            .fold<double>(0, (a, b) => a + b.totalSellPrice);
        labels.add(DateFormat('MMM').format(d));
        values.add(mTotal);
        barColors.add(i == 0 ? _green : _accent);
      }
    } else if (s.isAdmin) {
      labels.addAll(['Sales', 'Cost', 'Profit', 'Less', 'Loss']);
      values.addAll([rev, cost, profit, disc, loss]);
      barColors.addAll([_green, Colors.indigoAccent, _accent, Colors.lightBlueAccent, _rose]);
    } else {
      labels.addAll(['Sales', 'Less', 'Loss']);
      values.addAll([rev, disc, loss]);
      barColors.addAll([_green, Colors.lightBlueAccent, _rose]);
    }

    return RepaintBoundary(
      child: BarChart(
      BarChartData(
        barTouchData: BarTouchData(
          enabled: true,
          touchTooltipData: BarTouchTooltipData(
            getTooltipItem: (group, groupIndex, rod, rodIndex) {
              final lbl = group.x < labels.length ? labels[group.x].replaceAll('\n', ' ') : '';
              return BarTooltipItem(
                '$lbl\n${formatInr(rod.toY)}',
                const TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 11),
              );
            },
          ),
        ),
        borderData: FlBorderData(show: false),
        gridData: const FlGridData(show: true, drawVerticalLine: false),
        titlesData: FlTitlesData(
          topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
          rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
          leftTitles: AxisTitles(
            sideTitles: SideTitles(
              showTitles: true,
              reservedSize: 42,
              getTitlesWidget: (v, _) => Text(
                v >= 1000 ? '${(v / 1000).toStringAsFixed(0)}k' : v.toStringAsFixed(0),
                style: TextStyle(fontSize: 9, color: _muted),
              ),
            ),
          ),
          bottomTitles: AxisTitles(
            sideTitles: SideTitles(
              showTitles: true,
              reservedSize: 32,
              getTitlesWidget: (v, _) {
                final idx = v.toInt();
                if (idx < 0 || idx >= labels.length) return const SizedBox.shrink();
                return Padding(
                  padding: const EdgeInsets.only(top: 6),
                  child: Text(labels[idx], textAlign: TextAlign.center, style: TextStyle(fontSize: 9.5, fontWeight: FontWeight.w700, height: 1.15, color: _muted)),
                );
              },
            ),
          ),
        ),
        barGroups: List.generate(values.length, (i) {
          return BarChartGroupData(
            x: i,
            barRods: [
              BarChartRodData(
                toY: values[i],
                color: barColors[i],
                width: 18,
                borderRadius: const BorderRadius.vertical(top: Radius.circular(6)),
              ),
            ],
          );
        }),
      ),
      ),
    );
  }

  Widget _toolPill(IconData icon, String label, Color color, VoidCallback onTap) {
    return Padding(
      padding: const EdgeInsets.only(right: 10),
      child: InkWell(
        borderRadius: BorderRadius.circular(18),
        onTap: () {
          HapticFeedback.lightImpact();
          onTap();
        },
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          decoration: BoxDecoration(
            color: _card,
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: _border),
          ),
          child: Row(
            children: [
              Icon(icon, size: 16, color: color),
              const SizedBox(width: 8),
              Text(label, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700)),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildStockTab(PosStore s) {
    final q = _stockSearch.toLowerCase();
    final soldOutCount = s.stock.where((x) => x.qty <= 0).length;
    final filtered = s.stock.where((i) {
      if (i.qty <= 0) return false;
      final matchCat = _stockCat == 'ALL'
          ? true
          : (_stockCat == 'LOW STOCK'
              ? i.qty <= 3
              : (_stockCat == 'WITH PHOTO' ? i.photoBase64.isNotEmpty : i.category == _stockCat));
      final matchQ = q.isEmpty ||
          i.name.toLowerCase().contains(q) ||
          i.colourName.toLowerCase().contains(q) ||
          i.sizes.entries.any((e) => e.key.toLowerCase().contains(q) && e.value > 0);
      return matchCat && matchQ;
    }).toList();

    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(18, 14, 18, 10),
          child: Row(
            children: [
              Expanded(
                child: TextField(
                  key: _keyStockSearch,
                  decoration: InputDecoration(
                    prefixIcon: const Icon(Icons.search_rounded, size: 19),
                    hintText: s.t('Search dress, colour, location...', 'ஆடை, நிறம், இடம் தேடு...'),
                  ),
                  onChanged: (v) => setState(() => _stockSearch = v),
                ),
              ),
              const SizedBox(width: 8),
              InkWell(
                borderRadius: BorderRadius.circular(14),
                onTap: () => setState(() => _stockGridView = !_stockGridView),
                child: Container(
                  width: 46,
                  height: 46,
                  decoration: BoxDecoration(
                    color: _stockGridView ? _accent.withAlpha(35) : _surface,
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: _stockGridView ? _accent : _border),
                  ),
                  child: Icon(
                    _stockGridView ? Icons.view_list_rounded : Icons.grid_view_rounded,
                    size: 20,
                    color: _stockGridView ? _accent : _muted,
                  ),
                ),
              ),
            ],
          ),
        ),
        SizedBox(
          height: 40,
          child: ListView(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 18),
            children: [
              if (soldOutCount > 0)
                Padding(
                  padding: const EdgeInsets.only(right: 8),
                  child: InkWell(
                    borderRadius: BorderRadius.circular(20),
                    onTap: () => showOutOfStockSheet(context, s),
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 14),
                      alignment: Alignment.center,
                      decoration: BoxDecoration(
                        color: _rose.withAlpha(32),
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(color: _rose),
                      ),
                      child: Text(
                        s.t('Out of Stock ($soldOutCount)', 'தீர்ந்து போனவை ($soldOutCount)'),
                        style: TextStyle(fontSize: 11.5, fontWeight: FontWeight.w800, color: _rose),
                      ),
                    ),
                  ),
                ),
              ...['ALL', 'LOW STOCK', 'WITH PHOTO', ...kCategories].map((c) {
              final act = _stockCat == c;
              return Padding(
                padding: const EdgeInsets.only(right: 8),
                child: InkWell(
                  borderRadius: BorderRadius.circular(20),
                  onTap: () => setState(() => _stockCat = c),
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      color: act ? _ctaBg : _surface,
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: _border),
                    ),
                    child: Text(c, style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: act ? _ctaFg : null)),
                  ),
                ),
              );
            }),
            ],
          ),
        ),
        if (_heldCarts.isNotEmpty)
          SizedBox(
            height: 44,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.fromLTRB(18, 8, 18, 0),
              itemCount: _heldCarts.length,
              itemBuilder: (_, hi) {
                final hc = _heldCarts[hi];
                final hItems = hc['items'] as List<CartLine>;
                final hTot = hItems.fold<double>(0, (a, b) => a + b.totalSellPrice);
                return Padding(
                  padding: const EdgeInsets.only(right: 8),
                  child: ActionChip(
                    avatar: Icon(Icons.play_arrow_rounded, size: 16, color: _accent),
                    label: Text(
                      'Resume ${hc['label']} (${hItems.length} • ${formatInr(hTot)})',
                      style: TextStyle(fontSize: 11, fontWeight: FontWeight.w800, color: _accent),
                    ),
                    onPressed: () {
                      setState(() {
                        _quickCart.addAll(hItems);
                        _heldCarts.removeAt(hi);
                      });
                      _openQuickCheckoutDrawer(s);
                    },
                  ),
                );
              },
            ),
          ),
        const SizedBox(height: 10),
        Expanded(
          child: filtered.isEmpty
              ? Center(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.checkroom_rounded, size: 48, color: _muted),
                      const SizedBox(height: 8),
                      Text(s.t('No garments in stock yet', 'ஸ்டாக் எதுவும் இல்லை'), style: TextStyle(color: _muted, fontWeight: FontWeight.w600)),
                      const SizedBox(height: 12),
                      if (s.isAdmin)
                        ElevatedButton.icon(
                          style: ElevatedButton.styleFrom(backgroundColor: _ctaBg, foregroundColor: _ctaFg),
                          onPressed: () => _openAddStock(s),
                          icon: const Icon(Icons.add),
                          label: Text(s.t('Add First Garment', 'முதல் ஆடை சேர்')),
                        ),
                    ],
                  ),
                )
              : _stockGridView
                  ? GridView.builder(
                      padding: const EdgeInsets.fromLTRB(18, 4, 18, 160),
                      cacheExtent: 260,
                      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: MediaQuery.of(context).size.width >= 1180
                            ? 4
                            : (MediaQuery.of(context).size.width >= 840 ? 3 : 2),
                        crossAxisSpacing: 12,
                        mainAxisSpacing: 12,
                        childAspectRatio: 0.74,
                      ),
                      itemCount: filtered.length,
                      itemBuilder: (_, idx) {
                        final item = filtered[idx];
                        final swColor = hexToColor(item.colour);
                        return InkWell(
                          borderRadius: BorderRadius.circular(20),
                          onTap: () => _openDressPreview(s, item),
                          child: Card(
                            margin: EdgeInsets.zero,
                            clipBehavior: Clip.antiAlias,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Expanded(
                                  child: Stack(
                                    fit: StackFit.expand,
                                    children: [
                                      item.photoBase64.isNotEmpty
                                          ? Image.memory(_decodePhoto(item.id, item.photoBase64)!, fit: BoxFit.cover, cacheWidth: 260, gaplessPlayback: true, filterQuality: FilterQuality.low)
                                          : Container(
                                              decoration: BoxDecoration(
                                                gradient: LinearGradient(
                                                  begin: Alignment.topLeft,
                                                  end: Alignment.bottomRight,
                                                  colors: [swColor, swColor.withAlpha(170)],
                                                ),
                                              ),
                                              child: const Icon(Icons.checkroom_rounded, color: Colors.white70, size: 42),
                                            ),
                                      Positioned(
                                        top: 8,
                                        right: 8,
                                        child: Container(
                                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                                          decoration: BoxDecoration(
                                            color: Colors.black.withAlpha(175),
                                            borderRadius: BorderRadius.circular(10),
                                          ),
                                          child: Text(
                                            formatInr(item.sellPrice),
                                            style: const TextStyle(color: AppTheme.gold, fontWeight: FontWeight.w900, fontSize: 11),
                                          ),
                                        ),
                                      ),
                                      Positioned(
                                        bottom: 8,
                                        left: 8,
                                        child: Container(
                                          padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
                                          decoration: BoxDecoration(
                                            color: (item.qty <= 3 ? AppTheme.rose : AppTheme.green).withAlpha(220),
                                            borderRadius: BorderRadius.circular(8),
                                          ),
                                          child: Text(
                                            '${item.qty} pcs',
                                            style: const TextStyle(color: Colors.black, fontWeight: FontWeight.w800, fontSize: 10),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Padding(
                                  padding: const EdgeInsets.all(10),
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text(item.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 12.5)),
                                      const SizedBox(height: 2),
                                      Text('${item.category} • ${item.location}', maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 10.5, color: _muted)),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        );
                      },
                    )
                  : Builder(builder: (_) {
                  final grouped = <String, List<StockItem>>{};
                  for (final st in filtered) {
                    grouped.putIfAbsent(_baseDesignName(st), () => []).add(st);
                  }
                  final groupNames = grouped.keys.toList();
                  return ListView.builder(
                  padding: const EdgeInsets.fromLTRB(18, 4, 18, 160),
                  itemCount: groupNames.length,
                  itemBuilder: (_, idx) {
                    final baseName = groupNames[idx];
                    final variants = grouped[baseName]!;
                    final selId = _selectedColourByGroup[baseName];
                    final item = variants.firstWhere((v) => v.id == selId, orElse: () => variants.first);
                    final groupTotalPcs = variants.fold<int>(0, (a, b) => a + b.qty);
                    final swColor = hexToColor(item.colour);
                    return Card(
                      margin: const EdgeInsets.only(bottom: 12),
                      child: Padding(
                        padding: const EdgeInsets.all(16),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                GestureDetector(
                                  onTap: () => _openDressPreview(s, item),
                                  child: Container(
                                    width: 56,
                                    height: 56,
                                    decoration: BoxDecoration(
                                      color: swColor,
                                      borderRadius: BorderRadius.circular(16),
                                      border: Border.all(color: _accent.withAlpha(90)),
                                    ),
                                    child: item.photoBase64.isNotEmpty
                                        ? ClipRRect(
                                            borderRadius: BorderRadius.circular(15),
                                            child: Image.memory(_decodePhoto(item.id, item.photoBase64)!, fit: BoxFit.cover, cacheWidth: 260, gaplessPlayback: true, filterQuality: FilterQuality.low),
                                          )
                                        : const Icon(Icons.checkroom_rounded, color: Colors.white, size: 24),
                                  ),
                                ),
                                const SizedBox(width: 14),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Row(
                                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                        children: [
                                          Expanded(child: Text(variants.length > 1 ? '$baseName (${variants.length} colours • $groupTotalPcs pcs)' : baseName, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15), overflow: TextOverflow.ellipsis)),
                                          Text(formatInr(item.sellPrice), style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 15)),
                                        ],
                                      ),
                                      const SizedBox(height: 3),
                                      Wrap(
                                          spacing: 6,
                                          runSpacing: 4,
                                          children: [
                                            Text(item.category, style: TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: _accent)),
                                            if (item.colourName.isNotEmpty)
                                              Text('• ${item.colourName}', style: TextStyle(fontSize: 11, color: _muted)),
                                            Text('• ${item.location}', style: TextStyle(fontSize: 11, color: _muted)),
                                            Text('• ${item.qty} pcs', style: TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: item.qty <= 3 ? _rose : _green)),
                                            if (s.isAdmin)
                                              Text('• Cost ${formatInr(item.costPrice)} (+${formatInr(item.sellPrice - item.costPrice)})', style: TextStyle(fontSize: 10.5, color: _muted)),
                                            Builder(builder: (_) {
                                              final dt = DateTime.tryParse(item.createdAt);
                                              final addedLabel = dt != null ? DateFormat('dd MMM yyyy • hh:mm a').format(dt) : item.date;
                                              return Text('• $addedLabel', style: TextStyle(fontSize: 10, color: _muted));
                                            }),
                                          ],
                                        ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                            if (variants.length > 1) ...[
                              const SizedBox(height: 10),
                              SizedBox(
                                height: 32,
                                child: ListView.builder(
                                  scrollDirection: Axis.horizontal,
                                  itemCount: variants.length,
                                  itemBuilder: (_, vIdx) {
                                    final v = variants[vIdx];
                                    final activeV = v.id == item.id;
                                    final vc = hexToColor(v.colour);
                                    return Padding(
                                      padding: const EdgeInsets.only(right: 6),
                                      child: InkWell(
                                        borderRadius: BorderRadius.circular(16),
                                        onTap: () => setState(() => _selectedColourByGroup[baseName] = v.id),
                                        child: Container(
                                          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                                          decoration: BoxDecoration(
                                            color: activeV ? _accent.withAlpha(38) : _surface,
                                            borderRadius: BorderRadius.circular(16),
                                            border: Border.all(color: activeV ? _accent : _border, width: activeV ? 1.5 : 1),
                                          ),
                                          child: Row(
                                            mainAxisSize: MainAxisSize.min,
                                            children: [
                                              Container(width: 10, height: 10, decoration: BoxDecoration(color: vc, shape: BoxShape.circle, border: Border.all(color: Colors.white54))),
                                              const SizedBox(width: 6),
                                              Text(
                                                '${v.colourName.isNotEmpty ? v.colourName : 'Colour ${vIdx + 1}'} (${v.qty})',
                                                style: TextStyle(fontSize: 11, fontWeight: activeV ? FontWeight.w800 : FontWeight.w600, color: activeV ? _accent : null),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                    );
                                  },
                                ),
                              ),
                            ],
                            const SizedBox(height: 10),
                            Text(
                              s.t('Tap a size below to add to bill:', 'பில் போட சைஸை தட்டுங்க:'),
                              style: TextStyle(fontSize: 10.5, fontWeight: FontWeight.w700, color: _muted),
                            ),
                            const SizedBox(height: 6),
                            Wrap(
                              spacing: 8,
                              runSpacing: 8,
                              children: item.sizes.entries.map((e) {
                                final cnt = e.value;
                                final low = cnt > 0 && cnt <= 2;
                                return InkWell(
                                  borderRadius: BorderRadius.circular(12),
                                  onTap: cnt > 0 ? () => _addToQuickCart(s, item, e.key) : null,
                                  child: Container(
                                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
                                    decoration: BoxDecoration(
                                      color: _surface,
                                      borderRadius: BorderRadius.circular(12),
                                      border: Border.all(color: low ? _accent : _border),
                                    ),
                                    child: Row(
                                      mainAxisSize: MainAxisSize.min,
                                      children: [
                                        Text(e.key, style: TextStyle(fontWeight: FontWeight.w700, fontSize: 12, color: cnt == 0 ? _muted : null)),
                                        const SizedBox(width: 6),
                                        Text('$cnt', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 11, color: cnt == 0 ? _rose : (low ? _accent : _green))),
                                      ],
                                    ),
                                  ),
                                );
                              }).toList(),
                            ),
                            const SizedBox(height: 6),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.end,
                              children: [
                                if (s.isAdmin) ...[
                                  IconButton(
                                    icon: Icon(Icons.edit_outlined, size: 18, color: _accent),
                                    tooltip: 'Edit Stock',
                                    onPressed: () => _openAddStock(s, existing: item),
                                  ),
                                  IconButton(
                                    icon: Icon(Icons.delete_outline_rounded, size: 18, color: _rose),
                                    tooltip: 'Delete Stock',
                                    onPressed: () async {
                                      final ok = await showDialog<bool>(
                                        context: context,
                                        builder: (dCtx) => AlertDialog(
                                          title: const Text('Confirm Delete Stock'),
                                          content: Text('Delete "${item.name}" (${item.qty} pcs) permanently?'),
                                          actions: [
                                            TextButton(onPressed: () => Navigator.pop(dCtx, false), child: const Text('Cancel')),
                                            ElevatedButton(
                                              style: ElevatedButton.styleFrom(backgroundColor: _rose, foregroundColor: Colors.white),
                                              onPressed: () => Navigator.pop(dCtx, true),
                                              child: const Text('Delete'),
                                            ),
                                          ],
                                        ),
                                      );
                                      if (ok == true) {
                                        await s.deleteStock(item.id);
                                        if (mounted) {
                                          ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Deleted "${item.name}"')));
                                        }
                                      }
                                    },
                                  ),
                                ],
                              ],
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                );
                }),
        ),
      ],
    );
  }

  Widget _buildBillsTab(PosStore s) {
    final todayIso = DateFormat('yyyy-MM-dd').format(_now);
    final sevenDaysAgo = _now.subtract(const Duration(days: 7));
    final todayOnly = s.sales.where((sale) => sale.date == todayIso || sale.createdAt.startsWith(todayIso)).toList();
    final weekOnly = s.sales.where((sale) {
      final dt = DateTime.tryParse(sale.date.length >= 10 ? sale.date.substring(0, 10) : sale.createdAt);
      return dt != null && !dt.isBefore(DateTime(sevenDaysAgo.year, sevenDaysAgo.month, sevenDaysAgo.day));
    }).toList();
    final activeBaseList = _billsWindowMode == 'WEEK' ? weekOnly : todayOnly;
    final oldBillsCount = s.sales.length - todayOnly.length;
    final q = _salesSearch.toLowerCase().trim();
    final filtered = activeBaseList.where((sale) {
      if (_salesFilter != 'ALL') {
        final sp = sale.payment.toLowerCase();
        final fp = _salesFilter.toLowerCase();
        if (fp.contains('upi')) {
          if (!(sp.contains('upi') || sp.contains('gpay') || sp.contains('phonepe') || sp.contains('online'))) return false;
        } else if (sp != fp) {
          return false;
        }
      }
      if (q.isNotEmpty) {
        final hay = '${sale.id} ${sale.itemName} ${sale.customerName} ${sale.customerPhone} ${sale.soldBy}'.toLowerCase();
        if (!hay.contains(q)) return false;
      }
      return true;
    }).toList();
    final sum = filtered.fold<double>(0, (a, b) => a + b.totalSellPrice);

    return Column(
      children: [
        Padding(
          key: _keyBillsHeader,
          padding: const EdgeInsets.fromLTRB(18, 14, 18, 10),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(s.t("Today's Bills", 'இன்றைய பில்கள்'), style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
              Row(
                children: [
                  if (s.isAdmin) ...[
                    InkWell(
                      borderRadius: BorderRadius.circular(20),
                      onTap: () => showOldBillsArchiveSheet(context, s),
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                        decoration: BoxDecoration(color: _accent.withAlpha(30), borderRadius: BorderRadius.circular(20)),
                        child: Row(
                          children: [
                            Icon(Icons.picture_as_pdf_rounded, size: 13, color: _accent),
                            const SizedBox(width: 4),
                            Text('Old Bills ($oldBillsCount)', style: TextStyle(color: _accent, fontWeight: FontWeight.w800, fontSize: 11)),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(width: 6),
                  ],
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
                    decoration: BoxDecoration(color: _green.withAlpha(30), borderRadius: BorderRadius.circular(20)),
                    child: Text(formatInr(sum), style: TextStyle(color: _green, fontWeight: FontWeight.w800, fontSize: 13)),
                  ),
                ],
              ),
            ],
          ),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(18, 0, 18, 10),
          child: TextField(
            key: _keyBillsSearch,
            decoration: InputDecoration(
              prefixIcon: const Icon(Icons.search_rounded, size: 19),
              hintText: s.t('Search bill ID, dress, customer...', 'பில் எண், டிரஸ், வாடிக்கையாளர் தேடு...'),
            ),
            onChanged: (v) => setState(() => _salesSearch = v),
          ),
        ),
        SizedBox(
          height: 38,
          child: ListView(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 18),
            children: [
              Padding(
                padding: const EdgeInsets.only(right: 8),
                child: InkWell(
                  borderRadius: BorderRadius.circular(20),
                  onTap: () => setState(() => _billsWindowMode = _billsWindowMode == 'TODAY' ? 'WEEK' : 'TODAY'),
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12),
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      color: _billsWindowMode == 'WEEK' ? _accent : _surface,
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: _accent),
                    ),
                    child: Text(
                      _billsWindowMode == 'WEEK' ? 'Last 7 Days (${weekOnly.length})' : 'Today (${todayOnly.length}) ⇄ 7d',
                      style: TextStyle(fontSize: 11.5, fontWeight: FontWeight.w800, color: _billsWindowMode == 'WEEK' ? Colors.black : _accent),
                    ),
                  ),
                ),
              ),
              ...['ALL', ...kPaymentModes].map((p) {
              final act = _salesFilter == p;
              return Padding(
                padding: const EdgeInsets.only(right: 8),
                child: InkWell(
                  borderRadius: BorderRadius.circular(20),
                  onTap: () => setState(() => _salesFilter = p),
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 14),
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      color: act ? _ctaBg : _surface,
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: _border),
                    ),
                    child: Text(p, style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: act ? _ctaFg : null)),
                  ),
                ),
              );
            }),
            ],
          ),
        ),
        const SizedBox(height: 10),
        Expanded(
          child: filtered.isEmpty
              ? Center(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.receipt_long_rounded, size: 46, color: _muted),
                      const SizedBox(height: 8),
                      Text(
                        s.t('Fresh Day! No bills yet today.', 'புது நாள்! இன்று இன்னும் பில் இல்லை.'),
                        style: TextStyle(color: _muted, fontWeight: FontWeight.w700),
                      ),
                      if (s.isAdmin && oldBillsCount > 0) ...[
                        const SizedBox(height: 12),
                        OutlinedButton.icon(
                          onPressed: () => showOldBillsArchiveSheet(context, s),
                          icon: Icon(Icons.history_rounded, size: 16, color: _accent),
                          label: Text('View Old Bills ($oldBillsCount)', style: TextStyle(color: _accent, fontWeight: FontWeight.w700)),
                        ),
                      ],
                    ],
                  ),
                )
              : ListView.builder(
            padding: const EdgeInsets.fromLTRB(18, 4, 18, 160),
            itemCount: filtered.length,
            itemBuilder: (_, idx) {
              final sale = filtered[idx];
              return Card(
                margin: const EdgeInsets.only(bottom: 10),
                child: ListTile(
                  onTap: () => showBillReceiptPngSheet(context, s, sale),
                  contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                  title: Text(sale.itemName, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14), maxLines: 1, overflow: TextOverflow.ellipsis),
                  subtitle: Padding(
                    padding: const EdgeInsets.only(top: 4),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Wrap(
                          spacing: 6,
                          runSpacing: 4,
                          children: [
                            Text('${sale.size} × ${sale.qty}', style: TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: _accent)),
                            Text('• ${sale.payment}', style: TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: _green)),
                            if (sale.discount > 0)
                              Text('• Less ${formatInr(sale.discount)}', style: TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: _rose)),
                          ],
                        ),
                        const SizedBox(height: 2),
                        Text(
                          '${sale.date} ${sale.time} • By ${sale.soldBy}${sale.customerName.isNotEmpty ? ' • ${sale.customerName}' : ''}',
                          style: TextStyle(fontSize: 10.5, color: _muted),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ],
                    ),
                  ),
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(formatInr(sale.totalSellPrice), style: TextStyle(fontWeight: FontWeight.w800, color: _green, fontSize: 14)),
                      IconButton(
                        icon: Icon(Icons.image_outlined, size: 19, color: _accent),
                        tooltip: 'Bill PNG',
                        onPressed: () => showBillReceiptPngSheet(context, s, sale),
                      ),
                      if (s.isAdmin)
                        IconButton(
                          icon: Icon(Icons.edit_outlined, size: 18, color: _accent),
                          tooltip: 'Edit Bill',
                          onPressed: () => _openEditBillDialog(s, sale),
                        ),
                      if (s.isAdmin)
                        IconButton(
                          icon: Icon(Icons.delete_outline_rounded, size: 18, color: _rose),
                          tooltip: 'Restore & Delete Bill',
                          onPressed: () async {
                            final reasonCtrl = TextEditingController();
                            final reason = await showDialog<String>(
                              context: context,
                              builder: (ctx) => AlertDialog(
                                title: const Text('Refund & Restore Stock'),
                                content: Column(
                                  mainAxisSize: MainAxisSize.min,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text('Cancel ${sale.id} (${formatInr(sale.totalSellPrice)}) & restore stock:'),
                                    const SizedBox(height: 10),
                                    TextField(
                                      controller: reasonCtrl,
                                      decoration: const InputDecoration(labelText: 'Restore Reason * (e.g. Customer returned)'),
                                    ),
                                  ],
                                ),
                                actions: [
                                  TextButton(onPressed: () => Navigator.pop(ctx, null), child: const Text('Keep Bill')),
                                  ElevatedButton(
                                    onPressed: () {
                                      if (reasonCtrl.text.trim().isEmpty) return;
                                      Navigator.pop(ctx, reasonCtrl.text.trim());
                                    },
                                    child: const Text('Confirm Restore'),
                                  ),
                                ],
                              ),
                            );
                            if (reason != null && reason.isNotEmpty) {
                              await s.refundSale(sale, reason: reason);
                              if (mounted) {
                                ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Restored ${sale.id} ($reason)')));
                              }
                            }
                          },
                        ),
                    ],
                  ),
                ),
              );
            },
          ),
        ),
      ],
    );
  }

  Future<void> _openEditBillDialog(PosStore s, SaleRecord sale) async {
    final discCtrl = TextEditingController(text: sale.discount.toStringAsFixed(0));
    final nameCtrl = TextEditingController(text: sale.customerName);
    final phoneCtrl = TextEditingController(text: sale.customerPhone);
    String pay = kPaymentModes.contains(sale.payment) ? sale.payment : 'Cash';
    final saved = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setSt) => AlertDialog(
          title: Text('Edit Bill ${sale.id}', style: const TextStyle(fontSize: 15.5, fontWeight: FontWeight.w800)),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                DropdownButtonFormField<String>(
                  initialValue: pay,
                  decoration: const InputDecoration(labelText: 'Payment Mode'),
                  items: kPaymentModes.map((m) => DropdownMenuItem(value: m, child: Text(m))).toList(),
                  onChanged: (v) {
                    if (v != null) setSt(() => pay = v);
                  },
                ),
                const SizedBox(height: 10),
                TextField(
                  controller: discCtrl,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(labelText: 'Less / Discount (₹)'),
                ),
                const SizedBox(height: 10),
                TextField(controller: nameCtrl, decoration: const InputDecoration(labelText: 'Customer Name')),
                const SizedBox(height: 10),
                TextField(controller: phoneCtrl, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: 'Customer Mobile')),
              ],
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
            ElevatedButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('Save Changes'),
            ),
          ],
        ),
      ),
    );
    if (saved == true) {
      await s.editSaleDetails(
        sale: sale,
        payment: pay,
        discount: double.tryParse(discCtrl.text) ?? sale.discount,
        customerName: nameCtrl.text,
        customerPhone: phoneCtrl.text,
      );
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Updated ${sale.id}!')));
      }
    }
  }

  void _showRestoreHistorySheet(PosStore s) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: _card,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (ctx) => DraggableScrollableSheet(
        expand: false,
        initialChildSize: 0.78,
        maxChildSize: 0.94,
        builder: (_, sc) => Padding(
          padding: const EdgeInsets.fromLTRB(18, 16, 18, 22),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    s.t('Restore History (${s.restoreLogs.length})', 'ரீஸ்டோர் வரலாறு (${s.restoreLogs.length})'),
                    style: TextStyle(fontSize: 16.5, fontWeight: FontWeight.w900, color: _green),
                  ),
                  IconButton(icon: const Icon(Icons.close_rounded), onPressed: () => Navigator.pop(ctx)),
                ],
              ),
              const SizedBox(height: 8),
              Expanded(
                child: s.restoreLogs.isEmpty
                    ? Center(child: Text(s.t('No restore records yet.', 'ரீஸ்டோர் பதிவுகள் இல்லை.'), style: TextStyle(color: _muted)))
                    : ListView.builder(
                        controller: sc,
                        itemCount: s.restoreLogs.length,
                        itemBuilder: (_, i) {
                          final r = s.restoreLogs[i];
                          return Card(
                            margin: const EdgeInsets.only(bottom: 8),
                            child: ListTile(
                              dense: true,
                              title: Text('${r['itemName'] ?? ''} ${r['size'] != null ? '[${r['size']} x${r['qty'] ?? 1}]' : ''}', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 12.5)),
                              subtitle: Text('${s.t("Reason", "காரணம்")}: ${r['reason'] ?? ''} • ${r['restoredBy'] ?? ''} (${r['date'] ?? ''} ${r['time'] ?? ''})', style: TextStyle(fontSize: 11, color: _muted)),
                            ),
                          );
                        },
                      ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildAdminTab(PosStore s) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(18, 14, 18, 160),
      children: [
        Card(
          key: _keyAdminProfile,
          child: ListTile(
            contentPadding: const EdgeInsets.all(16),
            leading: Container(
              width: 48,
              height: 48,
              decoration: BoxDecoration(color: _accent.withAlpha(35), borderRadius: BorderRadius.circular(16)),
              child: Icon(Icons.verified_user_rounded, color: _accent),
            ),
            title: Text(s.userName, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
            subtitle: Text(s.role.name.toUpperCase(), style: TextStyle(color: _accent, fontSize: 11.5, fontWeight: FontWeight.w800)),
            trailing: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                if (s.userUid.isNotEmpty)
                  IconButton(
                    icon: Icon(Icons.copy_rounded, size: 18, color: _accent),
                    tooltip: 'Copy UID',
                    onPressed: () {
                      Clipboard.setData(ClipboardData(text: s.userUid));
                      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Copied User UID!')));
                    },
                  ),
                IconButton(
                  icon: Icon(Icons.logout_rounded, color: _rose),
                  tooltip: 'Sign Out',
                  onPressed: () async {
                    final ok = await showDialog<bool>(
                      context: context,
                      builder: (dCtx) => AlertDialog(
                        title: const Text('Sign Out?'),
                        content: const Text('Are you sure you want to log out of UNIVO WEAR?'),
                        actions: [
                          TextButton(onPressed: () => Navigator.pop(dCtx, false), child: const Text('Cancel')),
                          ElevatedButton(onPressed: () => Navigator.pop(dCtx, true), child: const Text('Sign Out')),
                        ],
                      ),
                    );
                    if (ok == true) await s.signOut();
                  },
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 14),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      children: [
                        Icon(Icons.system_update_rounded, color: _accent, size: 19),
                        const SizedBox(width: 8),
                        Text(s.t('App Updates', 'ஆப் அப்டேட்கள்'), style: TextStyle(fontWeight: FontWeight.w800, fontSize: 14.5)),
                      ],
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 3),
                      decoration: BoxDecoration(color: _green.withAlpha(26), borderRadius: BorderRadius.circular(10)),
                      child: Text('v$kAppVersionName (Build $kAppBuildNumber)', style: const TextStyle(fontSize: 10.5, fontWeight: FontWeight.w800, color: AppTheme.green)),
                    ),
                  ],
                ),

                const SizedBox(height: 12),
                Row(
                  children: [
                    Expanded(
                      child: OutlinedButton.icon(
                        style: OutlinedButton.styleFrom(shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
                        icon: const Icon(Icons.refresh_rounded, size: 16),
                        label: Text(s.t('Check for Updates', 'அப்டேட் செக் செய்'), style: TextStyle(fontWeight: FontWeight.w700, fontSize: 12)),
                        onPressed: () async {
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(content: Text('Checking for new UNIVO WEAR updates...')),
                          );
                          final info = await checkForAppUpdate(s);
                          if (!mounted) return;
                          if (info != null) {
                            await showUpdateAvailableSheet(context, s, info);
                          } else {
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(content: Text('You are on the latest version (v$kAppVersionName)!')),
                            );
                          }
                        },
                      ),
                    ),
                    if (s.role == UserRole.owner) ...[
                      const SizedBox(width: 8),
                      ElevatedButton.icon(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: _accent,
                          foregroundColor: const Color(0xFF0A0B0E),
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                        ),
                        icon: const Icon(Icons.campaign_rounded, size: 16),
                        label: const Text('Push Update', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 12)),
                        onPressed: () => showManualPushUpdateDialog(context, s),
                      ),
                    ],
                  ],
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 14),
        Card(
          child: Column(
            children: [
              ListTile(
                leading: Icon(Icons.menu_book_rounded, color: _accent),
                title: Text(s.t('How to Use & App Guide', 'பயன்படுத்தும் முறை (வழிகாட்டி)'), style: TextStyle(fontWeight: FontWeight.w800, fontSize: 14)),
                trailing: const Icon(Icons.chevron_right_rounded),
                onTap: () => showHowToUseSheet(context, s),
              ),
              Divider(height: 1, color: _border),
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 12, 16, 14),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(decodeHiddenText(kDevTagEncoded), style: TextStyle(fontWeight: FontWeight.w900, fontSize: 13, color: _accent)),
                        Text('v$kAppVersionName', style: TextStyle(fontSize: 11, color: _muted, fontWeight: FontWeight.w700)),
                      ],
                    ),
                    const SizedBox(height: 6),
                    InkWell(
                      onTap: () => launchUrl(Uri.parse('mailto:${decodeHiddenText(kDevMailEncoded)}')),
                      child: Row(
                        children: [
                          Icon(Icons.email_outlined, size: 14, color: _muted),
                          const SizedBox(width: 6),
                          Text('Support: ${decodeHiddenText(kDevMailEncoded)}', style: TextStyle(fontSize: 12, color: _muted)),
                        ],
                      ),
                    ),
                    const SizedBox(height: 4),
                    InkWell(
                      onTap: () => launchUrl(Uri.parse('tel:${decodeHiddenText(kDevTelEncoded).replaceAll(' ', '')}')),
                      child: Row(
                        children: [
                          Icon(Icons.phone_outlined, size: 14, color: _muted),
                          const SizedBox(width: 6),
                          Text('Contact: ${decodeHiddenText(kDevTelEncoded)}', style: TextStyle(fontSize: 12, color: _muted)),
                        ],
                      ),
                    ),
                    const SizedBox(height: 4),
                    InkWell(
                      onTap: () => launchUrl(Uri.parse('https://instagram.com/${decodeHiddenText(kDevInstaEncoded)}'), mode: LaunchMode.externalApplication),
                      child: Row(
                        children: [
                          Icon(Icons.camera_alt_outlined, size: 14, color: _accent),
                          const SizedBox(width: 6),
                          Text('Instagram: @${decodeHiddenText(kDevInstaEncoded)}', style: TextStyle(fontSize: 12, color: _accent, fontWeight: FontWeight.w700)),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 14),
        if (s.isAdmin) ...[
          Card(
            child: Padding(
              padding: const EdgeInsets.all(18),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(s.t('Staff Counter Controls', 'ஸ்டாஃப் கட்டுப்பாடுகள்'), style: TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
                  const SizedBox(height: 16),
                  Row(
                    children: [
                      Expanded(child: TextField(controller: _discCtrl, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Max Staff Bargain (₹)'))),
                      const SizedBox(width: 12),
                      Expanded(child: TextField(controller: _commCtrl, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Staff Commission (%)'))),
                    ],
                  ),
                  const SizedBox(height: 16),
                  SizedBox(
                    width: double.infinity,
                    height: 48,
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: _ctaBg,
                        foregroundColor: _ctaFg,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                      ),
                      onPressed: () async {
                        final d = double.tryParse(_discCtrl.text) ?? 200;
                        final c = double.tryParse(_commCtrl.text) ?? 2;
                        await s.saveShopConfig(maxDisc: d < 0 ? 0 : d, commPct: c < 0 ? 0 : c);
                        if (mounted) {
                          ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Shop rules synced to all staff devices!')));
                        }
                      },
                      child: const Text('Save & Sync Shop Rules', style: TextStyle(fontWeight: FontWeight.w800)),
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 14),
          Builder(builder: (_) {
            final monthPfx = DateFormat('yyyy-MM').format(_now);
            final mSales = s.sales.where((x) => x.date.startsWith(monthPfx) || x.createdAt.startsWith(monthPfx));
            final byStaff = <String, Map<String, double>>{};
            for (final x in mSales) {
              final st = x.soldBy.isEmpty ? 'Staff' : x.soldBy;
              final rec = byStaff.putIfAbsent(st, () => {'rev': 0, 'bills': 0, 'less': 0});
              rec['rev'] = rec['rev']! + x.totalSellPrice;
              rec['bills'] = rec['bills']! + 1;
              rec['less'] = rec['less']! + x.discount;
            }
            final ranked = byStaff.entries.toList()..sort((a, b) => b.value['rev']!.compareTo(a.value['rev']!));
            return Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text('Staff Sales & Commission (${DateFormat('MMM').format(_now)})', style: TextStyle(fontWeight: FontWeight.w800, color: _accent)),
                        Text('${s.commissionPct.toStringAsFixed(1)}%', style: TextStyle(fontSize: 11, fontWeight: FontWeight.w800, color: _muted)),
                      ],
                    ),
                    const SizedBox(height: 8),
                    if (ranked.isEmpty)
                      Text('No staff sales recorded this month yet.', style: TextStyle(fontSize: 12, color: _muted))
                    else
                      ...ranked.take(6).map((e) {
                        final rev = e.value['rev']!;
                        final cnt = e.value['bills']!.round();
                        final less = e.value['less']!;
                        final comm = rev * s.commissionPct / 100;
                        return Padding(
                          padding: const EdgeInsets.symmetric(vertical: 4),
                          child: Row(
                            children: [
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(e.key, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 13)),
                                    Text('$cnt bills • Less ${formatInr(less)} • Comm ${formatInr(comm)}', style: TextStyle(fontSize: 10.5, color: _muted)),
                                  ],
                                ),
                              ),
                              Text(formatInr(rev), style: TextStyle(fontWeight: FontWeight.w900, fontSize: 13.5, color: _green)),
                            ],
                          ),
                        );
                      }),
                  ],
                ),
              ),
            );
          }),
          const SizedBox(height: 14),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(18),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(s.t('Old Bills Archive & PDF', 'பழைய பில்கள் & PDF'), style: TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                        decoration: BoxDecoration(
                          color: (s.daysUntilMonthlyAutoDelete <= 3 ? _rose : _green).withAlpha(28),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Text(
                          '${s.daysUntilMonthlyAutoDelete}d to Auto-Delete',
                          style: TextStyle(
                            fontSize: 10,
                            fontWeight: FontWeight.w800,
                            color: s.daysUntilMonthlyAutoDelete <= 3 ? _rose : _green,
                          ),
                        ),
                      ),
                    ],
                  ),

                  const SizedBox(height: 12),
                  Row(
                    children: [
                      Expanded(
                        child: ElevatedButton.icon(
                          style: ElevatedButton.styleFrom(
                            backgroundColor: _accent,
                            foregroundColor: const Color(0xFF0A0B0E),
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                          ),
                          icon: const Icon(Icons.picture_as_pdf_rounded, size: 17),
                          label: Text(s.t('Open Old Bills & Save PDF', 'பழைய பில்கள் & PDF திற'), style: TextStyle(fontWeight: FontWeight.w800, fontSize: 12.5)),
                          onPressed: () => showOldBillsArchiveSheet(context, s),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 14),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text('Missing / Loss Log (${s.missing.length})', style: TextStyle(fontWeight: FontWeight.w800, color: _rose)),
                      TextButton(onPressed: () => showReportMissingSheet(context, s), child: const Text('+ Report')),
                    ],
                  ),
                  if (s.missing.isEmpty)
                    Text('No missing pieces logged.', style: TextStyle(fontSize: 12, color: _muted))
                  else
                    ...s.missing.take(5).map((m) => ListTile(
                          contentPadding: EdgeInsets.zero,
                          title: Text('${m.itemName} [${m.size} x${m.qty}]', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
                          subtitle: Text('${m.reason} • -${formatInr(m.lossAmount)}', style: TextStyle(fontSize: 11, color: _muted)),
                          trailing: TextButton(
                            onPressed: () async {
                              final rCtrl = TextEditingController();
                              final reason = await showDialog<String>(
                                context: context,
                                builder: (ctx) => AlertDialog(
                                  title: const Text('Why Restore to Stock?'),
                                  content: TextField(
                                    controller: rCtrl,
                                    decoration: const InputDecoration(labelText: 'Restore Reason * (e.g. Found in trial room)'),
                                  ),
                                  actions: [
                                    TextButton(onPressed: () => Navigator.pop(ctx, null), child: const Text('Cancel')),
                                    ElevatedButton(
                                      onPressed: () {
                                        if (rCtrl.text.trim().isEmpty) return;
                                        Navigator.pop(ctx, rCtrl.text.trim());
                                      },
                                      child: const Text('Restore Now'),
                                    ),
                                  ],
                                ),
                              );
                              if (reason != null && reason.isNotEmpty) {
                                await s.restoreMissing(m, reason: reason);
                                if (mounted) {
                                  ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Restored (${m.size}) • Reason: $reason')));
                                }
                              }
                            },
                            child: Text('Restore', style: TextStyle(color: _green, fontWeight: FontWeight.bold)),
                          ),
                        )),
                ],
              ),
            ),
          ),
          const SizedBox(height: 14),
          Card(
            child: ListTile(
              leading: Icon(Icons.history_rounded, color: _green),
              title: Text(
                s.t('Restore History (${s.restoreLogs.length})', 'ரீஸ்டோர் வரலாறு (${s.restoreLogs.length})'),
                style: TextStyle(fontWeight: FontWeight.w800, fontSize: 14, color: _green),
              ),
              trailing: OutlinedButton(
                style: OutlinedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  minimumSize: Size.zero,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                ),
                onPressed: () => _showRestoreHistorySheet(s),
                child: Text(s.t('View History', 'வரலாறு பார்'), style: const TextStyle(fontSize: 11.5, fontWeight: FontWeight.w800)),
              ),
            ),
          ),
          const SizedBox(height: 14),
          if (s.role == UserRole.owner)
          Card(
            child: ListTile(
              leading: Icon(Icons.admin_panel_settings_rounded, color: _accent),
              title: Text(s.t('Add Admin by User UID', 'புது Admin சேர் (UID)'), style: TextStyle(fontWeight: FontWeight.w700)),
              subtitle: Text('Grant full edit access to a partner', style: TextStyle(fontSize: 11, color: _muted)),
              onTap: () {
                final uidCtrl = TextEditingController();
                final nmCtrl = TextEditingController();
                showDialog(
                  context: context,
                  builder: (ctx) => AlertDialog(
                    title: const Text('Grant Admin Access'),
                    content: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        TextField(controller: nmCtrl, decoration: const InputDecoration(labelText: 'Admin Name')),
                        const SizedBox(height: 8),
                        TextField(controller: uidCtrl, decoration: const InputDecoration(labelText: 'Paste User UID')),
                      ],
                    ),
                    actions: [
                      TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
                      ElevatedButton(
                        onPressed: () async {
                          if (uidCtrl.text.trim().isEmpty) return;
                          await s.grantAdminRole(uidCtrl.text, nmCtrl.text);
                          if (ctx.mounted) Navigator.pop(ctx);
                          if (mounted) {
                            ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Admin role granted!')));
                          }
                        },
                        child: const Text('Grant Admin'),
                      ),
                    ],
                  ),
                );
              },
            ),
          ),
          const SizedBox(height: 14),
          Card(
            child: ListTile(
              leading: Icon(Icons.delete_forever_rounded, color: _rose),
              title: Text('Clear All Cloud Data', style: TextStyle(color: _rose, fontWeight: FontWeight.w700)),
              onTap: () async {
                final ok = await showDialog<bool>(
                  context: context,
                  builder: (ctx) => AlertDialog(
                    title: const Text('Delete All Cloud Data?'),
                    content: const Text('All stock, sales, khata, and records will be permanently deleted.'),
                    actions: [
                      TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
                      ElevatedButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Delete All')),
                    ],
                  ),
                );
                if (ok == true) await s.clearAllCloudData();
              },
            ),
          ),
        ],
      ],
    );
  }
}
