import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../core/app_theme.dart';
import '../core/constants.dart';
import '../models/pos_models.dart';
import '../services/pos_store.dart';
import '../sheets/live_tour_overlay.dart';

class ShopCalculatorScreen extends StatefulWidget {
  final PosStore store;
  const ShopCalculatorScreen({super.key, required this.store});

  @override
  State<ShopCalculatorScreen> createState() => _ShopCalculatorScreenState();
}

class _ShopCalculatorScreenState extends State<ShopCalculatorScreen> with SingleTickerProviderStateMixin {
  late final TabController _tabCtrl;
  final GlobalKey _keyCalcTabs = GlobalKey();

  // Normal calculator state
  String _expr = '';
  String _display = '0';
  final List<String> _history = [];

  // Smart Stock & Profit Calculator state
  StockItem? _selectedStock;
  final _mrpCtrl = TextEditingController(text: '1000');
  final _costCtrl = TextEditingController(text: '600');
  final _qtyCtrl = TextEditingController(text: '1');
  final _lessCtrl = TextEditingController(text: '0');
  int _gstPct = 0;

  @override
  void initState() {
    super.initState();
    _tabCtrl = TabController(length: 2, vsync: this);
  }

  @override
  void dispose() {
    _tabCtrl.dispose();
    _mrpCtrl.dispose();
    _costCtrl.dispose();
    _qtyCtrl.dispose();
    _lessCtrl.dispose();
    super.dispose();
  }

  void _tapKey(String k) {
    HapticFeedback.lightImpact();
    setState(() {
      if (k == 'AC') {
        _expr = '';
        _display = '0';
      } else if (k == '⌫') {
        if (_expr.isNotEmpty) {
          _expr = _expr.substring(0, _expr.length - 1);
          _display = _expr.isEmpty ? '0' : _expr;
        }
      } else if (k == '=') {
        if (_expr.isEmpty) return;
        final res = _evalExpression(_expr);
        if (res != null) {
          final clean = res == res.roundToDouble() ? res.round().toString() : res.toStringAsFixed(2);
          _history.insert(0, '$_expr = $clean');
          if (_history.length > 8) _history.removeLast();
          _display = clean;
          _expr = clean;
        } else {
          _display = 'Error';
        }
      } else {
        if (_display == 'Error') _expr = '';
        _expr += k;
        _display = _expr;
      }
    });
  }

  double? _evalExpression(String raw) {
    try {
      final s = raw.replaceAll('×', '*').replaceAll('÷', '/').replaceAll(' ', '');
      final tokens = <String>[];
      String numBuf = '';
      for (int i = 0; i < s.length; i++) {
        final ch = s[i];
        if ('0123456789.'.contains(ch) || (ch == '-' && (i == 0 || '+-*/'.contains(s[i - 1])))) {
          numBuf += ch;
        } else if (ch == '%') {
          if (numBuf.isNotEmpty) {
            final v = double.parse(numBuf) / 100.0;
            numBuf = v.toString();
          }
        } else if ('+-*/'.contains(ch)) {
          if (numBuf.isNotEmpty) {
            tokens.add(numBuf);
            numBuf = '';
          }
          tokens.add(ch);
        }
      }
      if (numBuf.isNotEmpty) tokens.add(numBuf);
      if (tokens.isEmpty) return 0;

      // Pass 1: * and /
      final pass1 = <String>[];
      int i = 0;
      while (i < tokens.length) {
        if (tokens[i] == '*' || tokens[i] == '/') {
          final left = double.parse(pass1.removeLast());
          final right = double.parse(tokens[i + 1]);
          final out = tokens[i] == '*' ? left * right : (right == 0 ? 0.0 : left / right);
          pass1.add(out.toString());
          i += 2;
        } else {
          pass1.add(tokens[i]);
          i++;
        }
      }
      // Pass 2: + and -
      double total = double.parse(pass1[0]);
      for (int j = 1; j < pass1.length; j += 2) {
        final op = pass1[j];
        final val = double.parse(pass1[j + 1]);
        total = op == '+' ? total + val : total - val;
      }
      return total;
    } catch (_) {
      return null;
    }
  }

  void _showCalcHelp(BuildContext context) {
    showDialog(
      context: context,
      builder: (dCtx) => AlertDialog(
        title: const Row(
          children: [
            Icon(Icons.lightbulb_rounded, color: AppTheme.gold),
            SizedBox(width: 8),
            Text('How to Use Calculator', style: TextStyle(fontSize: 15.5, fontWeight: FontWeight.w800)),
          ],
        ),
        content: const Text(
          '• Normal Tab: Quick math (+, -, ×, ÷, %) with calculation history.\n\n'
          '• Stock Calc Tab: Pick any dress from your live Stock (or enter custom MRP/Qty/Less/GST) to instantly calculate customer payable price, discount %, and profit margin!',
          style: TextStyle(fontSize: 12.5, height: 1.45),
        ),
        actions: [
          ElevatedButton(onPressed: () => Navigator.pop(dCtx), child: const Text('Got it')),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final s = widget.store;
    final accent = s.isDark ? AppTheme.gold : AppTheme.goldLightMode;
    final muted = s.isDark ? const Color(0xFF94A3B8) : const Color(0xFF64748B);
    final surface = s.isDark ? AppTheme.darkSurface : AppTheme.lightSurface;
    final border = s.isDark ? AppTheme.darkBorder : AppTheme.lightBorder;

    return Scaffold(
      appBar: AppBar(
        title: Text(s.t('Shop Calculator', 'கடை கால்குலேட்டர்'), style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16)),
        actions: [
          IconButton(
            icon: Icon(Icons.lightbulb_outline_rounded, color: accent),
            tooltip: 'Page Guide',
            onPressed: () => showLiveArrowTour(context, s, [
              LiveTourStep(
                targetKey: _keyCalcTabs,
                title: s.t('2-Mode Shop Calculator', '2-மோட் கடை கால்குலேட்டர்'),
                description: s.t(
                  'Switch between Normal Calc (daily math) and Stock & Profit Calc (pick any dress from your shop stock to auto-calculate total cost, discount, GST & net profit!).',
                  'சாதாரண கணக்கு (Normal Calc) மற்றும் ஸ்டாக் & லாப கணக்கு (கடை ஸ்டாக் செலக்ட் பண்ணி காஸ்ட், டிஸ்கவுண்ட், GST & நிகர லாபம் கணக்கிட) இடையே மாத்துங்க!',
                ),
              ),
            ]),
          ),
        ],
        bottom: TabBar(
          key: _keyCalcTabs,
          controller: _tabCtrl,
          indicatorColor: accent,
          labelColor: accent,
          unselectedLabelColor: muted,
          tabs: [
            Tab(text: s.t('Normal Calc', 'சாதாரண கணக்கு')),
            Tab(text: s.t('Stock & Profit Calc', 'ஸ்டாக் & லாப கணக்கு')),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabCtrl,
        children: [
          // TAB 1: Normal Calculator
          Center(
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 460),
              child: Column(
                children: [
                  Expanded(
                    flex: 2,
                    child: Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(20),
                      alignment: Alignment.bottomRight,
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.end,
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          if (_history.isNotEmpty)
                            Text(_history.first, style: TextStyle(fontSize: 13, color: muted)),
                          const SizedBox(height: 8),
                          FittedBox(
                            fit: BoxFit.scaleDown,
                            child: Text(
                              _display,
                              style: const TextStyle(fontSize: 44, fontWeight: FontWeight.w900),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Expanded(
                    flex: 4,
                    child: Padding(
                      padding: const EdgeInsets.fromLTRB(14, 0, 14, 18),
                      child: GridView.count(
                        crossAxisCount: 4,
                        mainAxisSpacing: 10,
                        crossAxisSpacing: 10,
                        childAspectRatio: 1.25,
                        children: [
                          'AC', '⌫', '%', '÷',
                          '7', '8', '9', '×',
                          '4', '5', '6', '-',
                          '1', '2', '3', '+',
                          '00', '0', '.', '=',
                        ].map((k) {
                          final isEq = k == '=';
                          final isOp = '÷×-+%'.contains(k);
                          final isClear = k == 'AC' || k == '⌫';
                          return ElevatedButton(
                            style: ElevatedButton.styleFrom(
                              backgroundColor: isEq ? accent : (isOp ? accent.withAlpha(35) : surface),
                              foregroundColor: isEq ? Colors.black : (isClear ? AppTheme.rose : (isOp ? accent : null)),
                              elevation: 0,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(18),
                                side: BorderSide(color: border),
                              ),
                            ),
                            onPressed: () => _tapKey(k),
                            child: Text(k, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
                          );
                        }).toList(),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),

          // TAB 2: Smart Stock & Profit Calculator
          Center(
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 560),
              child: Builder(builder: (_) {
                final mrp = double.tryParse(_mrpCtrl.text) ?? 0;
                final cost = double.tryParse(_costCtrl.text) ?? 0;
                final qty = int.tryParse(_qtyCtrl.text) ?? 1;
                final less = double.tryParse(_lessCtrl.text) ?? 0;
                final gross = mrp * qty;
                final taxable = (gross - less) < 0 ? 0.0 : (gross - less);
                final gstAmt = (taxable * _gstPct / 100).roundToDouble();
                final finalPay = taxable + gstAmt;
                final totCost = cost * qty;
                final profit = taxable - totCost;
                final margin = taxable > 0 ? (profit / taxable * 100) : 0.0;

                return ListView(
                  padding: const EdgeInsets.all(18),
                  children: [
                    DropdownButtonFormField<String>(
                      initialValue: _selectedStock?.id,
                      decoration: const InputDecoration(labelText: 'Pick From Live Stock (Optional)'),
                      items: s.stock.map((st) => DropdownMenuItem(
                            value: st.id,
                            child: Text('${st.name} (${formatInr(st.sellPrice)})', overflow: TextOverflow.ellipsis),
                          )).toList(),
                      onChanged: (id) {
                        final matches = s.stock.where((x) => x.id == id).toList();
                        if (matches.isNotEmpty) {
                          setState(() {
                            _selectedStock = matches.first;
                            _mrpCtrl.text = matches.first.sellPrice.toStringAsFixed(0);
                            _costCtrl.text = matches.first.costPrice.toStringAsFixed(0);
                          });
                        }
                      },
                    ),
                    const SizedBox(height: 12),
                    Row(
                      children: [
                        Expanded(
                          child: TextField(
                            controller: _mrpCtrl,
                            keyboardType: TextInputType.number,
                            decoration: const InputDecoration(labelText: 'Unit MRP (₹)'),
                            onChanged: (_) => setState(() {}),
                          ),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: TextField(
                            controller: _qtyCtrl,
                            keyboardType: TextInputType.number,
                            decoration: const InputDecoration(labelText: 'Qty (pcs)'),
                            onChanged: (_) => setState(() {}),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 10),
                    Row(
                      children: [
                        Expanded(
                          child: TextField(
                            controller: _lessCtrl,
                            keyboardType: TextInputType.number,
                            decoration: const InputDecoration(labelText: 'Less / Discount (₹)'),
                            onChanged: (_) => setState(() {}),
                          ),
                        ),
                        if (s.isAdmin) ...[
                          const SizedBox(width: 10),
                          Expanded(
                            child: TextField(
                              controller: _costCtrl,
                              keyboardType: TextInputType.number,
                              decoration: const InputDecoration(labelText: 'Unit Cost (₹)'),
                              onChanged: (_) => setState(() {}),
                            ),
                          ),
                        ],
                      ],
                    ),
                    const SizedBox(height: 10),
                    Wrap(
                      spacing: 8,
                      children: [0, 5, 12].map((g) => ChoiceChip(
                            label: Text(g == 0 ? 'No GST' : 'GST $g%', style: const TextStyle(fontSize: 11.5, fontWeight: FontWeight.w700)),
                            selected: _gstPct == g,
                            onSelected: (_) => setState(() => _gstPct = g),
                          )).toList(),
                    ),
                    const SizedBox(height: 14),
                    Card(
                      child: Padding(
                        padding: const EdgeInsets.all(16),
                        child: Column(
                          children: [
                            _calcRow('Gross MRP ($qty pcs)', formatInr(gross)),
                            if (less > 0) _calcRow('Less / Discount', '-${formatInr(less)}', col: AppTheme.rose),
                            if (gstAmt > 0) _calcRow('GST ($_gstPct%)', '+${formatInr(gstAmt)}', col: accent),
                            const Divider(height: 20),
                            _calcRow('FINAL CUSTOMER PAY', formatInr(finalPay), col: AppTheme.green, big: true),
                            if (s.isAdmin) ...[
                              const Divider(height: 20),
                              _calcRow('Total Cost', formatInr(totCost), col: muted),
                              _calcRow('Net Profit (${margin.toStringAsFixed(1)}%)', formatInr(profit), col: profit >= 0 ? accent : AppTheme.rose, big: true),
                            ],
                          ],
                        ),
                      ),
                    ),
                  ],
                );
              }),
            ),
          ),
        ],
      ),
    );
  }

  Widget _calcRow(String l, String v, {Color? col, bool big = false}) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 4),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(l, style: TextStyle(fontSize: big ? 13.5 : 12, fontWeight: big ? FontWeight.w800 : FontWeight.w500)),
            Text(v, style: TextStyle(fontSize: big ? 18 : 13.5, fontWeight: FontWeight.w900, color: col)),
          ],
        ),
      );
}
