import 'package:flutter/material.dart';
import '../core/app_theme.dart';
import '../core/constants.dart';

class LuxurySplashScreen extends StatefulWidget {
  final bool isDark;
  final VoidCallback onFinished;
  const LuxurySplashScreen({super.key, required this.isDark, required this.onFinished});

  @override
  State<LuxurySplashScreen> createState() => _LuxurySplashScreenState();
}

class _LuxurySplashScreenState extends State<LuxurySplashScreen> with SingleTickerProviderStateMixin {
  late final AnimationController _ctrl;
  late final Animation<double> _fade;
  late final Animation<double> _scale;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 900));
    _fade = CurvedAnimation(parent: _ctrl, curve: Curves.easeOut);
    _scale = Tween<double>(begin: 0.84, end: 1.0).animate(CurvedAnimation(parent: _ctrl, curve: Curves.easeOutCubic));
    _ctrl.forward();
    Future.delayed(const Duration(milliseconds: 1550), () {
      if (mounted) widget.onFinished();
    });
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final bg = widget.isDark ? AppTheme.darkBg : AppTheme.lightBg;
    final accent = widget.isDark ? AppTheme.gold : AppTheme.goldLightMode;
    final textCol = widget.isDark ? const Color(0xFFF8FAFC) : const Color(0xFF111318);
    final muted = widget.isDark ? const Color(0xFF8B92A5) : const Color(0xFF667085);

    return Scaffold(
      backgroundColor: bg,
      body: Center(
        child: FadeTransition(
          opacity: _fade,
          child: ScaleTransition(
            scale: _scale,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 112,
                  height: 112,
                  padding: const EdgeInsets.all(6),
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(color: accent.withAlpha(140), width: 1.6),
                    boxShadow: [
                      BoxShadow(color: accent.withAlpha(55), blurRadius: 34, spreadRadius: 4),
                    ],
                  ),
                  child: ClipOval(
                    child: Image.asset('assets/images/univo_logo.png', fit: BoxFit.cover),
                  ),
                ),
                const SizedBox(height: 22),
                Text(
                  'UNIVO WEAR',
                  style: TextStyle(
                    fontSize: 26,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 3.6,
                    fontFamily: 'Georgia',
                    color: textCol,
                  ),
                ),
                const SizedBox(height: 6),
                Text(
                  'ATELIER LUXURY POS • v$kAppVersionName',
                  style: TextStyle(
                    fontSize: 10.5,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 2.2,
                    color: accent,
                  ),
                ),
                const SizedBox(height: 28),
                SizedBox(
                  width: 130,
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(4),
                    child: LinearProgressIndicator(
                      minHeight: 3,
                      backgroundColor: muted.withAlpha(40),
                      valueColor: AlwaysStoppedAnimation<Color>(accent),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
