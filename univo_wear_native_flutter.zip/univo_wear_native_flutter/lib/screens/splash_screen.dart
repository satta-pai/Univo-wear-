import 'dart:math' as math;
import 'dart:ui' show PathMetric;
import 'package:flutter/material.dart';
import '../core/app_theme.dart';
import '../core/constants.dart';

class LuxurySplashScreen extends StatefulWidget {
  final bool isDark;
  final VoidCallback onFinished;
  const LuxurySplashScreen({super.key, required this.isDark, required this.onFinished});

  @override
  State<LuxurySplashScreen> createState() => _LuxurySplashScreenState();
}

class _LuxurySplashScreenState extends State<LuxurySplashScreen>
    with SingleTickerProviderStateMixin {
  late final AnimationController _ctrl;
  late final Animation<double> _stitchProgress;
  late final Animation<double> _hangerProgress;
  late final Animation<double> _drapeOpacity;
  late final Animation<double> _sheenProgress;
  late final Animation<double> _titleProgress;
  late final Animation<double> _subtitleProgress;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2150),
    );

    _stitchProgress = CurvedAnimation(
      parent: _ctrl,
      curve: const Interval(0.00, 0.52, curve: Curves.easeInOutCubic),
    );
    _hangerProgress = CurvedAnimation(
      parent: _ctrl,
      curve: const Interval(0.06, 0.58, curve: Curves.easeInOutCubic),
    );
    _drapeOpacity = CurvedAnimation(
      parent: _ctrl,
      curve: const Interval(0.36, 0.72, curve: Curves.easeOutCubic),
    );
    _sheenProgress = CurvedAnimation(
      parent: _ctrl,
      curve: const Interval(0.45, 0.92, curve: Curves.easeInOut),
    );
    _titleProgress = CurvedAnimation(
      parent: _ctrl,
      curve: const Interval(0.50, 0.86, curve: Curves.easeOutCubic),
    );
    _subtitleProgress = CurvedAnimation(
      parent: _ctrl,
      curve: const Interval(0.68, 1.00, curve: Curves.easeOut),
    );

    _ctrl.forward();
    Future.delayed(const Duration(milliseconds: 2450), () {
      if (mounted) widget.onFinished();
    });
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final bg = widget.isDark ? AppTheme.darkBg : AppTheme.lightBg;
    final accent = widget.isDark ? AppTheme.gold : AppTheme.goldLightMode;
    final accentSoft = widget.isDark ? const Color(0xFFF6DC9F) : const Color(0xFFD4A24C);
    final textCol = widget.isDark ? const Color(0xFFF8FAFC) : const Color(0xFF111318);
    final muted = widget.isDark ? const Color(0xFF8B92A5) : const Color(0xFF667085);

    return Scaffold(
      backgroundColor: bg,
      body: AnimatedBuilder(
        animation: _ctrl,
        builder: (context, _) {
          final titleT = _titleProgress.value;
          final subT = _subtitleProgress.value;
          final letterSpace = 7.4 - (3.6 * titleT);
          final titleOffsetY = 14.0 * (1.0 - titleT);

          return Stack(
            fit: StackFit.expand,
            children: [
              // Subtle ambient atelier radial glow
              DecoratedBox(
                decoration: BoxDecoration(
                  gradient: RadialGradient(
                    center: const Alignment(0, -0.14),
                    radius: 0.85,
                    colors: [
                      accent.withAlpha(widget.isDark ? 34 : 28),
                      bg.withAlpha(0),
                    ],
                  ),
                ),
              ),
              Center(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    SizedBox(
                      width: 176,
                      height: 176,
                      child: CustomPaint(
                        painter: _AtelierCouturePainter(
                          stitchT: _stitchProgress.value,
                          hangerT: _hangerProgress.value,
                          drapeT: _drapeOpacity.value,
                          sheenT: _sheenProgress.value,
                          accent: accent,
                          accentSoft: accentSoft,
                          isDark: widget.isDark,
                        ),
                      ),
                    ),
                    const SizedBox(height: 18),
                    Transform.translate(
                      offset: Offset(0, titleOffsetY),
                      child: Opacity(
                        opacity: titleT.clamp(0.0, 1.0),
                        child: Text(
                          'UNIVO WEAR',
                          style: TextStyle(
                            fontSize: 27,
                            fontWeight: FontWeight.w900,
                            letterSpacing: letterSpace,
                            fontFamily: 'Georgia',
                            color: textCol,
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(height: 10),
                    // Golden stitched hairline divider expanding from center
                    SizedBox(
                      width: 168 * subT,
                      height: 2,
                      child: CustomPaint(
                        painter: _StitchDividerPainter(color: accent),
                      ),
                    ),
                    const SizedBox(height: 10),
                    Opacity(
                      opacity: subT.clamp(0.0, 1.0),
                      child: Text(
                        'ATELIER DRESS BOUTIQUE  •  v$kAppVersionName',
                        style: TextStyle(
                          fontSize: 10.5,
                          fontWeight: FontWeight.w800,
                          letterSpacing: 2.3,
                          color: accent,
                        ),
                      ),
                    ),
                    const SizedBox(height: 6),
                    Opacity(
                      opacity: (subT * 0.85).clamp(0.0, 1.0),
                      child: Text(
                        'TAILORED FOR EVERY STYLE',
                        style: TextStyle(
                          fontSize: 9.5,
                          fontWeight: FontWeight.w600,
                          letterSpacing: 3.1,
                          color: muted,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}

class _AtelierCouturePainter extends CustomPainter {
  final double stitchT;
  final double hangerT;
  final double drapeT;
  final double sheenT;
  final Color accent;
  final Color accentSoft;
  final bool isDark;

  const _AtelierCouturePainter({
    required this.stitchT,
    required this.hangerT,
    required this.drapeT,
    required this.sheenT,
    required this.accent,
    required this.accentSoft,
    required this.isDark,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final cx = size.width / 2;
    final cy = size.height / 2;
    final radius = size.width * 0.44;

    // 1. Soft inner velvet medallion backing
    final discPaint = Paint()
      ..shader = RadialGradient(
        colors: [
          accent.withAlpha((28 * drapeT).round()),
          (isDark ? const Color(0xFF14161D) : const Color(0xFFF3EFE6)).withAlpha((210 * stitchT).round()),
        ],
      ).createShader(Rect.fromCircle(center: Offset(cx, cy), radius: radius));
    canvas.drawCircle(Offset(cx, cy), radius * 0.94, discPaint);

    // 2. Outer fine champagne ring + animated tailor's dashed stitch ring
    final outerRing = Paint()
      ..color = accent.withAlpha((90 * stitchT).round())
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.2;
    canvas.drawArc(
      Rect.fromCircle(center: Offset(cx, cy), radius: radius),
      -math.pi / 2,
      math.pi * 2 * stitchT,
      false,
      outerRing,
    );

    final stitchCount = 36;
    final visibleStitches = (stitchCount * stitchT).floor();
    final stitchPaint = Paint()
      ..color = accentSoft.withAlpha(210)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.4
      ..strokeCap = StrokeCap.round;
    final innerR = radius * 0.86;
    for (int i = 0; i < visibleStitches; i++) {
      final startAngle = -math.pi / 2 + (i * (2 * math.pi / stitchCount));
      final sweep = (2 * math.pi / stitchCount) * 0.48;
      canvas.drawArc(
        Rect.fromCircle(center: Offset(cx, cy), radius: innerR),
        startAngle,
        sweep,
        false,
        stitchPaint,
      );
    }

    // 3. Subtle draped dress / garment silk fold silhouette under the hanger
    if (drapeT > 0.01) {
      final dressPath = Path()
        ..moveTo(cx - 28, cy + 4)
        ..quadraticBezierTo(cx - 34, cy + 32, cx - 42, cy + 46)
        ..quadraticBezierTo(cx - 16, cy + 54, cx, cy + 49)
        ..quadraticBezierTo(cx + 16, cy + 54, cx + 42, cy + 46)
        ..quadraticBezierTo(cx + 34, cy + 32, cx + 28, cy + 4)
        ..close();

      final dressFill = Paint()
        ..shader = LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [
            accent.withAlpha((68 * drapeT).round()),
            accent.withAlpha((14 * drapeT).round()),
          ],
        ).createShader(Rect.fromLTWH(cx - 44, cy, 88, 56));
      canvas.drawPath(dressPath, dressFill);

      // Subtle pleated silk fold lines
      final foldPaint = Paint()
        ..color = accentSoft.withAlpha((95 * drapeT).round())
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.0
        ..strokeCap = StrokeCap.round;
      canvas.drawLine(Offset(cx - 12, cy + 12), Offset(cx - 18, cy + 45), foldPaint);
      canvas.drawLine(Offset(cx + 12, cy + 12), Offset(cx + 18, cy + 45), foldPaint);
    }

    // 4. Bespoke Couture Coat Hanger drawn live by golden tailoring thread
    final hangerPath = Path()
      // Hook curve from top
      ..moveTo(cx - 6, cy - 36)
      ..cubicTo(cx - 6, cy - 48, cx + 11, cy - 48, cx + 11, cy - 36)
      ..cubicTo(cx + 11, cy - 29, cx, cy - 28, cx, cy - 21)
      // Right shoulder sweep
      ..cubicTo(cx + 14, cy - 16, cx + 38, cy - 4, cx + 48, cy + 4)
      ..quadraticBezierTo(cx + 52, cy + 8, cx + 45, cy + 10)
      // Bottom trouser bar across to left
      ..lineTo(cx - 45, cy + 10)
      ..quadraticBezierTo(cx - 52, cy + 8, cx - 48, cy + 4)
      // Left shoulder sweep back to collar neck
      ..cubicTo(cx - 38, cy - 4, cx - 14, cy - 16, cx, cy - 21);

    final metrics = hangerPath.computeMetrics().toList();
    if (metrics.isNotEmpty && hangerT > 0.0) {
      final PathMetric m = metrics.first;
      final drawLen = m.length * hangerT;
      final partial = m.extractPath(0, drawLen);

      // Soft golden glow under thread
      final glowPaint = Paint()
        ..color = accent.withAlpha(90)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 6.0
        ..strokeCap = StrokeCap.round
        ..strokeJoin = StrokeJoin.round
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 5);
      canvas.drawPath(partial, glowPaint);

      // Crisp liquid-gold hanger thread
      final threadPaint = Paint()
        ..shader = LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [accentSoft, accent, accentSoft],
        ).createShader(Rect.fromCircle(center: Offset(cx, cy), radius: radius))
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2.8
        ..strokeCap = StrokeCap.round
        ..strokeJoin = StrokeJoin.round;
      canvas.drawPath(partial, threadPaint);

      // Glowing golden needle-tip spark while actively stitching
      if (hangerT < 0.99) {
        final tangent = m.getTangentForOffset(drawLen);
        if (tangent != null) {
          final pos = tangent.position;
          canvas.drawCircle(
            pos,
            7.5,
            Paint()
              ..color = accentSoft.withAlpha(110)
              ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 4),
          );
          canvas.drawCircle(pos, 2.8, Paint()..color = Colors.white);
        }
      }
    }

    // 5. Crisp Serif "UW" Couture Monogram inside the draped silhouette
    if (drapeT > 0.05) {
      final tp = TextPainter(
        text: TextSpan(
          text: 'UW',
          style: TextStyle(
            fontSize: 22,
            fontWeight: FontWeight.w900,
            letterSpacing: 3.2,
            fontFamily: 'Georgia',
            color: accentSoft.withAlpha((255 * drapeT).round()),
          ),
        ),
        textDirection: TextDirection.ltr,
      )..layout();
      tp.paint(canvas, Offset(cx - tp.width / 2 + 1.5, cy + 16));
    }

    // 6. Diagonal silk-sheen light sweep clipped to the circular crest
    if (sheenT > 0.02 && sheenT < 0.98) {
      canvas.save();
      canvas.clipPath(
        Path()..addOval(Rect.fromCircle(center: Offset(cx, cy), radius: radius)),
      );
      final sweepX = -size.width + (size.width * 3.0 * sheenT);
      final sheenPaint = Paint()
        ..shader = LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            Colors.white.withAlpha(0),
            accentSoft.withAlpha(75),
            Colors.white.withAlpha(0),
          ],
          stops: const [0.0, 0.5, 1.0],
        ).createShader(Rect.fromLTWH(sweepX, 0, 56, size.height));
      canvas.drawRect(Rect.fromLTWH(sweepX, 0, 56, size.height), sheenPaint);
      canvas.restore();
    }
  }

  @override
  bool shouldRepaint(covariant _AtelierCouturePainter old) =>
      old.stitchT != stitchT ||
      old.hangerT != hangerT ||
      old.drapeT != drapeT ||
      old.sheenT != sheenT ||
      old.isDark != isDark;
}

class _StitchDividerPainter extends CustomPainter {
  final Color color;
  const _StitchDividerPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color.withAlpha(180)
      ..strokeWidth = 1.4
      ..strokeCap = StrokeCap.round;
    const dash = 5.0;
    const gap = 4.0;
    double x = 0;
    while (x < size.width) {
      final endX = math.min(x + dash, size.width);
      canvas.drawLine(Offset(x, size.height / 2), Offset(endX, size.height / 2), paint);
      x += dash + gap;
    }
  }

  @override
  bool shouldRepaint(covariant _StitchDividerPainter old) => old.color != color;
}
