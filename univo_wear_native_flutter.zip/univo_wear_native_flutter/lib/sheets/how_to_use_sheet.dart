import 'package:flutter/material.dart';
import '../core/app_theme.dart';
import '../services/pos_store.dart';

void showHowToUseSheet(BuildContext context, PosStore s) {
  final accent = s.isDark ? AppTheme.gold : AppTheme.goldLightMode;
  final muted = s.isDark ? const Color(0xFF94A3B8) : const Color(0xFF64748B);
  final surface = s.isDark ? AppTheme.darkSurface : AppTheme.lightSurface;
  final border = s.isDark ? AppTheme.darkBorder : AppTheme.lightBorder;

  final roleLabel = s.role == UserRole.owner
      ? 'Owner Guide'
      : (s.role == UserRole.admin ? 'Admin Guide' : 'Staff Guide');

  final staffSteps = <Map<String, String>>[
    {
      'title': '1. Easy Billing (Stock → Cart)',
      'desc': 'Open Stock tab, search a dress name (e.g. Polo Fit), tap the colour chip (Brown / White), then tap the size chip (M, L, 32) to add to the Cart bar. Tap the Cart bar to finish billing.',
    },
    {
      'title': '2. Less / Bargain, Cash Change & Hold Bill',
      'desc': 'Inside Checkout, type Less (₹) or Final Price (₹) within your allowed bargain limit. For Cash bills, tap ₹500/₹1000/₹2000 to see exact Return Change. Tap "Hold" if a customer goes to the trial room, then "Resume" anytime.',
    },
    {
      'title': '3. PNG Bill Receipt & Thermal Print',
      'desc': 'After saving a bill (or from Today\'s Bills), tap any bill to Share/Save a Branded PNG receipt or tap Print Bill for Bluetooth Thermal / Wi-Fi printing.',
    },
    {
      'title': '4. Daily Closing, Khata & Stock Tally',
      'desc': 'Use Day-Book at closing time to share the Daily Sales & Stock PNG. Use Stock Tally to verify rack counts against the system and report missing pieces.',
    },
  ];

  final adminSteps = <Map<String, String>>[
    {
      'title': '5. Multi-Colour Stock & Photo Catalog',
      'desc': 'Tap + Add Stock, pick or type any colour, enter size counts, and tap "+ Add Another Colour" to add multiple colours under the same design name. All colours group cleanly into one card.',
    },
    {
      'title': '6. 7-Day Edit / Restore & Old Bills PDF',
      'desc': 'In Bills tab, switch "Today ⇄ Last 7 Days" to edit payment/discount or restore & delete a bill with a mandatory reason. Open Old Bills Archive to export Date/Month PDFs.',
    },
    {
      'title': '7. Smart ERP, GST Reports & Festival Promos',
      'desc': 'Open Smart ERP for Peak Hours, Dead-Stock Aging (30/60/90d), and Supplier PO PDFs. Open GST & Promo for GSTR-1 CA PDF/CSV exports and auto-applied Festival Offers.',
    },
  ];

  final ownerSteps = <Map<String, String>>[
    {
      'title': '8. Owner-Only Controls & Security',
      'desc': 'Only the Owner can grant Admin access by User UID, push app updates to all phones, set Max Staff Bargain / Commission rules, and control monthly auto-cleanup.',
    },
  ];

  final sections = <Map<String, String>>[
    ...staffSteps,
    if (s.isAdmin) ...adminSteps,
    if (s.role == UserRole.owner) ...ownerSteps,
  ];

  showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    backgroundColor: s.isDark ? AppTheme.darkCard : AppTheme.lightCard,
    shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(26))),
    builder: (ctx) => DraggableScrollableSheet(
      expand: false,
      initialChildSize: 0.85,
      maxChildSize: 0.94,
      builder: (_, sc) => ListView(
        controller: sc,
        padding: const EdgeInsets.fromLTRB(18, 16, 18, 28),
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  Icon(Icons.menu_book_rounded, color: accent, size: 22),
                  const SizedBox(width: 8),
                  Text('How to Use • $roleLabel', style: const TextStyle(fontSize: 16.5, fontWeight: FontWeight.w900)),
                ],
              ),
              IconButton(icon: const Icon(Icons.close_rounded), onPressed: () => Navigator.pop(ctx)),
            ],
          ),
          const SizedBox(height: 10),
          ...sections.map((sec) => Container(
                margin: const EdgeInsets.only(bottom: 10),
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: surface,
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: border),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(sec['title']!, style: TextStyle(fontWeight: FontWeight.w800, fontSize: 13.5, color: accent)),
                    const SizedBox(height: 5),
                    Text(sec['desc']!, style: TextStyle(fontSize: 12, height: 1.45, color: muted)),
                  ],
                ),
              )),
        ],
      ),
    ),
  );
}
