import 'package:flutter/material.dart';
import '../core/app_theme.dart';
import '../services/pos_store.dart';

void showHowToUseSheet(BuildContext context, PosStore s) {
  final accent = s.isDark ? AppTheme.gold : AppTheme.goldLightMode;
  final muted = s.isDark ? const Color(0xFF94A3B8) : const Color(0xFF64748B);
  final surface = s.isDark ? AppTheme.darkSurface : AppTheme.lightSurface;
  final border = s.isDark ? AppTheme.darkBorder : AppTheme.lightBorder;

  final roleLabel = s.role == UserRole.owner
      ? s.t('Owner Guide', 'ஓனர் வழிகாட்டி')
      : (s.role == UserRole.admin ? s.t('Admin Guide', 'அட்மின் வழிகாட்டி') : s.t('Staff Guide', 'ஸ்டாஃப் வழிகாட்டி'));

  final staffSteps = <Map<String, String>>[
    {
      'title': s.t('1. Easy Billing (Stock → Cart)', '1. ஈஸியா பில் போடுவது (ஸ்டாக் → கார்ட்)'),
      'desc': s.t(
        'Open Stock tab, search a dress name (e.g. Polo Fit), tap the colour chip (Brown / White), then tap the size chip (M, L, 32) to add to the Cart bar. Tap the Cart bar to complete the bill.',
        'ஸ்டாக் பேஜ் போய் டிரஸ் பெயரை தேடுங்க (உதா: Polo Fit), கலர் சிப் (Brown / White) தொட்டு, சைஸ் (M, L, 32) தொட்டா கீழ Cart-ல ஆட் ஆகும். Cart பார் தொட்டு பில் முடிங்க.',
      ),
    },
    {
      'title': s.t('2. Less / Bargain, Cash Change & Hold Bill', '2. டிஸ்கவுண்ட், சில்லறை கணக்கு & Hold பில்'),
      'desc': s.t(
        'Inside Checkout, enter Less (₹) or Final Price (₹) within your allowed limit. For Cash bills, tap ₹500/₹1000/₹2000 to see exact Return Change. Tap "Hold" if a customer goes to the trial room.',
        'Checkout உள்ள Less (₹) இல்ல Final Price (₹) போடலாம். Cash பில்ல ₹500/₹1000/₹2000 தொட்டா திரும்பக் கொடுக்க வேண்டிய சில்லறை காட்டும். கஸ்டமர் ட்ரையல் போனா "Hold" தட்டி வெச்சிக்கலாம்.',
      ),
    },
    {
      'title': s.t('3. PNG Bill Receipt & Thermal Print', '3. PNG பில் & பிரிண்டர் பிரிண்ட்'),
      'desc': s.t(
        'After saving a bill (or from Today\'s Bills), tap any bill to Share/Save a Branded PNG receipt or tap Print Bill for Bluetooth Thermal / Wi-Fi printing.',
        'பில் போட்டவுடனே (இல்ல இன்றைய பில்கள்ல) பில்லை தொட்டு PNG இமேஜா ஷேர்/சேவ் பண்ணலாம், இல்ல Print Bill தட்டி Bluetooth / Wi-Fi பிரிண்டர்ல பிரிண்ட் எடுக்கலாம்.',
      ),
    },
    {
      'title': s.t('4. Daily Closing, Calculator & Stock Tally', '4. தினசரி கணக்கு, கால்குலேட்டர் & ஸ்டாக் டேலி'),
      'desc': s.t(
        'Use Day-Book at closing time for the Daily Sales & Stock Closing PNG. Use Calculator for quick math and Stock Tally to count racks.',
        'கடை மூடும்போது Day-Book-ல தினசரி Closing PNG ஷேர் பண்ணுங்க. சாதாரண/ஸ்டாக் கணக்குக்கு Calculator, ரேக் எண்ணிக்கைக்கு Stock Tally யூஸ் பண்ணுங்க.',
      ),
    },
  ];

  final adminSteps = <Map<String, String>>[
    {
      'title': s.t('5. Multi-Colour Stock & Out of Stock', '5. மல்டி-கலர் ஸ்டாக் & தீர்ந்து போன ஸ்டாக்'),
      'desc': s.t(
        'Tap + Add Stock, tap "Choose Colour" (68 real dress colours), enter size counts, and tap "+ Add Another Colour". When any stock reaches 0 pcs, it automatically moves to Out of Stock (தீர்ந்து போன ஸ்டாக்).',
        '+ Add Stock தொட்டு Choose Colour (68 கலர்கள்) செலக்ட் பண்ணி "+ Add Another Colour" வழியா பல கலர் சேர்க்கலாம். ஸ்டாக் 0 ஆனதும் தானா "தீர்ந்து போன ஸ்டாக்" பேஜுக்கு போயிடும்.',
      ),
    },
    {
      'title': s.t('6. 7-Day Edit / Restore & Old Bills PDF', '6. 7-நாள் பில் எடிட் / ரீஸ்டோர் & Old Bills PDF'),
      'desc': s.t(
        'In Bills tab, switch "Today ⇄ Last 7 Days" to edit or restore & delete a bill with a reason. Open Old Bills Archive to export Date/Month PDFs.',
        'பில்கள் பேஜ்ல "Today ⇄ Last 7 Days" மாத்தி கடந்த 7 நாள் பில்களை எடிட் அல்லது ரீஸ்டோர் பண்ணலாம். Old Bills Archive-ல தேதி/மாத PDF சேவ் பண்ணலாம்.',
      ),
    },
    {
      'title': s.t('7. Smart ERP, GST Reports & Promos', '7. Smart ERP, GST ரிப்போர்ட் & ஆஃபர்கள்'),
      'desc': s.t(
        'Open Smart ERP for Peak Hours, Dead-Stock Aging, and Supplier PO PDFs. Open GST & Promo for GSTR-1 CA PDF/CSV exports and Festival Offers.',
        'Smart ERP-ல Peak Hours, Dead-Stock, Supplier PO PDF பாக்கலாம். GST & Promo-ல GSTR-1 CA ரிப்போர்ட் மற்றும் தீபாவளி/பொங்கல் ஆஃபர் செட் பண்ணலாம்.',
      ),
    },
  ];

  final ownerSteps = <Map<String, String>>[
    {
      'title': s.t('8. Owner-Only Controls & Security', '8. ஓனர் மட்டும் கட்டுப்பாடுகள்'),
      'desc': s.t(
        'Only the Owner can grant Admin access by User UID, push app updates to all phones, set Staff Bargain/Commission rules, and manage auto-cleanup.',
        'ஓனர் மட்டும் தான் புது Admin சேர்க்க, எல்லா போனுக்கும் அப்டேட் அனுப்ப, Staff டிஸ்கவுண்ட்/கமிஷன் ரூல்ஸ் செட் பண்ண முடியும்.',
      ),
    },
  ];

  final sections = <Map<String, String>>[
    ...staffSteps,
    if (s.isAdmin) ...adminSteps,
    if (s.role == UserRole.owner) ...ownerSteps,
  ];

  showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    backgroundColor: s.isDark ? AppTheme.darkCard : AppTheme.lightCard,
    shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(26))),
    builder: (ctx) => DraggableScrollableSheet(
      expand: false,
      initialChildSize: 0.85,
      maxChildSize: 0.94,
      builder: (_, sc) => ListView(
        controller: sc,
        padding: const EdgeInsets.fromLTRB(18, 16, 18, 28),
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  Icon(Icons.menu_book_rounded, color: accent, size: 22),
                  const SizedBox(width: 8),
                  Text('${s.t("How to Use", "பயன்படுத்தும் முறை")} • $roleLabel', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w900)),
                ],
              ),
              IconButton(icon: const Icon(Icons.close_rounded), onPressed: () => Navigator.pop(ctx)),
            ],
          ),
          const SizedBox(height: 10),
          ...sections.map((sec) => Container(
                margin: const EdgeInsets.only(bottom: 10),
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: surface,
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: border),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(sec['title']!, style: TextStyle(fontWeight: FontWeight.w800, fontSize: 13.5, color: accent)),
                    const SizedBox(height: 5),
                    Text(sec['desc']!, style: TextStyle(fontSize: 12, height: 1.45, color: muted)),
                  ],
                ),
              )),
        ],
      ),
    ),
  );
}
