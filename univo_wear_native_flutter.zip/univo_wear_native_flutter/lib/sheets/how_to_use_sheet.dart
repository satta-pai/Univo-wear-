import 'package:flutter/material.dart';
import '../core/app_theme.dart';
import '../services/pos_store.dart';

void showHowToUseSheet(BuildContext context, PosStore s) {
  final accent = s.isDark ? AppTheme.gold : AppTheme.goldLightMode;
  final muted = s.isDark ? const Color(0xFF94A3B8) : const Color(0xFF64748B);
  final surface = s.isDark ? AppTheme.darkSurface : AppTheme.lightSurface;
  final border = s.isDark ? AppTheme.darkBorder : AppTheme.lightBorder;

  final sections = <Map<String, String>>[
    {
      'title': '1. Quick Billing & Cart',
      'desc': 'Go to Stock tab, search any garment or colour, and tap a size chip (M, L, 32) to add it to the live Cart bar. Tap the Cart bar to apply Less/Discount, calculate Cash return change, or Hold a trial-room bill for later.',
    },
    {
      'title': '2. Multi-Colour Stock Entry (Owner / Admin)',
      'desc': 'Tap + Add Stock, pick or type any colour, enter size quantities, and tap "+ Add Another Colour" to add multiple colours of the same design in one go. Attach a dress photo from Camera or Gallery for Catalog Grid view.',
    },
    {
      'title': '3. PNG Bills & Thermal Printing',
      'desc': 'After every sale (or from Today\'s Bills), tap any bill to Share/Save a 3x Branded PNG receipt, or tap Print Bill for direct 58mm/80mm Bluetooth Thermal printing or Wi-Fi/A4 printing.',
    },
    {
      'title': '4. 7-Day Edit, Restore & Old Bills PDF',
      'desc': 'Bills tab resets fresh every day at midnight. Switch "Today ⇄ Last 7 Days" to edit payment/discount or restore & delete a bill with a mandatory reason. Owner & Admin can export full Date/Month Old Bills PDFs.',
    },
    {
      'title': '5. Daily Closing, Khata & Smart ERP',
      'desc': 'Use Day-Book at closing time to generate a branded Daily Sales & Stock Closing PNG. Use Smart ERP for Dead-Stock Aging, Peak Hours, and Supplier PO PDFs, and GST & Promo for GSTR-1 CA exports and Festival Offers.',
    },
    {
      'title': '6. Works Offline & Auto-Updates',
      'desc': 'If internet drops, the bottom bar shows "You are offline" — you can keep working and everything syncs automatically once "Back online" appears. Check for Updates in Profile updates both Android & Windows in-place.',
    },
  ];

  showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    backgroundColor: s.isDark ? AppTheme.darkCard : AppTheme.lightCard,
    shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(26))),
    builder: (ctx) => DraggableScrollableSheet(
      expand: false,
      initialChildSize: 0.85,
      maxChildSize: 0.94,
      builder: (_, sc) => ListView(
        controller: sc,
        padding: const EdgeInsets.fromLTRB(18, 16, 18, 28),
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  Icon(Icons.menu_book_rounded, color: accent, size: 22),
                  const SizedBox(width: 8),
                  const Text('How to Use UNIVO WEAR', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w900)),
                ],
              ),
              IconButton(icon: const Icon(Icons.close_rounded), onPressed: () => Navigator.pop(ctx)),
            ],
          ),
          const SizedBox(height: 10),
          ...sections.map((sec) => Container(
                margin: const EdgeInsets.only(bottom: 10),
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: surface,
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: border),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(sec['title']!, style: TextStyle(fontWeight: FontWeight.w800, fontSize: 13.5, color: accent)),
                    const SizedBox(height: 5),
                    Text(sec['desc']!, style: TextStyle(fontSize: 12, height: 1.45, color: muted)),
                  ],
                ),
              )),
        ],
      ),
    ),
  );
}
