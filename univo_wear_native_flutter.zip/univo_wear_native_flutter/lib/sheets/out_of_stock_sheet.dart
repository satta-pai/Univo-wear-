import 'dart:convert';
import 'package:flutter/material.dart';
import '../core/app_theme.dart';
import '../core/constants.dart';
import '../models/pos_models.dart';
import '../services/pos_store.dart';
import 'add_stock_sheet.dart';

void showOutOfStockSheet(BuildContext context, PosStore s) {
  final accent = s.isDark ? AppTheme.gold : AppTheme.goldLightMode;
  final muted = s.isDark ? const Color(0xFF94A3B8) : const Color(0xFF64748B);

  showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    backgroundColor: s.isDark ? AppTheme.darkCard : AppTheme.lightCard,
    shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(26))),
    builder: (ctx) => AnimatedBuilder(
      animation: s,
      builder: (_, __) {
        final soldOut = s.stock.where((x) => x.qty <= 0).toList();
        return DraggableScrollableSheet(
          expand: false,
          initialChildSize: 0.82,
          maxChildSize: 0.94,
          builder: (_, sc) => Padding(
            padding: const EdgeInsets.fromLTRB(18, 16, 18, 22),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      children: [
                        const Icon(Icons.inventory_2_outlined, color: AppTheme.rose, size: 22),
                        const SizedBox(width: 8),
                        Text(
                          s.t('Out of Stock (${soldOut.length})', 'தீர்ந்து போன ஸ்டாக் (${soldOut.length})'),
                          style: const TextStyle(fontSize: 16.5, fontWeight: FontWeight.w900, color: AppTheme.rose),
                        ),
                      ],
                    ),
                    IconButton(icon: const Icon(Icons.close_rounded), onPressed: () => Navigator.pop(ctx)),
                  ],
                ),
                const SizedBox(height: 10),
                Expanded(
                  child: soldOut.isEmpty
                      ? Center(
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              const Icon(Icons.check_circle_outline_rounded, size: 48, color: AppTheme.green),
                              const SizedBox(height: 8),
                              Text(
                                s.t('No sold-out stock right now!', 'தீர்ந்து போன ஸ்டாக் எதுவும் இல்லை!'),
                                style: TextStyle(color: muted, fontWeight: FontWeight.w700),
                              ),
                            ],
                          ),
                        )
                      : ListView.builder(
                          controller: sc,
                          itemCount: soldOut.length,
                          itemBuilder: (_, i) {
                            final item = soldOut[i];
                            return Card(
                              margin: const EdgeInsets.only(bottom: 10),
                              child: ListTile(
                                contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                                leading: Container(
                                  width: 46,
                                  height: 46,
                                  decoration: BoxDecoration(
                                    color: hexToColor(item.colour),
                                    borderRadius: BorderRadius.circular(12),
                                  ),
                                  child: item.photoBase64.isNotEmpty
                                      ? ClipRRect(
                                          borderRadius: BorderRadius.circular(12),
                                          child: Image.memory(base64Decode(item.photoBase64), fit: BoxFit.cover),
                                        )
                                      : const Icon(Icons.checkroom_rounded, color: Colors.white, size: 22),
                                ),
                                title: Text(item.name, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 13.5)),
                                subtitle: Text(
                                  '${item.category}${item.colourName.isNotEmpty ? ' • ${item.colourName}' : ''} • ${formatInr(item.sellPrice)} • 0 pcs',
                                  style: TextStyle(fontSize: 11, color: muted),
                                ),
                                trailing: s.isAdmin
                                    ? Row(
                                        mainAxisSize: MainAxisSize.min,
                                        children: [
                                          ElevatedButton(
                                            style: ElevatedButton.styleFrom(
                                              backgroundColor: accent,
                                              foregroundColor: Colors.black,
                                              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                                              minimumSize: Size.zero,
                                            ),
                                            onPressed: () {
                                              showModalBottomSheet(
                                                context: ctx,
                                                isScrollControlled: true,
                                                builder: (_) => AddStockSheet(store: s, existing: item),
                                              );
                                            },
                                            child: Text(s.t('Restock', 'மீண்டும் சேர்'), style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w800)),
                                          ),
                                          IconButton(
                                            icon: const Icon(Icons.delete_outline_rounded, size: 19, color: AppTheme.rose),
                                            onPressed: () async {
                                              final ok = await showDialog<bool>(
                                                context: ctx,
                                                builder: (dCtx) => AlertDialog(
                                                  title: Text(s.t('Delete Permanently?', 'நிரந்தரமா டெலீட் பண்ணவா?')),
                                                  content: Text('${item.name}'),
                                                  actions: [
                                                    TextButton(onPressed: () => Navigator.pop(dCtx, false), child: Text(s.t('Cancel', 'வேண்டாம்'))),
                                                    ElevatedButton(onPressed: () => Navigator.pop(dCtx, true), child: Text(s.t('Delete', 'டெலீட்'))),
                                                  ],
                                                ),
                                              );
                                              if (ok == true) await s.deleteStock(item.id);
                                            },
                                          ),
                                        ],
                                      )
                                    : Container(
                                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                                        decoration: BoxDecoration(color: AppTheme.rose.withAlpha(28), borderRadius: BorderRadius.circular(8)),
                                        child: Text(s.t('SOLD OUT', 'தீர்ந்துவிட்டது'), style: const TextStyle(fontSize: 10, fontWeight: FontWeight.w800, color: AppTheme.rose)),
                                      ),
                              ),
                            );
                          },
                        ),
                ),
              ],
            ),
          ),
        );
      },
    ),
  );
}
