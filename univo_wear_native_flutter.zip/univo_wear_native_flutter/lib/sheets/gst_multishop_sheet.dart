import 'dart:io';
import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';
import 'package:path_provider/path_provider.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:share_plus/share_plus.dart';
import '../core/app_theme.dart';
import '../core/constants.dart';
import '../services/pos_store.dart';

String _gstRs(double v) => 'Rs. ${NumberFormat('#,##0', 'en_IN').format(v.round())}';

void showGstAndEnterpriseSheet(BuildContext context, PosStore s) {
  final shopNameCtrl = TextEditingController(text: s.shopName);
  final gstinCtrl = TextEditingController(text: s.shopGstin);
  final waCtrl = TextEditingController(text: s.shopWhatsapp);
  final promoTitleCtrl = TextEditingController(text: s.promoTitle);
  final promoMinCtrl = TextEditingController(text: s.promoMinBill.toStringAsFixed(0));
  final promoPctCtrl = TextEditingController(text: s.promoDiscountPct.toStringAsFixed(0));
  bool promoOn = s.promoEnabled;

  final now = DateTime.now();
  final monthPrefix = DateFormat('yyyy-MM').format(now);
  final monthLabel = DateFormat('MMMM yyyy').format(now);
  final monthBills = s.sales.where((x) => x.date.startsWith(monthPrefix) || x.createdAt.startsWith(monthPrefix)).toList();

  double tax5Base = 0, tax5Gst = 0, tax12Base = 0, tax12Gst = 0, nonGstBase = 0;
  for (final b in monthBills) {
    if (b.gstRate == 5 && b.gstTotal > 0) {
      tax5Base += b.taxableValue;
      tax5Gst += b.gstTotal;
    } else if (b.gstRate >= 12 && b.gstTotal > 0) {
      tax12Base += b.taxableValue;
      tax12Gst += b.gstTotal;
    } else {
      nonGstBase += b.totalSellPrice;
    }
  }

  // Multi-Branch Stock Valuation
  final branchPcs = <String, int>{};
  final branchVal = <String, double>{};
  for (final item in s.stock) {
    final loc = item.location.isEmpty ? 'Main Shop' : item.location;
    branchPcs[loc] = (branchPcs[loc] ?? 0) + item.qty;
    branchVal[loc] = (branchVal[loc] ?? 0) + (item.sellPrice * item.qty);
  }

  final accent = s.isDark ? AppTheme.gold : AppTheme.goldLightMode;
  final muted = s.isDark ? const Color(0xFF94A3B8) : const Color(0xFF64748B);

  Future<void> exportGstr1(BuildContext ctx, bool asCsv) async {
    if (kIsWeb) {
      ScaffoldMessenger.of(ctx).showSnackBar(const SnackBar(content: Text('Export available on Android/Desktop app.')));
      return;
    }
    try {
      final dir = await getTemporaryDirectory();
      if (asCsv) {
        final buf = StringBuffer('InvoiceNo,Date,Customer,HSN,TaxableValue,GSTRate,CGST,SGST,TotalGST,FinalAmount,Payment\n');
        for (final b in monthBills) {
          final halfGst = (b.gstTotal / 2).toStringAsFixed(2);
          buf.writeln('${b.id},${b.date},"${b.customerName}",6203,${b.taxableValue.toStringAsFixed(2)},${b.gstRate}%,$halfGst,$halfGst,${b.gstTotal.toStringAsFixed(2)},${b.totalSellPrice.toStringAsFixed(2)},${b.payment}');
        }
        final f = File('${dir.path}/GSTR1_${monthPrefix}.csv');
        await f.writeAsString(buf.toString());
        await SharePlus.instance.share(ShareParams(files: [XFile(f.path)], text: '${s.shopName} GSTR-1 CSV ($monthLabel)'));
      } else {
        final doc = pw.Document();
        doc.addPage(
          pw.Page(
            pageFormat: PdfPageFormat.a4,
            margin: const pw.EdgeInsets.all(24),
            build: (_) => pw.Column(
              crossAxisAlignment: pw.CrossAxisAlignment.start,
              children: [
                pw.Text('${s.shopName.toUpperCase()} - GSTR-1 HSN SUMMARY', style: pw.TextStyle(fontSize: 16, fontWeight: pw.FontWeight.bold)),
                pw.Text('Period: $monthLabel  |  GSTIN: ${s.shopGstin.isEmpty ? "UNREGISTERED" : s.shopGstin}', style: const pw.TextStyle(fontSize: 9.5)),
                pw.SizedBox(height: 12),
                pw.TableHelper.fromTextArray(
                  headerStyle: pw.TextStyle(fontSize: 9, fontWeight: pw.FontWeight.bold, color: PdfColors.white),
                  headerDecoration: const pw.BoxDecoration(color: PdfColors.grey900),
                  cellStyle: const pw.TextStyle(fontSize: 9),
                  headers: const ['GST Slab', 'HSN', 'Taxable Value', 'CGST', 'SGST', 'Total Tax'],
                  data: [
                    ['5% Apparel (<= Rs.1000)', '6203/6204', _gstRs(tax5Base), _gstRs(tax5Gst / 2), _gstRs(tax5Gst / 2), _gstRs(tax5Gst)],
                    ['12% Apparel (> Rs.1000)', '6203/6204', _gstRs(tax12Base), _gstRs(tax12Gst / 2), _gstRs(tax12Gst / 2), _gstRs(tax12Gst)],
                    ['Non-GST / Composition', '-', _gstRs(nonGstBase), 'Rs. 0', 'Rs. 0', 'Rs. 0'],
                  ],
                ),
                pw.SizedBox(height: 14),
                pw.Text('Total Monthly GST Payable: ${_gstRs(tax5Gst + tax12Gst)}', style: pw.TextStyle(fontSize: 12, fontWeight: pw.FontWeight.bold)),
              ],
            ),
          ),
        );
        final f = File('${dir.path}/GSTR1_${monthPrefix}.pdf');
        await f.writeAsBytes(await doc.save(), flush: true);
        await SharePlus.instance.share(ShareParams(files: [XFile(f.path)], text: '${s.shopName} GSTR-1 PDF ($monthLabel)'));
      }
    } catch (e) {
      if (ctx.mounted) ScaffoldMessenger.of(ctx).showSnackBar(SnackBar(content: Text('GST Export error: $e')));
    }
  }

  showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    backgroundColor: s.isDark ? AppTheme.darkCard : AppTheme.lightCard,
    shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(26))),
    builder: (ctx) => StatefulBuilder(
      builder: (ctx, setSt) => DraggableScrollableSheet(
        expand: false,
        initialChildSize: 0.9,
        maxChildSize: 0.95,
        builder: (_, sc) => ListView(
          controller: sc,
          padding: EdgeInsets.fromLTRB(18, 16, 18, MediaQuery.of(ctx).viewInsets.bottom + 28),
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text('Store Hub: GST, Promos & Branches', style: TextStyle(fontSize: 16.5, fontWeight: FontWeight.w900)),
                IconButton(icon: const Icon(Icons.close_rounded), onPressed: () => Navigator.pop(ctx)),
              ],
            ),
            const SizedBox(height: 8),

            // 1. Live Phygital Online Storefront Link
            Card(
              child: Padding(
                padding: const EdgeInsets.all(14),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Live Online Customer Catalog', style: TextStyle(fontWeight: FontWeight.w800, color: accent)),
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        Expanded(
                          child: ElevatedButton.icon(
                            style: ElevatedButton.styleFrom(backgroundColor: accent, foregroundColor: Colors.black),
                            icon: const Icon(Icons.storefront_rounded, size: 16),
                            label: const Text('Copy Storefront Link', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 12)),
                            onPressed: () {
                              const url = 'https://satta-pai.github.io/Univo-wear-/?shop=catalog';
                              Clipboard.setData(const ClipboardData(text: url));
                              ScaffoldMessenger.of(ctx).showSnackBar(const SnackBar(content: Text('Copied Live Catalog Link! Share on WhatsApp Status!')));
                            },
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 10),

            // 2. Festival Promo Engine
            Card(
              child: Padding(
                padding: const EdgeInsets.all(14),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text('Festival Promo Engine', style: TextStyle(fontWeight: FontWeight.w800, color: accent)),
                        Switch(value: promoOn, onChanged: (v) => setSt(() => promoOn = v)),
                      ],
                    ),
                    TextField(controller: promoTitleCtrl, decoration: const InputDecoration(labelText: 'Offer Name (e.g. DIWALI SPECIAL)')),
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        Expanded(child: TextField(controller: promoMinCtrl, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Min Bill (₹)'))),
                        const SizedBox(width: 8),
                        Expanded(child: TextField(controller: promoPctCtrl, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Auto Off (%)'))),
                      ],
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 10),

            // 3. Store Identity & Multi-Branch Valuation
            Card(
              child: Padding(
                padding: const EdgeInsets.all(14),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Store Profile & GSTIN', style: TextStyle(fontWeight: FontWeight.w800, color: accent)),
                    const SizedBox(height: 8),
                    TextField(controller: shopNameCtrl, decoration: const InputDecoration(labelText: 'Shop Name')),
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        Expanded(child: TextField(controller: gstinCtrl, decoration: const InputDecoration(labelText: 'GSTIN (Optional)'))),
                        const SizedBox(width: 8),
                        Expanded(child: TextField(controller: waCtrl, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: 'Shop WhatsApp'))),
                      ],
                    ),
                    const SizedBox(height: 12),
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(backgroundColor: AppTheme.green, foregroundColor: Colors.black),
                        onPressed: () async {
                          await s.saveEnterpriseSettings(
                            shopName: shopNameCtrl.text.trim().isEmpty ? 'UNIVO WEAR' : shopNameCtrl.text.trim(),
                            shopGstin: gstinCtrl.text.trim(),
                            shopWhatsapp: waCtrl.text.trim(),
                            promoEnabled: promoOn,
                            promoTitle: promoTitleCtrl.text.trim().isEmpty ? 'FESTIVAL OFFER' : promoTitleCtrl.text.trim(),
                            promoMinBill: double.tryParse(promoMinCtrl.text) ?? 2000,
                            promoDiscountPct: double.tryParse(promoPctCtrl.text) ?? 10,
                          );
                          if (ctx.mounted) {
                            ScaffoldMessenger.of(ctx).showSnackBar(const SnackBar(content: Text('Store Profile & Festival Promo synced!')));
                          }
                        },
                        child: const Text('Save & Sync Settings', style: TextStyle(fontWeight: FontWeight.w900)),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 10),

            // 4. Multi-Branch Stock Breakdown
            Card(
              child: Padding(
                padding: const EdgeInsets.all(14),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Multi-Branch Stock Overview', style: TextStyle(fontWeight: FontWeight.w800, color: accent)),
                    const SizedBox(height: 8),
                    ...branchPcs.entries.map((e) => Padding(
                          padding: const EdgeInsets.symmetric(vertical: 3),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text('${e.key} (${e.value} pcs)', style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 12.5)),
                              Text(formatInr(branchVal[e.key] ?? 0), style: const TextStyle(fontWeight: FontWeight.w900, color: AppTheme.green)),
                            ],
                          ),
                        )),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 10),

            // 5. CA GSTR-1 / HSN Slab Export
            Card(
              child: Padding(
                padding: const EdgeInsets.all(14),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('CA GSTR-1 / HSN Summary ($monthLabel)', style: TextStyle(fontWeight: FontWeight.w800, color: accent)),
                    const SizedBox(height: 8),
                    Text('5% Slab Tax: ${formatInr(tax5Gst)}  •  12% Slab Tax: ${formatInr(tax12Gst)}', style: TextStyle(fontSize: 12, color: muted, fontWeight: FontWeight.w700)),
                    const SizedBox(height: 10),
                    Row(
                      children: [
                        Expanded(
                          child: ElevatedButton.icon(
                            style: ElevatedButton.styleFrom(backgroundColor: accent, foregroundColor: Colors.black),
                            onPressed: () => exportGstr1(ctx, false),
                            icon: const Icon(Icons.picture_as_pdf_rounded, size: 16),
                            label: const Text('GSTR-1 PDF', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 12)),
                          ),
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: OutlinedButton.icon(
                            onPressed: () => exportGstr1(ctx, true),
                            icon: const Icon(Icons.table_chart_rounded, size: 16),
                            label: const Text('CA Excel CSV', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 12)),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    ),
  );
}
