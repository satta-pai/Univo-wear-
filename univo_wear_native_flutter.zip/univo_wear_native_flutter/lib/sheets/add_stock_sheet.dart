import 'package:flutter/material.dart';
import '../core/app_theme.dart';
import '../core/constants.dart';
import '../models/pos_models.dart';
import '../services/pos_store.dart';

class AddStockSheet extends StatefulWidget {
  final PosStore store;
  final StockItem? existing;
  const AddStockSheet({super.key, required this.store, this.existing});

  @override
  State<AddStockSheet> createState() => _AddStockSheetState();
}

class _AddStockSheetState extends State<AddStockSheet> {
  final _nameCtrl = TextEditingController();
  final _costCtrl = TextEditingController();
  final _sellCtrl = TextEditingController();
  final _colourCtrl = TextEditingController();
  String _category = 'Pants';
  String _location = 'Main Shop';
  String _hex = '#eab308';
  final Map<String, TextEditingController> _sizeCtrls = {};

  @override
  void initState() {
    super.initState();
    final ex = widget.existing;
    if (ex != null) {
      _nameCtrl.text = ex.name;
      _costCtrl.text = ex.costPrice.toStringAsFixed(0);
      _sellCtrl.text = ex.sellPrice.toStringAsFixed(0);
      _colourCtrl.text = ex.colourName;
      _category = kCategories.contains(ex.category) ? ex.category : 'Shirts';
      _location = kLocations.contains(ex.location) ? ex.location : 'Main Shop';
      _hex = ex.colour;
    }
    _resetSizes(ex?.sizes);
  }

  void _resetSizes([Map<String, int>? existingSizes]) {
    _sizeCtrls.clear();
    for (final sz in sizesForCategory(_category)) {
      _sizeCtrls[sz] = TextEditingController(text: '${existingSizes?[sz] ?? 0}');
    }
  }

  @override
  Widget build(BuildContext context) {
    final sizes = sizesForCategory(_category);
    return Padding(
      padding: EdgeInsets.only(
        left: 16,
        right: 16,
        top: 16,
        bottom: MediaQuery.of(context).viewInsets.bottom + 16,
      ),
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              widget.existing == null ? '+ Add New Stock' : 'Edit Stock & Sizes',
              style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 12),
            TextField(controller: _nameCtrl, decoration: const InputDecoration(labelText: 'Dress / Pants Name *')),
            const SizedBox(height: 10),
            Row(
              children: [
                Expanded(
                  child: DropdownButtonFormField<String>(
                    initialValue: _category,
                    decoration: const InputDecoration(labelText: 'Category'),
                    items: kCategories.map((c) => DropdownMenuItem(value: c, child: Text(c))).toList(),
                    onChanged: (v) {
                      if (v != null) {
                        setState(() {
                          _category = v;
                          _resetSizes();
                        });
                      }
                    },
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: DropdownButtonFormField<String>(
                    initialValue: _location,
                    decoration: const InputDecoration(labelText: 'Location'),
                    items: kLocations.map((l) => DropdownMenuItem(value: l, child: Text(l))).toList(),
                    onChanged: (v) {
                      if (v != null) setState(() => _location = v);
                    },
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),
            TextField(controller: _colourCtrl, decoration: const InputDecoration(labelText: 'Colour Name (e.g. Olive, Black)')),
            const SizedBox(height: 8),
            Wrap(
              spacing: 6,
              runSpacing: 6,
              children: kColourSwatches.map((s) {
                final sel = _hex.toLowerCase() == s.hex.toLowerCase();
                return GestureDetector(
                  onTap: () => setState(() {
                    _hex = s.hex;
                    _colourCtrl.text = s.name;
                  }),
                  child: Container(
                    width: 26,
                    height: 26,
                    decoration: BoxDecoration(
                      color: s.color,
                      shape: BoxShape.circle,
                      border: Border.all(color: sel ? AppTheme.gold : Colors.grey, width: sel ? 2.5 : 1),
                    ),
                  ),
                );
              }).toList(),
            ),
            const SizedBox(height: 12),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: sizes
                  .map(
                    (sz) => SizedBox(
                      width: 68,
                      child: TextField(
                        controller: _sizeCtrls[sz],
                        keyboardType: TextInputType.number,
                        textAlign: TextAlign.center,
                        decoration: InputDecoration(labelText: sz),
                      ),
                    ),
                  )
                  .toList(),
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _costCtrl,
                    keyboardType: TextInputType.number,
                    decoration: const InputDecoration(labelText: 'Cost Price (₹) *'),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: TextField(
                    controller: _sellCtrl,
                    keyboardType: TextInputType.number,
                    decoration: const InputDecoration(labelText: 'Selling MRP (₹) *'),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppTheme.gold,
                  foregroundColor: Colors.black,
                  padding: const EdgeInsets.symmetric(vertical: 14),
                ),
                onPressed: () async {
                  final name = _nameCtrl.text.trim();
                  final cost = double.tryParse(_costCtrl.text) ?? 0;
                  final sell = double.tryParse(_sellCtrl.text) ?? 0;
                  if (name.isEmpty || sell < cost || sell <= 0) return;
                  final map = <String, int>{};
                  int total = 0;
                  _sizeCtrls.forEach((k, c) {
                    final v = int.tryParse(c.text) ?? 0;
                    map[k] = v < 0 ? 0 : v;
                    total += map[k]!;
                  });
                  if (total <= 0) return;
                  final item = StockItem(
                    id: widget.existing?.id ?? makeId('STK'),
                    name: name,
                    category: _category,
                    colour: _hex,
                    colourName: _colourCtrl.text.trim(),
                    location: _location,
                    hsnCode: '6203',
                    sizes: map,
                    qty: total,
                    costPrice: cost,
                    sellPrice: sell,
                    addedBy: widget.store.userName,
                    date: widget.existing?.date ?? getLocalDateString(),
                    createdAt: widget.existing?.createdAt ?? DateTime.now().toIso8601String(),
                  );
                  await widget.store.saveStock(item);
                  if (context.mounted) Navigator.pop(context);
                },
                child: Text(widget.existing == null ? 'Save Stock' : 'Update Stock', style: const TextStyle(fontWeight: FontWeight.bold)),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
