import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import '../core/app_theme.dart';
import '../core/constants.dart';
import '../models/pos_models.dart';
import '../services/pos_store.dart';

class _ColourVariantEntry {
  String hex;
  final TextEditingController colourNameCtrl;
  final Map<String, TextEditingController> sizeCtrls;

  _ColourVariantEntry({
    required this.hex,
    required String colourName,
    required List<String> sizes,
    Map<String, int>? existingSizes,
  })  : colourNameCtrl = TextEditingController(text: colourName),
        sizeCtrls = {
          for (final sz in sizes) sz: TextEditingController(text: '${existingSizes?[sz] ?? 0}'),
        };

  void rebuildSizes(List<String> sizes) {
    for (final c in sizeCtrls.values) {
      c.dispose();
    }
    sizeCtrls.clear();
    for (final sz in sizes) {
      sizeCtrls[sz] = TextEditingController(text: '0');
    }
  }

  void dispose() {
    colourNameCtrl.dispose();
    for (final c in sizeCtrls.values) {
      c.dispose();
    }
  }
}

class AddStockSheet extends StatefulWidget {
  final PosStore store;
  final StockItem? existing;
  const AddStockSheet({super.key, required this.store, this.existing});

  @override
  State<AddStockSheet> createState() => _AddStockSheetState();
}

class _AddStockSheetState extends State<AddStockSheet> {
  final _nameCtrl = TextEditingController();
  final _costCtrl = TextEditingController();
  final _sellCtrl = TextEditingController();
  String _category = 'Pants';
  String _location = 'Main Shop';
  String _photoBase64 = '';
  bool _saving = false;
  final List<_ColourVariantEntry> _variants = [];

  @override
  void initState() {
    super.initState();
    final ex = widget.existing;
    if (ex != null) {
      _nameCtrl.text = ex.name;
      _costCtrl.text = ex.costPrice.toStringAsFixed(0);
      _sellCtrl.text = ex.sellPrice.toStringAsFixed(0);
      _category = kCategories.contains(ex.category) ? ex.category : 'Shirts';
      _location = kLocations.contains(ex.location) ? ex.location : 'Main Shop';
      _photoBase64 = ex.photoBase64;
      _variants.add(_ColourVariantEntry(
        hex: ex.colour,
        colourName: ex.colourName,
        sizes: sizesForCategory(_category),
        existingSizes: ex.sizes,
      ));
    } else {
      _variants.add(_ColourVariantEntry(
        hex: '#1f2937',
        colourName: '',
        sizes: sizesForCategory(_category),
      ));
    }
  }

  @override
  void dispose() {
    _nameCtrl.dispose();
    _costCtrl.dispose();
    _sellCtrl.dispose();
    for (final v in _variants) {
      v.dispose();
    }
    super.dispose();
  }

  Future<void> _pickPhoto(ImageSource source) async {
    try {
      final picker = ImagePicker();
      final xfile = await picker.pickImage(source: source, maxWidth: 320, maxHeight: 320, imageQuality: 48);
      if (xfile == null) return;
      final bytes = await xfile.readAsBytes();
      if (mounted) setState(() => _photoBase64 = base64Encode(bytes));
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Photo error: $e')));
      }
    }
  }

  Future<void> _openColourPickerModal(_ColourVariantEntry vr) async {
    String q = '';
    await showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (mCtx) => StatefulBuilder(
        builder: (mCtx, setM) {
          final list = kColourSwatches.where((c) => q.isEmpty || c.name.toLowerCase().contains(q.toLowerCase())).toList();
          return DraggableScrollableSheet(
            expand: false,
            initialChildSize: 0.78,
            maxChildSize: 0.92,
            builder: (_, sc) => Padding(
              padding: const EdgeInsets.fromLTRB(16, 14, 16, 16),
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text('Choose Dress Colour (${list.length})', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
                      IconButton(icon: const Icon(Icons.close_rounded), onPressed: () => Navigator.pop(mCtx)),
                    ],
                  ),
                  TextField(
                    decoration: const InputDecoration(prefixIcon: Icon(Icons.search_rounded), hintText: 'Search colour (e.g. Wine, Olive, Navy)...'),
                    onChanged: (v) => setM(() => q = v),
                  ),
                  const SizedBox(height: 12),
                  Expanded(
                    child: GridView.builder(
                      controller: sc,
                      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: 3,
                        crossAxisSpacing: 8,
                        mainAxisSpacing: 8,
                        childAspectRatio: 2.2,
                      ),
                      itemCount: list.length,
                      itemBuilder: (_, idx) {
                        final sw = list[idx];
                        final sel = vr.hex.toLowerCase() == sw.hex.toLowerCase();
                        return InkWell(
                          borderRadius: BorderRadius.circular(12),
                          onTap: () {
                            setState(() {
                              vr.hex = sw.hex;
                              vr.colourNameCtrl.text = sw.name;
                            });
                            Navigator.pop(mCtx);
                          },
                          child: Container(
                            padding: const EdgeInsets.symmetric(horizontal: 8),
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(12),
                              border: Border.all(color: sel ? AppTheme.gold : Colors.white24, width: sel ? 2 : 1),
                            ),
                            child: Row(
                              children: [
                                Container(
                                  width: 20,
                                  height: 20,
                                  decoration: BoxDecoration(color: sw.color, shape: BoxShape.circle, border: Border.all(color: Colors.white54)),
                                ),
                                const SizedBox(width: 6),
                                Expanded(
                                  child: Text(sw.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w700)),
                                ),
                              ],
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final sizes = sizesForCategory(_category);
    final isEdit = widget.existing != null;

    return Padding(
      padding: EdgeInsets.only(
        left: 16,
        right: 16,
        top: 16,
        bottom: MediaQuery.of(context).viewInsets.bottom + 18,
      ),
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              isEdit ? 'Edit Stock & Sizes' : '+ Add New Stock (Multi-Colour)',
              style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800),
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                GestureDetector(
                  onTap: () => _pickPhoto(ImageSource.gallery),
                  child: Container(
                    width: 66,
                    height: 66,
                    decoration: BoxDecoration(
                      color: hexToColor(_variants.first.hex).withAlpha(45),
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: AppTheme.gold.withAlpha(110)),
                    ),
                    child: _photoBase64.isNotEmpty
                        ? ClipRRect(
                            borderRadius: BorderRadius.circular(15),
                            child: Image.memory(base64Decode(_photoBase64), fit: BoxFit.cover),
                          )
                        : const Icon(Icons.add_a_photo_rounded, color: AppTheme.gold, size: 24),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('Dress Photo (Optional)', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 12.5)),
                      const SizedBox(height: 6),
                      Wrap(
                        spacing: 6,
                        children: [
                          OutlinedButton.icon(
                            style: OutlinedButton.styleFrom(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4), minimumSize: Size.zero),
                            onPressed: () => _pickPhoto(ImageSource.camera),
                            icon: const Icon(Icons.camera_alt_rounded, size: 14),
                            label: const Text('Camera', style: TextStyle(fontSize: 11)),
                          ),
                          OutlinedButton.icon(
                            style: OutlinedButton.styleFrom(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4), minimumSize: Size.zero),
                            onPressed: () => _pickPhoto(ImageSource.gallery),
                            icon: const Icon(Icons.photo_library_rounded, size: 14),
                            label: const Text('Gallery', style: TextStyle(fontSize: 11)),
                          ),
                          if (_photoBase64.isNotEmpty)
                            TextButton(
                              style: TextButton.styleFrom(padding: const EdgeInsets.symmetric(horizontal: 6), minimumSize: Size.zero),
                              onPressed: () => setState(() => _photoBase64 = ''),
                              child: const Text('Remove', style: TextStyle(fontSize: 11, color: AppTheme.rose)),
                            ),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            TextField(controller: _nameCtrl, decoration: const InputDecoration(labelText: 'Dress / Pants Name *')),
            const SizedBox(height: 10),
            Row(
              children: [
                Expanded(
                  child: DropdownButtonFormField<String>(
                    initialValue: _category,
                    decoration: const InputDecoration(labelText: 'Category'),
                    items: kCategories.map((c) => DropdownMenuItem(value: c, child: Text(c))).toList(),
                    onChanged: (v) {
                      if (v != null) {
                        setState(() {
                          _category = v;
                          final newSizes = sizesForCategory(_category);
                          for (final vr in _variants) {
                            vr.rebuildSizes(newSizes);
                          }
                        });
                      }
                    },
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: DropdownButtonFormField<String>(
                    initialValue: _location,
                    decoration: const InputDecoration(labelText: 'Location'),
                    items: kLocations.map((l) => DropdownMenuItem(value: l, child: Text(l))).toList(),
                    onChanged: (v) {
                      if (v != null) setState(() => _location = v);
                    },
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),
            Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _costCtrl,
                    keyboardType: TextInputType.number,
                    decoration: const InputDecoration(labelText: 'Cost Price (₹) *'),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: TextField(
                    controller: _sellCtrl,
                    keyboardType: TextInputType.number,
                    decoration: const InputDecoration(labelText: 'Selling MRP (₹) *'),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 14),

            // Multi-Colour Variant Cards (Pick real-life colour OR type any custom colour name!)
            ...List.generate(_variants.length, (vIdx) {
              final vr = _variants[vIdx];
              return Container(
                margin: const EdgeInsets.only(bottom: 12),
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: AppTheme.gold.withAlpha(80)),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          _variants.length > 1 ? 'Colour #${vIdx + 1} & Sizes' : 'Colour & Size Quantities',
                          style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 12.5, color: AppTheme.gold),
                        ),
                        if (_variants.length > 1)
                          InkWell(
                            onTap: () => setState(() {
                              final removed = _variants.removeAt(vIdx);
                              removed.dispose();
                            }),
                            child: const Icon(Icons.close_rounded, size: 18, color: AppTheme.rose),
                          ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    InkWell(
                      borderRadius: BorderRadius.circular(14),
                      onTap: () => _openColourPickerModal(vr),
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(14),
                          border: Border.all(color: AppTheme.gold.withAlpha(110)),
                        ),
                        child: Row(
                          children: [
                            Container(
                              width: 22,
                              height: 22,
                              decoration: BoxDecoration(
                                color: hexToColor(vr.hex),
                                shape: BoxShape.circle,
                                border: Border.all(color: Colors.white54, width: 1.5),
                              ),
                            ),
                            const SizedBox(width: 10),
                            Expanded(
                              child: Text(
                                vr.colourNameCtrl.text.trim().isNotEmpty
                                    ? 'Colour: ${vr.colourNameCtrl.text.trim()}'
                                    : 'Choose Colour (${kColourSwatches.length} dress colours)',
                                style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 12.5),
                              ),
                            ),
                            const Icon(Icons.palette_outlined, size: 18, color: AppTheme.gold),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 8),
                    TextField(
                      controller: vr.colourNameCtrl,
                      decoration: const InputDecoration(
                        labelText: 'Colour Name (Pick above OR just type any colour)',
                        hintText: 'e.g. Bottle Green, Dusty Rose, Indigo Check...',
                      ),
                    ),
                    const SizedBox(height: 10),
                    Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      children: sizes.map((sz) {
                        return SizedBox(
                          width: 64,
                          child: TextField(
                            controller: vr.sizeCtrls[sz],
                            keyboardType: TextInputType.number,
                            textAlign: TextAlign.center,
                            decoration: InputDecoration(
                              labelText: sz,
                              contentPadding: const EdgeInsets.symmetric(horizontal: 6, vertical: 8),
                            ),
                          ),
                        );
                      }).toList(),
                    ),
                  ],
                ),
              );
            }),

            SizedBox(
                width: double.infinity,
                child: OutlinedButton.icon(
                  style: OutlinedButton.styleFrom(
                    foregroundColor: AppTheme.gold,
                    side: BorderSide(color: AppTheme.gold.withAlpha(130)),
                    padding: const EdgeInsets.symmetric(vertical: 11),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                  ),
                  onPressed: () {
                    setState(() {
                      final nextSwatch = kColourSwatches[_variants.length % kColourSwatches.length];
                      _variants.add(_ColourVariantEntry(
                        hex: nextSwatch.hex,
                        colourName: '',
                        sizes: sizesForCategory(_category),
                      ));
                    });
                  },
                  icon: const Icon(Icons.add_circle_outline_rounded, size: 18),
                  label: const Text('+ Add Another Colour', style: TextStyle(fontWeight: FontWeight.w800)),
                ),
              ),
            const SizedBox(height: 14),
            Row(
              children: [
                if (isEdit && widget.store.isAdmin) ...[
                  OutlinedButton.icon(
                    style: OutlinedButton.styleFrom(
                      foregroundColor: AppTheme.rose,
                      side: const BorderSide(color: AppTheme.rose),
                      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
                    ),
                    onPressed: _saving
                        ? null
                        : () async {
                            final ok = await showDialog<bool>(
                              context: context,
                              builder: (ctx) => AlertDialog(
                                title: const Text('Delete Stock Item?'),
                                content: Text('Delete "${widget.existing!.name}" permanently?'),
                                actions: [
                                  TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
                                  ElevatedButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Delete')),
                                ],
                              ),
                            );
                            if (ok == true) {
                              await widget.store.deleteStock(widget.existing!.id);
                              if (context.mounted) Navigator.pop(context);
                            }
                          },
                    icon: const Icon(Icons.delete_outline, size: 18),
                    label: const Text('Delete'),
                  ),
                  const SizedBox(width: 10),
                ],
                Expanded(
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppTheme.gold,
                      foregroundColor: Colors.black,
                      padding: const EdgeInsets.symmetric(vertical: 14),
                    ),
                    onPressed: _saving
                        ? null
                        : () async {
                            final name = _nameCtrl.text.trim();
                            final cost = double.tryParse(_costCtrl.text) ?? 0;
                            final sell = double.tryParse(_sellCtrl.text) ?? 0;
                            if (name.isEmpty) {
                              ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Enter garment name!')));
                              return;
                            }
                            if (sell <= 0 || sell < cost) {
                              ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Selling MRP cannot be less than Cost Price!')));
                              return;
                            }

                            final toSave = <StockItem>[];
                            final nowIso = DateTime.now().toIso8601String();
                            final today = getLocalDateString();

                            for (int idx = 0; idx < _variants.length; idx++) {
                              final vr = _variants[idx];
                              final map = <String, int>{};
                              int total = 0;
                              vr.sizeCtrls.forEach((k, c) {
                                final v = int.tryParse(c.text) ?? 0;
                                map[k] = v < 0 ? 0 : v;
                                total += map[k]!;
                              });
                              if (total <= 0) continue;
                              final typedColour = vr.colourNameCtrl.text.trim();
                              final itemName = (_variants.length > 1 && typedColour.isNotEmpty)
                                  ? '$name - $typedColour'
                                  : name;
                              toSave.add(StockItem(
                                id: (isEdit && idx == 0) ? widget.existing!.id : makeId('STK'),
                                name: itemName,
                                category: _category,
                                colour: vr.hex,
                                colourName: typedColour,
                                location: _location,
                                hsnCode: '6203',
                                sizes: map,
                                qty: total,
                                costPrice: cost,
                                sellPrice: sell,
                                addedBy: widget.store.userName,
                                date: (isEdit && idx == 0) ? widget.existing!.date : today,
                                createdAt: (isEdit && idx == 0) ? widget.existing!.createdAt : nowIso,
                                photoBase64: _photoBase64,
                              ));
                            }

                            if (toSave.isEmpty) {
                              ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Enter pieces for at least one colour & size!')));
                              return;
                            }

                            setState(() => _saving = true);
                            try {
                              for (final st in toSave) {
                                await widget.store.saveStock(st);
                              }
                              if (context.mounted) {
                                Navigator.pop(context);
                                ScaffoldMessenger.of(context).showSnackBar(
                                  SnackBar(content: Text('Saved ${toSave.length} colour variant${toSave.length == 1 ? '' : 's'}!')),
                                );
                              }
                            } catch (e) {
                              if (context.mounted) {
                                setState(() => _saving = false);
                                ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Save failed: $e')));
                              }
                            }
                          },
                    child: _saving
                        ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.black))
                        : Text(
                            isEdit
                                ? 'Update Stock'
                                : (_variants.length > 1 ? 'Save ${_variants.length} Colours' : 'Save Stock'),
                            style: const TextStyle(fontWeight: FontWeight.bold),
                          ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
