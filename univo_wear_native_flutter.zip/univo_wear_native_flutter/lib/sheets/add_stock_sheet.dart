import 'dart:convert';
import 'package:image_picker/image_picker.dart';
import 'package:flutter/material.dart';
import '../core/app_theme.dart';
import '../core/constants.dart';
import '../models/pos_models.dart';
import '../services/pos_store.dart';

class AddStockSheet extends StatefulWidget {
  final PosStore store;
  final StockItem? existing;
  const AddStockSheet({super.key, required this.store, this.existing});

  @override
  State<AddStockSheet> createState() => _AddStockSheetState();
}

class _AddStockSheetState extends State<AddStockSheet> {
  final _nameCtrl = TextEditingController();
  final _costCtrl = TextEditingController();
  final _sellCtrl = TextEditingController();
  final _colourCtrl = TextEditingController();
  String _category = 'Pants';
  String _location = 'Main Shop';
  String _hex = '#eab308';
  final Map<String, TextEditingController> _sizeCtrls = {};
  bool _saving = false;
  String _photoBase64 = '';

  @override
  void initState() {
    super.initState();
    final ex = widget.existing;
    if (ex != null) {
      _nameCtrl.text = ex.name;
      _costCtrl.text = ex.costPrice.toStringAsFixed(0);
      _sellCtrl.text = ex.sellPrice.toStringAsFixed(0);
      _colourCtrl.text = ex.colourName;
      _category = kCategories.contains(ex.category) ? ex.category : 'Shirts';
      _location = kLocations.contains(ex.location) ? ex.location : 'Main Shop';
      _hex = ex.colour;
      _photoBase64 = ex.photoBase64;
    }
    _resetSizes(ex?.sizes);
  }

  void _resetSizes([Map<String, int>? existingSizes]) {
    _sizeCtrls.clear();
    for (final sz in sizesForCategory(_category)) {
      _sizeCtrls[sz] = TextEditingController(text: '${existingSizes?[sz] ?? 0}');
    }
  }

  Future<void> _pickPhoto(ImageSource source) async {
    try {
      final picker = ImagePicker();
      final xfile = await picker.pickImage(source: source, maxWidth: 420, maxHeight: 420, imageQuality: 55);
      if (xfile == null) return;
      final bytes = await xfile.readAsBytes();
      if (mounted) setState(() => _photoBase64 = base64Encode(bytes));
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Photo error: $e')));
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final sizes = sizesForCategory(_category);
    return Padding(
      padding: EdgeInsets.only(
        left: 16,
        right: 16,
        top: 16,
        bottom: MediaQuery.of(context).viewInsets.bottom + 16,
      ),
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              widget.existing == null ? '+ Add New Stock' : 'Edit Stock & Sizes',
              style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                GestureDetector(
                  onTap: () => _pickPhoto(ImageSource.gallery),
                  child: Container(
                    width: 68,
                    height: 68,
                    decoration: BoxDecoration(
                      color: hexToColor(_hex).withAlpha(45),
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: AppTheme.gold.withAlpha(110)),
                    ),
                    child: _photoBase64.isNotEmpty
                        ? ClipRRect(
                            borderRadius: BorderRadius.circular(15),
                            child: Image.memory(base64Decode(_photoBase64), fit: BoxFit.cover),
                          )
                        : const Icon(Icons.add_a_photo_rounded, color: AppTheme.gold, size: 24),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('Dress Catalog Photo (Optional)', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 12.5)),
                      const SizedBox(height: 6),
                      Wrap(
                        spacing: 6,
                        children: [
                          OutlinedButton.icon(
                            style: OutlinedButton.styleFrom(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4), minimumSize: Size.zero),
                            onPressed: () => _pickPhoto(ImageSource.camera),
                            icon: const Icon(Icons.camera_alt_rounded, size: 14),
                            label: const Text('Camera', style: TextStyle(fontSize: 11)),
                          ),
                          OutlinedButton.icon(
                            style: OutlinedButton.styleFrom(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4), minimumSize: Size.zero),
                            onPressed: () => _pickPhoto(ImageSource.gallery),
                            icon: const Icon(Icons.photo_library_rounded, size: 14),
                            label: const Text('Gallery', style: TextStyle(fontSize: 11)),
                          ),
                          if (_photoBase64.isNotEmpty)
                            TextButton(
                              style: TextButton.styleFrom(padding: const EdgeInsets.symmetric(horizontal: 6), minimumSize: Size.zero),
                              onPressed: () => setState(() => _photoBase64 = ''),
                              child: const Text('Remove', style: TextStyle(fontSize: 11, color: AppTheme.rose)),
                            ),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            TextField(controller: _nameCtrl, decoration: const InputDecoration(labelText: 'Dress / Pants Name *')),
            const SizedBox(height: 10),
            Row(
              children: [
                Expanded(
                  child: DropdownButtonFormField<String>(
                    initialValue: _category,
                    decoration: const InputDecoration(labelText: 'Category'),
                    items: kCategories.map((c) => DropdownMenuItem(value: c, child: Text(c))).toList(),
                    onChanged: (v) {
                      if (v != null) {
                        setState(() {
                          _category = v;
                          _resetSizes();
                        });
                      }
                    },
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: DropdownButtonFormField<String>(
                    initialValue: _location,
                    decoration: const InputDecoration(labelText: 'Location'),
                    items: kLocations.map((l) => DropdownMenuItem(value: l, child: Text(l))).toList(),
                    onChanged: (v) {
                      if (v != null) setState(() => _location = v);
                    },
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),
            TextField(controller: _colourCtrl, decoration: const InputDecoration(labelText: 'Colour Name (e.g. Olive, Black)')),
            const SizedBox(height: 8),
            Wrap(
              spacing: 6,
              runSpacing: 6,
              children: kColourSwatches.map((s) {
                final sel = _hex.toLowerCase() == s.hex.toLowerCase();
                return GestureDetector(
                  onTap: () => setState(() {
                    _hex = s.hex;
                    _colourCtrl.text = s.name;
                  }),
                  child: Container(
                    width: 26,
                    height: 26,
                    decoration: BoxDecoration(
                      color: s.color,
                      shape: BoxShape.circle,
                      border: Border.all(color: sel ? AppTheme.gold : Colors.grey, width: sel ? 2.5 : 1),
                    ),
                  ),
                );
              }).toList(),
            ),
            const SizedBox(height: 12),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: sizes
                  .map(
                    (sz) => SizedBox(
                      width: 68,
                      child: TextField(
                        controller: _sizeCtrls[sz],
                        keyboardType: TextInputType.number,
                        textAlign: TextAlign.center,
                        decoration: InputDecoration(labelText: sz),
                      ),
                    ),
                  )
                  .toList(),
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _costCtrl,
                    keyboardType: TextInputType.number,
                    decoration: const InputDecoration(labelText: 'Cost Price (₹) *'),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: TextField(
                    controller: _sellCtrl,
                    keyboardType: TextInputType.number,
                    decoration: const InputDecoration(labelText: 'Selling MRP (₹) *'),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                if (widget.existing != null && widget.store.isAdmin) ...[
                  OutlinedButton.icon(
                    style: OutlinedButton.styleFrom(
                      foregroundColor: AppTheme.rose,
                      side: const BorderSide(color: AppTheme.rose),
                      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
                    ),
                    onPressed: _saving
                        ? null
                        : () async {
                            final ok = await showDialog<bool>(
                              context: context,
                              builder: (ctx) => AlertDialog(
                                title: const Text('Delete Stock Item?'),
                                content: Text('Delete "${widget.existing!.name}" permanently?'),
                                actions: [
                                  TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
                                  ElevatedButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Delete')),
                                ],
                              ),
                            );
                            if (ok == true) {
                              await widget.store.deleteStock(widget.existing!.id);
                              if (context.mounted) Navigator.pop(context);
                            }
                          },
                    icon: const Icon(Icons.delete_outline, size: 18),
                    label: const Text('Delete'),
                  ),
                  const SizedBox(width: 10),
                ],
                Expanded(
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppTheme.gold,
                      foregroundColor: Colors.black,
                      padding: const EdgeInsets.symmetric(vertical: 14),
                    ),
                    onPressed: _saving
                        ? null
                        : () async {
                            final name = _nameCtrl.text.trim();
                            final cost = double.tryParse(_costCtrl.text) ?? 0;
                            final sell = double.tryParse(_sellCtrl.text) ?? 0;
                            if (name.isEmpty) {
                              ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Enter garment name!')));
                              return;
                            }
                            if (sell <= 0 || sell < cost) {
                              ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Selling MRP cannot be less than Cost Price!')));
                              return;
                            }
                            final map = <String, int>{};
                            int total = 0;
                            _sizeCtrls.forEach((k, c) {
                              final v = int.tryParse(c.text) ?? 0;
                              map[k] = v < 0 ? 0 : v;
                              total += map[k]!;
                            });
                            if (total <= 0) {
                              ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Enter pieces for at least one size!')));
                              return;
                            }
                            setState(() => _saving = true);
                            try {
                              final item = StockItem(
                                id: widget.existing?.id ?? makeId('STK'),
                                name: name,
                                category: _category,
                                colour: _hex,
                                colourName: _colourCtrl.text.trim(),
                                location: _location,
                                hsnCode: '6203',
                                sizes: map,
                                qty: total,
                                costPrice: cost,
                                sellPrice: sell,
                                addedBy: widget.store.userName,
                                date: widget.existing?.date ?? getLocalDateString(),
                                createdAt: widget.existing?.createdAt ?? DateTime.now().toIso8601String(),
                                photoBase64: _photoBase64,
                              );
                              await widget.store.saveStock(item);
                              if (context.mounted) Navigator.pop(context);
                            } catch (e) {
                              if (context.mounted) {
                                setState(() => _saving = false);
                                ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Cloud sync failed: $e')));
                              }
                            }
                          },
                    child: _saving
                        ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.black))
                        : Text(widget.existing == null ? 'Save Stock' : 'Update Stock', style: const TextStyle(fontWeight: FontWeight.bold)),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
