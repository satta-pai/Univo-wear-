import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../core/app_theme.dart';
import '../services/pos_store.dart';

class LiveTourStep {
  final GlobalKey? targetKey;
  final String title;
  final String description;
  final String? shortcutHint;

  const LiveTourStep({
    this.targetKey,
    required this.title,
    required this.description,
    this.shortcutHint,
  });
}

Future<void> showLiveArrowTour(
  BuildContext context,
  PosStore s,
  List<LiveTourStep> steps, {
  VoidCallback? onOpenFullGuide,
}) async {
  if (steps.isEmpty) return;
  await showGeneralDialog<void>(
    context: context,
    barrierDismissible: false,
    barrierLabel: 'Live Tour',
    barrierColor: Colors.transparent,
    transitionDuration: const Duration(milliseconds: 220),
    pageBuilder: (dialogCtx, _, __) {
      return _LiveSpotlightTourOverlay(
        store: s,
        steps: steps,
        onOpenFullGuide: onOpenFullGuide,
      );
    },
  );
}

class _LiveSpotlightTourOverlay extends StatefulWidget {
  final PosStore store;
  final List<LiveTourStep> steps;
  final VoidCallback? onOpenFullGuide;

  const _LiveSpotlightTourOverlay({
    required this.store,
    required this.steps,
    this.onOpenFullGuide,
  });

  @override
  State<_LiveSpotlightTourOverlay> createState() => _LiveSpotlightTourOverlayState();
}

class _LiveSpotlightTourOverlayState extends State<_LiveSpotlightTourOverlay>
    with SingleTickerProviderStateMixin {
  int _idx = 0;
  Rect? _targetRect;
  late final AnimationController _pulseCtrl;

  @override
  void initState() {
    super.initState();
    _pulseCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1100),
    )..repeat(reverse: true);
    WidgetsBinding.instance.addPostFrameCallback((_) => _resolveTarget());
  }

  @override
  void dispose() {
    _pulseCtrl.dispose();
    super.dispose();
  }

  void _resolveTarget() {
    if (!mounted) return;
    final step = widget.steps[_idx];
    Rect? found;
    final key = step.targetKey;
    if (key != null && key.currentContext != null) {
      final ro = key.currentContext!.findRenderObject();
      if (ro is RenderBox && ro.hasSize && ro.attached) {
        final offset = ro.localToGlobal(Offset.zero);
        final r = offset & ro.size;
        if (r.width > 0 && r.height > 0) {
          found = r.inflate(6);
        }
      }
    }
    setState(() => _targetRect = found);
  }

  void _next() {
    if (_idx < widget.steps.length - 1) {
      setState(() => _idx++);
      WidgetsBinding.instance.addPostFrameCallback((_) => _resolveTarget());
    } else {
      Navigator.of(context).pop();
    }
  }

  void _prev() {
    if (_idx > 0) {
      setState(() => _idx--);
      WidgetsBinding.instance.addPostFrameCallback((_) => _resolveTarget());
    }
  }

  @override
  Widget build(BuildContext context) {
    final s = widget.store;
    final size = MediaQuery.of(context).size;
    final accent = s.isDark ? AppTheme.gold : AppTheme.goldLightMode;
    final cardBg = s.isDark ? const Color(0xFF151822) : const Color(0xFFFFFFFF);
    final textCol = s.isDark ? const Color(0xFFF8FAFC) : const Color(0xFF111318);
    final muted = s.isDark ? const Color(0xFF94A3B8) : const Color(0xFF64748B);
    final step = widget.steps[_idx];

    final cardWidth = math.min(size.width - 32.0, 390.0);
    final target = _targetRect;

    // Position the tooltip card cleanly above or below the highlighted live widget
    double cardTop;
    bool cardBelowTarget = true;
    if (target == null) {
      cardTop = (size.height - 230) / 2;
    } else {
      final spaceBelow = size.height - target.bottom;
      final spaceAbove = target.top;
      if (spaceBelow >= 240 || spaceBelow >= spaceAbove) {
        cardBelowTarget = true;
        cardTop = math.min(target.bottom + 46, size.height - 235);
      } else {
        cardBelowTarget = false;
        cardTop = math.max(24, target.top - 245);
      }
    }
    final cardLeft = target == null
        ? (size.width - cardWidth) / 2
        : (target.center.dx - cardWidth / 2).clamp(16.0, math.max(16.0, size.width - cardWidth - 16.0));

    final cardAnchor = Offset(
      (cardLeft + cardWidth / 2).clamp(32.0, size.width - 32.0),
      cardBelowTarget ? cardTop : (cardTop + 190).clamp(60.0, size.height - 40.0),
    );

    return CallbackShortcuts(
      bindings: {
        const SingleActivator(LogicalKeyboardKey.escape): () => Navigator.of(context).pop(),
        const SingleActivator(LogicalKeyboardKey.arrowRight): _next,
        const SingleActivator(LogicalKeyboardKey.enter): _next,
        const SingleActivator(LogicalKeyboardKey.arrowLeft): _prev,
      },
      child: Focus(
        autofocus: true,
        child: Material(
          type: MaterialType.transparency,
          child: AnimatedBuilder(
            animation: _pulseCtrl,
            builder: (context, _) {
              return Stack(
                children: [
                  // Full-screen spotlight scrim + golden target ring + curved pointer arrow
                  Positioned.fill(
                    child: GestureDetector(
                      onTap: _next,
                      child: CustomPaint(
                        painter: _SpotlightArrowPainter(
                          targetRect: target,
                          cardAnchor: cardAnchor,
                          cardBelowTarget: cardBelowTarget,
                          accent: accent,
                          pulse: _pulseCtrl.value,
                        ),
                      ),
                    ),
                  ),
                  // Floating Coach-Mark Explanation Card
                  Positioned(
                    left: cardLeft,
                    top: cardTop,
                    width: cardWidth,
                    child: Container(
                      padding: const EdgeInsets.all(18),
                      decoration: BoxDecoration(
                        color: cardBg,
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(color: accent.withAlpha(180), width: 1.5),
                        boxShadow: const [
                          BoxShadow(color: Colors.black54, blurRadius: 28, offset: Offset(0, 12)),
                        ],
                      ),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 3),
                                decoration: BoxDecoration(
                                  color: accent.withAlpha(36),
                                  borderRadius: BorderRadius.circular(20),
                                ),
                                child: Text(
                                  '${s.t("Step", "படி")} ${_idx + 1} / ${widget.steps.length}',
                                  style: TextStyle(color: accent, fontSize: 11, fontWeight: FontWeight.w900),
                                ),
                              ),
                              if (step.shortcutHint != null) ...[
                                const SizedBox(width: 8),
                                Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2.5),
                                  decoration: BoxDecoration(
                                    color: muted.withAlpha(30),
                                    borderRadius: BorderRadius.circular(6),
                                    border: Border.all(color: muted.withAlpha(80)),
                                  ),
                                  child: Text(
                                    step.shortcutHint!,
                                    style: TextStyle(color: textCol, fontSize: 10, fontWeight: FontWeight.w800),
                                  ),
                                ),
                              ],
                              const Spacer(),
                              InkWell(
                                borderRadius: BorderRadius.circular(12),
                                onTap: () => Navigator.of(context).pop(),
                                child: Padding(
                                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                                  child: Text(
                                    s.t('Skip', 'தவிர்'),
                                    style: TextStyle(color: muted, fontSize: 12, fontWeight: FontWeight.w700),
                                  ),
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 10),
                          Row(
                            children: [
                              Icon(Icons.lightbulb_rounded, size: 18, color: accent),
                              const SizedBox(width: 7),
                              Expanded(
                                child: Text(
                                  step.title,
                                  style: TextStyle(
                                    color: textCol,
                                    fontSize: 15,
                                    fontWeight: FontWeight.w900,
                                  ),
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 8),
                          Text(
                            step.description,
                            style: TextStyle(
                              color: textCol.withAlpha(220),
                              fontSize: 12.8,
                              height: 1.48,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                          const SizedBox(height: 14),
                          Row(
                            children: [
                              if (widget.onOpenFullGuide != null && _idx == widget.steps.length - 1)
                                TextButton(
                                  onPressed: () {
                                    Navigator.of(context).pop();
                                    widget.onOpenFullGuide!();
                                  },
                                  child: Text(
                                    s.t('Full Guide', 'முழு வழிகாட்டி'),
                                    style: TextStyle(color: accent, fontWeight: FontWeight.w800, fontSize: 12),
                                  ),
                                )
                              else if (_idx > 0)
                                TextButton.icon(
                                  onPressed: _prev,
                                  icon: Icon(Icons.arrow_back_rounded, size: 15, color: muted),
                                  label: Text(s.t('Back', 'பின்'), style: TextStyle(color: muted, fontWeight: FontWeight.w700)),
                                ),
                              const Spacer(),
                              ElevatedButton.icon(
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: accent,
                                  foregroundColor: const Color(0xFF0A0B0E),
                                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                                ),
                                onPressed: _next,
                                icon: Icon(
                                  _idx == widget.steps.length - 1 ? Icons.check_rounded : Icons.arrow_forward_rounded,
                                  size: 16,
                                ),
                                label: Text(
                                  _idx == widget.steps.length - 1
                                      ? s.t('Got it!', 'புரிந்தது!')
                                      : s.t('Next', 'அடுத்து'),
                                  style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 12.5),
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              );
            },
          ),
        ),
      ),
    );
  }
}

class _SpotlightArrowPainter extends CustomPainter {
  final Rect? targetRect;
  final Offset cardAnchor;
  final bool cardBelowTarget;
  final Color accent;
  final double pulse;

  const _SpotlightArrowPainter({
    required this.targetRect,
    required this.cardAnchor,
    required this.cardBelowTarget,
    required this.accent,
    required this.pulse,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final full = Path()..addRect(Offset.zero & size);
    if (targetRect != null) {
      final hole = Path()
        ..addRRect(RRect.fromRectAndRadius(targetRect!, const Radius.circular(14)));
      final scrimPath = Path.combine(PathOperation.difference, full, hole);
      canvas.drawPath(scrimPath, Paint()..color = Colors.black.withAlpha(188));

      // Animated glowing champagne-gold spotlight ring around the real widget
      final glowRect = targetRect!.inflate(2.0 + (pulse * 3.0));
      canvas.drawRRect(
        RRect.fromRectAndRadius(glowRect, const Radius.circular(16)),
        Paint()
          ..color = accent.withAlpha((120 + (pulse * 90)).round())
          ..style = PaintingStyle.stroke
          ..strokeWidth = 2.4,
      );

      // Curved golden arrow pointing straight from tooltip card to the target widget
      final endPt = Offset(
        targetRect!.center.dx.clamp(24.0, size.width - 24.0),
        cardBelowTarget ? targetRect!.bottom + 8 : targetRect!.top - 8,
      );
      final startPt = Offset(
        cardAnchor.dx,
        cardBelowTarget ? cardAnchor.dy - 4 : cardAnchor.dy + 4,
      );
      final ctrlPt = Offset(
        (startPt.dx + endPt.dx) / 2 + (startPt.dx < endPt.dx ? -18 : 18),
        (startPt.dy + endPt.dy) / 2,
      );

      final arrowPath = Path()
        ..moveTo(startPt.dx, startPt.dy)
        ..quadraticBezierTo(ctrlPt.dx, ctrlPt.dy, endPt.dx, endPt.dy);

      final arrowPaint = Paint()
        ..color = accent
        ..style = PaintingStyle.stroke
        ..strokeWidth = 3.0
        ..strokeCap = StrokeCap.round;
      canvas.drawPath(arrowPath, arrowPaint);

      // Arrowhead at endPt aligned with tangent from ctrlPt -> endPt
      final angle = math.atan2(endPt.dy - ctrlPt.dy, endPt.dx - ctrlPt.dx);
      const headLen = 12.0;
      final p1 = Offset(
        endPt.dx - headLen * math.cos(angle - 0.52),
        endPt.dy - headLen * math.sin(angle - 0.52),
      );
      final p2 = Offset(
        endPt.dx - headLen * math.cos(angle + 0.52),
        endPt.dy - headLen * math.sin(angle + 0.52),
      );
      final headPath = Path()
        ..moveTo(p1.dx, p1.dy)
        ..lineTo(endPt.dx, endPt.dy)
        ..lineTo(p2.dx, p2.dy);
      canvas.drawPath(headPath, arrowPaint);
    } else {
      canvas.drawPath(full, Paint()..color = Colors.black.withAlpha(182));
    }
  }

  @override
  bool shouldRepaint(covariant _SpotlightArrowPainter old) =>
      old.targetRect != targetRect ||
      old.cardAnchor != cardAnchor ||
      old.pulse != pulse;
}
