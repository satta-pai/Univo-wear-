import 'package:flutter/material.dart';
import '../core/app_theme.dart';
import '../core/constants.dart';
import '../models/pos_models.dart';
import '../services/pos_store.dart';

void showDayBookSheet(BuildContext context, PosStore s) {
  final openCtrl = TextEditingController(text: s.openingCash.toStringAsFixed(0));
  final expCtrl = TextEditingController(text: s.dailyExpense.toStringAsFixed(0));

  showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    builder: (ctx) => StatefulBuilder(
      builder: (ctx, setSt) {
        final openCash = double.tryParse(openCtrl.text) ?? 0;
        final expense = double.tryParse(expCtrl.text) ?? 0;
        double cashSales = 0, upiSales = 0, cardSales = 0;
        for (final sale in s.sales) {
          if (sale.payment == 'Cash') cashSales += sale.totalSellPrice;
          else if (sale.payment == 'UPI / GPay') upiSales += sale.totalSellPrice;
          else if (sale.payment == 'Card') cardSales += sale.totalSellPrice;
        }
        final khataPaid = s.khata
            .where((k) => k['status'] == 'Paid')
            .fold<double>(0, (a, b) => a + ((b['amount'] as num? ?? 0).toDouble()));
        final netDrawer = openCash + cashSales + khataPaid - expense;

        return Padding(
          padding: EdgeInsets.only(left: 16, right: 16, top: 16, bottom: MediaQuery.of(ctx).viewInsets.bottom + 16),
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Daily Day-Book & Cash Handover', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: AppTheme.green)),
                const SizedBox(height: 12),
                Row(
                  children: [
                    Expanded(
                      child: TextField(
                        controller: openCtrl,
                        keyboardType: TextInputType.number,
                        decoration: const InputDecoration(labelText: 'Opening Cash (₹)'),
                        onChanged: (_) => setSt(() {}),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: TextField(
                        controller: expCtrl,
                        keyboardType: TextInputType.number,
                        decoration: const InputDecoration(labelText: 'Today Expense (₹)'),
                        onChanged: (_) => setSt(() {}),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(14),
                    child: Column(
                      children: [
                        _row('Opening Drawer Cash', formatInr(openCash)),
                        _row('+ Cash Sales', formatInr(cashSales), color: AppTheme.green),
                        _row('+ UPI / GPay (Bank)', formatInr(upiSales), color: Colors.lightBlueAccent),
                        _row('+ Card Sales (Bank)', formatInr(cardSales), color: Colors.indigoAccent),
                        _row('+ Khata Collected', formatInr(khataPaid), color: AppTheme.gold),
                        _row('- Shop Expenses', '-${formatInr(expense)}', color: Colors.redAccent),
                        const Divider(),
                        _row('Net Cash Handover', formatInr(netDrawer), color: AppTheme.green, bold: true),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 12),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton.icon(
                    style: ElevatedButton.styleFrom(backgroundColor: AppTheme.green, foregroundColor: Colors.black, padding: const EdgeInsets.symmetric(vertical: 13)),
                    onPressed: () {
                      final msg = 'UNIVO WEAR DAY-BOOK (${getLocalDateString()})\nOpening Cash: ${formatInr(openCash)}\nCash Sales: ${formatInr(cashSales)}\nUPI/GPay: ${formatInr(upiSales)}\nExpenses: -${formatInr(expense)}\nNet Cash Handover: ${formatInr(netDrawer)}';
                      openWhatsAppMessage(msg);
                    },
                    icon: const Icon(Icons.share),
                    label: const Text('Send Day-Book to Owner (WhatsApp)', style: TextStyle(fontWeight: FontWeight.bold)),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    ),
  );
}

Widget _row(String label, String val, {Color? color, bool bold = false}) {
  return Padding(
    padding: const EdgeInsets.symmetric(vertical: 3),
    child: Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(label, style: TextStyle(fontWeight: bold ? FontWeight.bold : FontWeight.normal, fontSize: bold ? 14 : 12)),
        Text(val, style: TextStyle(fontWeight: FontWeight.bold, fontSize: bold ? 16 : 13, color: color)),
      ],
    ),
  );
}

void showKhataSheet(BuildContext context, PosStore s) {
  final nameCtrl = TextEditingController();
  final phoneCtrl = TextEditingController();
  final amtCtrl = TextEditingController();
  final noteCtrl = TextEditingController();

  showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    builder: (ctx) => Padding(
      padding: EdgeInsets.only(left: 16, right: 16, top: 16, bottom: MediaQuery.of(ctx).viewInsets.bottom + 16),
      child: SizedBox(
        height: MediaQuery.of(ctx).size.height * 0.78,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Customer Credit (Khata) Ledger', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: AppTheme.gold)),
            const SizedBox(height: 10),
            Row(
              children: [
                Expanded(child: TextField(controller: nameCtrl, decoration: const InputDecoration(labelText: 'Name *'))),
                const SizedBox(width: 8),
                Expanded(child: TextField(controller: phoneCtrl, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: 'Mobile *'))),
              ],
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                Expanded(child: TextField(controller: amtCtrl, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Due ₹ *'))),
                const SizedBox(width: 8),
                Expanded(child: TextField(controller: noteCtrl, decoration: const InputDecoration(labelText: 'Dress Note'))),
                const SizedBox(width: 8),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(backgroundColor: AppTheme.gold, foregroundColor: Colors.black),
                  onPressed: () async {
                    final amt = double.tryParse(amtCtrl.text) ?? 0;
                    if (nameCtrl.text.trim().isEmpty || amt <= 0) return;
                    await s.addSimpleDoc('khata', {
                      'id': makeId('KHT'),
                      'customerName': nameCtrl.text.trim(),
                      'phone': phoneCtrl.text.trim(),
                      'amount': amt,
                      'note': noteCtrl.text.trim(),
                      'status': 'Pending',
                      'date': getLocalDateString(),
                      'createdAt': DateTime.now().toIso8601String(),
                    });
                    if (ctx.mounted) Navigator.pop(ctx);
                  },
                  child: const Text('+ Add'),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Expanded(
              child: ListView.builder(
                itemCount: s.khata.length,
                itemBuilder: (_, i) {
                  final k = s.khata[i];
                  final isPaid = k['status'] == 'Paid';
                  final amt = (k['amount'] as num? ?? 0).toDouble();
                  return Card(
                    child: ListTile(
                      title: Text('${k['customerName']} (${k['phone'] ?? ''})', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
                      subtitle: Text('${k['note'] ?? ''} • ${k['date'] ?? ''}', style: const TextStyle(fontSize: 11)),
                      trailing: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text(
                            formatInr(amt),
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                              color: isPaid ? AppTheme.green : Colors.redAccent,
                              decoration: isPaid ? TextDecoration.lineThrough : null,
                            ),
                          ),
                          IconButton(
                            icon: const Icon(Icons.share, color: AppTheme.green, size: 18),
                            onPressed: () => openWhatsAppMessage(
                              'வணக்கம் ${k['customerName']}, UNIVO WEAR கடையில் உங்களது நிலுவைத் தொகை: ${formatInr(amt)} (${k['note'] ?? 'Dress Bill'}). நேரில் அல்லது GPay மூலம் செலுத்தவும். நன்றி!',
                              phone: (k['phone'] ?? '').toString(),
                            ),
                          ),
                          if (!isPaid)
                            TextButton(
                              onPressed: () async {
                                final updated = Map<String, dynamic>.from(k);
                                updated['status'] = 'Paid';
                                await s.addSimpleDoc('khata', updated);
                                if (ctx.mounted) Navigator.pop(ctx);
                              },
                              child: const Text('Paid', style: TextStyle(color: AppTheme.gold, fontWeight: FontWeight.bold)),
                            ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    ),
  );
}

void showAlterationsSheet(BuildContext context, PosStore s) {
  final nameCtrl = TextEditingController();
  final phoneCtrl = TextEditingController();
  final notesCtrl = TextEditingController();
  final feeCtrl = TextEditingController(text: '50');

  showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    builder: (ctx) => Padding(
      padding: EdgeInsets.only(left: 16, right: 16, top: 16, bottom: MediaQuery.of(ctx).viewInsets.bottom + 16),
      child: SizedBox(
        height: MediaQuery.of(ctx).size.height * 0.78,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Tailoring & Alteration Job-Slips', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.indigoAccent)),
            const SizedBox(height: 10),
            Row(
              children: [
                Expanded(child: TextField(controller: nameCtrl, decoration: const InputDecoration(labelText: 'Customer *'))),
                const SizedBox(width: 8),
                Expanded(child: TextField(controller: phoneCtrl, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: 'Mobile *'))),
              ],
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                Expanded(flex: 2, child: TextField(controller: notesCtrl, decoration: const InputDecoration(labelText: 'Alteration Note (e.g. Pant 38") *'))),
                const SizedBox(width: 8),
                Expanded(child: TextField(controller: feeCtrl, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Fee ₹'))),
              ],
            ),
            const SizedBox(height: 8),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(backgroundColor: Colors.indigoAccent, foregroundColor: Colors.white),
                onPressed: () async {
                  if (nameCtrl.text.trim().isEmpty || notesCtrl.text.trim().isEmpty) return;
                  await s.addSimpleDoc('alterations', {
                    'id': makeId('ALT'),
                    'customerName': nameCtrl.text.trim(),
                    'phone': phoneCtrl.text.trim(),
                    'notes': notesCtrl.text.trim(),
                    'fee': double.tryParse(feeCtrl.text) ?? 0,
                    'status': 'Pending',
                    'date': getLocalDateString(),
                    'createdAt': DateTime.now().toIso8601String(),
                  });
                  if (ctx.mounted) Navigator.pop(ctx);
                },
                child: const Text('+ Create Job Slip'),
              ),
            ),
            const SizedBox(height: 10),
            Expanded(
              child: ListView.builder(
                itemCount: s.alterations.length,
                itemBuilder: (_, i) {
                  final a = s.alterations[i];
                  final st = (a['status'] ?? 'Pending').toString();
                  return Card(
                    child: ListTile(
                      title: Text('${a['customerName']} (${a['phone'] ?? ''})', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
                      subtitle: Text('${a['notes'] ?? ''} • Fee: ₹${a['fee'] ?? 0}', style: const TextStyle(fontSize: 11)),
                      trailing: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          IconButton(
                            icon: const Icon(Icons.share, color: AppTheme.green, size: 18),
                            onPressed: () => openWhatsAppMessage(
                              'வணக்கம் ${a['customerName']}, UNIVO WEAR கடையில் நீங்கள் கொடுத்த ஆடை ஆல்டரேஷன் (${a['notes']}) தயாராக உள்ளது! நேரில் வந்து பெற்றுக்கொள்ளலாம். நன்றி!',
                              phone: (a['phone'] ?? '').toString(),
                            ),
                          ),
                          ElevatedButton(
                            onPressed: () async {
                              final next = st == 'Pending' ? 'Ready' : (st == 'Ready' ? 'Delivered' : 'Pending');
                              final updated = Map<String, dynamic>.from(a);
                              updated['status'] = next;
                              await s.addSimpleDoc('alterations', updated);
                              if (ctx.mounted) Navigator.pop(ctx);
                            },
                            child: Text(st, style: const TextStyle(fontSize: 11)),
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    ),
  );
}

void showSuppliersSheet(BuildContext context, PosStore s) {
  final nameCtrl = TextEditingController();
  final cityCtrl = TextEditingController();
  final billCtrl = TextEditingController();
  final amtCtrl = TextEditingController();

  showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    builder: (ctx) => Padding(
      padding: EdgeInsets.only(left: 16, right: 16, top: 16, bottom: MediaQuery.of(ctx).viewInsets.bottom + 16),
      child: SizedBox(
        height: MediaQuery.of(ctx).size.height * 0.78,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Wholesale Supplier Purchase Bills', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.lightBlueAccent)),
            const SizedBox(height: 10),
            Row(
              children: [
                Expanded(child: TextField(controller: nameCtrl, decoration: const InputDecoration(labelText: 'Mill / Supplier *'))),
                const SizedBox(width: 8),
                Expanded(child: TextField(controller: cityCtrl, decoration: const InputDecoration(labelText: 'City (Erode/Surat)'))),
              ],
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                Expanded(child: TextField(controller: billCtrl, decoration: const InputDecoration(labelText: 'Invoice No *'))),
                const SizedBox(width: 8),
                Expanded(child: TextField(controller: amtCtrl, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Amount ₹ *'))),
              ],
            ),
            const SizedBox(height: 8),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(backgroundColor: Colors.lightBlueAccent, foregroundColor: Colors.black),
                onPressed: () async {
                  final amt = double.tryParse(amtCtrl.text) ?? 0;
                  if (nameCtrl.text.trim().isEmpty || amt <= 0) return;
                  await s.addSimpleDoc('suppliers', {
                    'id': makeId('SUP'),
                    'name': nameCtrl.text.trim(),
                    'city': cityCtrl.text.trim(),
                    'billNo': billCtrl.text.trim(),
                    'amount': amt,
                    'status': 'Pending',
                    'date': getLocalDateString(),
                    'createdAt': DateTime.now().toIso8601String(),
                  });
                  if (ctx.mounted) Navigator.pop(ctx);
                },
                child: const Text('+ Save Supplier Bill', style: TextStyle(fontWeight: FontWeight.bold)),
              ),
            ),
            const SizedBox(height: 10),
            Expanded(
              child: ListView.builder(
                itemCount: s.suppliers.length,
                itemBuilder: (_, i) {
                  final sup = s.suppliers[i];
                  final isPaid = sup['status'] == 'Paid';
                  return Card(
                    child: ListTile(
                      title: Text('${sup['name']} (${sup['city'] ?? ''})', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
                      subtitle: Text('Bill #${sup['billNo'] ?? ''} • ${sup['date'] ?? ''}', style: const TextStyle(fontSize: 11)),
                      trailing: TextButton(
                        onPressed: () async {
                          final updated = Map<String, dynamic>.from(sup);
                          updated['status'] = isPaid ? 'Pending' : 'Paid';
                          await s.addSimpleDoc('suppliers', updated);
                          if (ctx.mounted) Navigator.pop(ctx);
                        },
                        child: Text(
                          '${formatInr((sup['amount'] as num? ?? 0).toDouble())} (${sup['status']})',
                          style: TextStyle(color: isPaid ? AppTheme.green : AppTheme.gold, fontWeight: FontWeight.bold),
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    ),
  );
}

void showGodownTransferSheet(BuildContext context, PosStore s) {
  if (s.stock.isEmpty) return;
  StockItem selected = s.stock.first;
  String toLoc = 'Main Shop';

  showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    builder: (ctx) => StatefulBuilder(
      builder: (ctx, setSt) => Padding(
        padding: EdgeInsets.only(left: 16, right: 16, top: 16, bottom: MediaQuery.of(ctx).viewInsets.bottom + 16),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Godown ↔ Shop Stock Transfer', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: AppTheme.gold)),
            const SizedBox(height: 12),
            DropdownButtonFormField<String>(
              value: selected.id,
              isExpanded: true,
              decoration: const InputDecoration(labelText: 'Select Stock Item'),
              items: s.stock.map((i) => DropdownMenuItem(value: i.id, child: Text('${i.name} [${i.location}] (${i.qty} pcs)'))).toList(),
              onChanged: (id) {
                if (id != null) setSt(() => selected = s.stock.firstWhere((e) => e.id == id));
              },
            ),
            const SizedBox(height: 10),
            DropdownButtonFormField<String>(
              value: toLoc,
              decoration: const InputDecoration(labelText: 'Move To Location'),
              items: kLocations.map((l) => DropdownMenuItem(value: l, child: Text(l))).toList(),
              onChanged: (v) {
                if (v != null) setSt(() => toLoc = v);
              },
            ),
            const SizedBox(height: 14),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(backgroundColor: AppTheme.gold, foregroundColor: Colors.black, padding: const EdgeInsets.symmetric(vertical: 13)),
                onPressed: () async {
                  final updated = StockItem(
                    id: selected.id,
                    name: selected.name,
                    category: selected.category,
                    colour: selected.colour,
                    colourName: selected.colourName,
                    location: toLoc,
                    hsnCode: selected.hsnCode,
                    sizes: selected.sizes,
                    qty: selected.qty,
                    costPrice: selected.costPrice,
                    sellPrice: selected.sellPrice,
                    addedBy: selected.addedBy,
                    date: selected.date,
                    createdAt: selected.createdAt,
                  );
                  await s.saveStock(updated);
                  if (ctx.mounted) Navigator.pop(ctx);
                },
                child: const Text('Confirm Location Transfer', style: TextStyle(fontWeight: FontWeight.bold)),
              ),
            ),
          ],
        ),
      ),
    ),
  );
}

void showVipLoyaltySheet(BuildContext context, PosStore s) {
  showModalBottomSheet(
    context: context,
    builder: (ctx) => Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('VIP Customer Loyalty Club (1 Pt / ₹100)', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.pinkAccent)),
          const SizedBox(height: 10),
          Expanded(
            child: s.customers.isEmpty
                ? const Center(child: Text('Enter customer mobile numbers during billing to earn VIP points!'))
                : ListView.builder(
                    itemCount: s.customers.length,
                    itemBuilder: (_, i) {
                      final c = s.customers[i];
                      return Card(
                        child: ListTile(
                          leading: const CircleAvatar(backgroundColor: Colors.pinkAccent, child: Icon(Icons.star, color: Colors.white)),
                          title: Text('${c['name'] ?? 'VIP Customer'}', style: const TextStyle(fontWeight: FontWeight.bold)),
                          subtitle: Text('${c['phone'] ?? ''} • Spent: ${formatInr((c['totalSpent'] as num? ?? 0).toDouble())}'),
                          trailing: Text('${c['points'] ?? 0} Pts', style: const TextStyle(fontWeight: FontWeight.w800, color: Colors.pinkAccent, fontSize: 14)),
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
    ),
  );
}
