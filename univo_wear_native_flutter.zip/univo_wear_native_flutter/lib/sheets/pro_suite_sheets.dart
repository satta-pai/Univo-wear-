import 'png_share_helper.dart';
import 'package:flutter/material.dart';
import '../core/app_theme.dart';
import '../core/constants.dart';
import '../models/pos_models.dart';
import '../services/pos_store.dart';

void showDayBookSheet(BuildContext context, PosStore s) {
  final openCtrl = TextEditingController(text: s.openingCash.toStringAsFixed(0));
  final expCtrl = TextEditingController(text: s.dailyExpense.toStringAsFixed(0));
  final boundaryKey = GlobalKey();
  bool exporting = false;

  showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    builder: (ctx) => StatefulBuilder(
      builder: (ctx, setSt) {
        final openCash = double.tryParse(openCtrl.text) ?? 0;
        final expense = double.tryParse(expCtrl.text) ?? 0;
        s.openingCash = openCash;
        s.dailyExpense = expense;
        double cashSales = 0, upiSales = 0, cardSales = 0, creditSales = 0, otherSales = 0, totalLess = 0;
        int pcsSoldToday = 0;
        final todayStr = getLocalDateString();
        final todayBills = s.sales.where((x) => x.date == todayStr || x.createdAt.startsWith(todayStr)).toList();
        for (final sale in todayBills) {
          pcsSoldToday += sale.qty;
          totalLess += sale.discount;
          final p = sale.payment.toLowerCase();
          if (p.contains('cash')) {
            cashSales += sale.totalSellPrice;
          } else if (p.contains('upi') || p.contains('gpay') || p.contains('phonepe') || p.contains('paytm') || p.contains('online') || p.contains('qr')) {
            upiSales += sale.totalSellPrice;
          } else if (p.contains('card')) {
            cardSales += sale.totalSellPrice;
          } else if (p.contains('credit') || p.contains('khata')) {
            creditSales += sale.totalSellPrice;
          } else {
            otherSales += sale.totalSellPrice;
          }
        }
        final totalDaySales = cashSales + upiSales + cardSales + creditSales + otherSales;
        final totalStockPcs = s.stock.fold<int>(0, (a, b) => a + b.qty);
        final totalStockValue = s.stock.fold<double>(0, (a, b) => a + (b.sellPrice * b.qty));
        final khataPaid = s.khata
            .where((k) => k['status'] == 'Paid' && ((k['date'] ?? '').toString() == todayStr || (k['updatedAt'] ?? '').toString().startsWith(todayStr)))
            .fold<double>(0, (a, b) => a + ((b['amount'] as num? ?? 0).toDouble()));
        final netDrawer = openCash + cashSales + khataPaid - expense;
        final totalReceivedToday = cashSales + upiSales + cardSales + otherSales + khataPaid;

        Future<void> exportDayBookPng(bool doShare) async {
          if (exporting) return;
          setSt(() => exporting = true);
          try {
            final res = await captureAndSaveOrSharePng(
              boundaryKey,
              fileNamePrefix: 'UNIVO_DAYBOOK_$todayStr',
              share: doShare,
              shareText: 'UNIVO WEAR Daily Closing ($todayStr) • Total Sales: ${formatInr(totalDaySales)}',
            );
            if (!doShare && res != null && ctx.mounted) {
              ScaffoldMessenger.of(ctx).showSnackBar(
                SnackBar(
                  content: Text(res.inDownloads
                      ? 'Closing PNG saved to Downloads: ${res.fileName}'
                      : 'Closing PNG saved to Storage: ${res.fileName}'),
                ),
              );
            }
          } catch (e) {
            if (ctx.mounted) {
              ScaffoldMessenger.of(ctx).showSnackBar(SnackBar(content: Text('PNG error: $e')));
            }
          } finally {
            if (ctx.mounted) setSt(() => exporting = false);
          }
        }

        return Padding(
          padding: EdgeInsets.only(left: 16, right: 16, top: 16, bottom: MediaQuery.of(ctx).viewInsets.bottom + 18),
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Daily Closing & Stock Report ($todayStr)', style: const TextStyle(fontSize: 15.5, fontWeight: FontWeight.w800, color: AppTheme.green)),
                const SizedBox(height: 10),
                Row(
                  children: [
                    Expanded(
                      child: TextField(
                        controller: openCtrl,
                        keyboardType: TextInputType.number,
                        decoration: const InputDecoration(labelText: 'Opening Cash (₹)'),
                        onChanged: (_) => setSt(() {}),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: TextField(
                        controller: expCtrl,
                        keyboardType: TextInputType.number,
                        decoration: const InputDecoration(labelText: 'Today Expense (₹)'),
                        onChanged: (_) => setSt(() {}),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                // Branded White & Gold Capturable Daily Closing PNG Card
                RepaintBoundary(
                  key: boundaryKey,
                  child: Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: const Color(0xFFFFFFFF),
                      borderRadius: BorderRadius.circular(18),
                      border: Border.all(color: const Color(0xFFE5B869), width: 1.5),
                    ),
                    child: DefaultTextStyle(
                      style: const TextStyle(color: Color(0xFF111318), fontSize: 12),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              ClipRRect(
                                borderRadius: BorderRadius.circular(8),
                                child: Image.asset('assets/images/univo_logo.png', width: 34, height: 34, fit: BoxFit.cover),
                              ),
                              const SizedBox(width: 8),
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  const Text('UNIVO WEAR', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900, letterSpacing: 1.8, color: Color(0xFF111318))),
                                  Text('DAILY SALES & STOCK CLOSING • $todayStr', style: const TextStyle(fontSize: 8.5, fontWeight: FontWeight.w800, color: Color(0xFF9A6B22))),
                                ],
                              ),
                            ],
                          ),
                          const Divider(height: 18, color: Color(0xFFE2E8F0)),
                          _pngRow('Bills & Pieces Sold Today', '${todayBills.length} bills ($pcsSoldToday pcs)', bold: true),
                          _pngRow('Balance Stock In-Shop', '$totalStockPcs pcs (${formatInr(totalStockValue)})'),
                          const Divider(height: 16, color: Color(0xFFE2E8F0)),
                          _pngRow('Cash Sales', formatInr(cashSales), color: const Color(0xFF059669)),
                          _pngRow('UPI / GPay (Bank)', formatInr(upiSales), color: const Color(0xFF0284C7)),
                          _pngRow('Card Sales (Bank)', formatInr(cardSales), color: const Color(0xFF4F46E5)),
                          if (creditSales > 0) _pngRow('Credit / Khata Bills', formatInr(creditSales), color: const Color(0xFFD97706)),
                          if (otherSales > 0) _pngRow('Other Sales', formatInr(otherSales)),
                          if (totalLess > 0) _pngRow('Total Less / Discount', '-${formatInr(totalLess)}', color: const Color(0xFFE11D48)),
                          const SizedBox(height: 6),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                            decoration: BoxDecoration(color: const Color(0xFFFEF3C7), borderRadius: BorderRadius.circular(10)),
                            child: _pngRow('TOTAL DAY SALES', formatInr(totalDaySales), color: const Color(0xFF92400E), bold: true),
                          ),
                          const Divider(height: 16, color: Color(0xFFE2E8F0)),
                          _pngRow('Opening Drawer Cash', formatInr(openCash)),
                          _pngRow('+ Today Khata Collected', formatInr(khataPaid), color: const Color(0xFF9A6B22)),
                          _pngRow('- Shop Expenses', '-${formatInr(expense)}', color: const Color(0xFFE11D48)),
                          _pngRow('Total Received (Cash + Bank)', formatInr(totalReceivedToday), bold: true),
                          const SizedBox(height: 6),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                            decoration: BoxDecoration(color: const Color(0xFFECFDF5), borderRadius: BorderRadius.circular(10)),
                            child: _pngRow('NET CASH IN DRAWER', formatInr(netDrawer), color: const Color(0xFF059669), bold: true),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 12),
                Row(
                  children: [
                    Expanded(
                      child: ElevatedButton.icon(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: AppTheme.gold,
                          foregroundColor: Colors.black,
                          padding: const EdgeInsets.symmetric(vertical: 13),
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                        ),
                        onPressed: exporting ? null : () => exportDayBookPng(true),
                        icon: exporting
                            ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.black))
                            : const Icon(Icons.share_rounded, size: 18),
                        label: const Text('Share Closing PNG', style: TextStyle(fontWeight: FontWeight.w900)),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: ElevatedButton.icon(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: AppTheme.green,
                          foregroundColor: Colors.black,
                          padding: const EdgeInsets.symmetric(vertical: 13),
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                        ),
                        onPressed: exporting ? null : () => exportDayBookPng(false),
                        icon: const Icon(Icons.download_rounded, size: 18),
                        label: const Text('Save PNG', style: TextStyle(fontWeight: FontWeight.w900)),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    ),
  );
}

Widget _pngRow(String label, String val, {Color? color, bool bold = false}) {
  return Padding(
    padding: const EdgeInsets.symmetric(vertical: 2.5),
    child: Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(label, style: TextStyle(fontWeight: bold ? FontWeight.w800 : FontWeight.w500, fontSize: bold ? 12.5 : 11.5, color: const Color(0xFF334155))),
        Text(val, style: TextStyle(fontWeight: FontWeight.w900, fontSize: bold ? 14 : 12, color: color ?? const Color(0xFF0F172A))),
      ],
    ),
  );
}

Widget _row(String label, String val, {Color? color, bool bold = false}) {
  return Padding(
    padding: const EdgeInsets.symmetric(vertical: 3),
    child: Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(label, style: TextStyle(fontWeight: bold ? FontWeight.bold : FontWeight.normal, fontSize: bold ? 14 : 12)),
        Text(val, style: TextStyle(fontWeight: FontWeight.bold, fontSize: bold ? 16 : 13, color: color)),
      ],
    ),
  );
}

void showKhataSheet(BuildContext context, PosStore s) {
  if (s.isGuest) { ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Sign in to manage Khata Ledger!'))); return; }
  final nameCtrl = TextEditingController();
  final phoneCtrl = TextEditingController();
  final amtCtrl = TextEditingController();
  final noteCtrl = TextEditingController();

  showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    builder: (ctx) => Padding(
      padding: EdgeInsets.only(left: 16, right: 16, top: 16, bottom: MediaQuery.of(ctx).viewInsets.bottom + 16),
      child: SizedBox(
        height: MediaQuery.of(ctx).size.height * 0.78,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Customer Credit (Khata) Ledger', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: AppTheme.gold)),
            const SizedBox(height: 10),
            Row(
              children: [
                Expanded(child: TextField(controller: nameCtrl, decoration: const InputDecoration(labelText: 'Name *'))),
                const SizedBox(width: 8),
                Expanded(child: TextField(controller: phoneCtrl, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: 'Mobile *'))),
              ],
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                Expanded(child: TextField(controller: amtCtrl, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Due ₹ *'))),
                const SizedBox(width: 8),
                Expanded(child: TextField(controller: noteCtrl, decoration: const InputDecoration(labelText: 'Dress Note'))),
                const SizedBox(width: 8),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(backgroundColor: AppTheme.gold, foregroundColor: Colors.black),
                  onPressed: () async {
                    final amt = double.tryParse(amtCtrl.text) ?? 0;
                    if (nameCtrl.text.trim().isEmpty || amt <= 0) return;
                    await s.addSimpleDoc('khata', {
                      'id': makeId('KHT'),
                      'customerName': nameCtrl.text.trim(),
                      'phone': phoneCtrl.text.trim(),
                      'amount': amt,
                      'note': noteCtrl.text.trim(),
                      'status': 'Pending',
                      'date': getLocalDateString(),
                      'createdAt': DateTime.now().toIso8601String(),
                    });
                    if (ctx.mounted) Navigator.pop(ctx);
                  },
                  child: const Text('+ Add'),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Expanded(
              child: ListView.builder(
                itemCount: s.khata.length,
                itemBuilder: (_, i) {
                  final k = s.khata[i];
                  final isPaid = k['status'] == 'Paid';
                  final amt = (k['amount'] as num? ?? 0).toDouble();
                  return Card(
                    child: ListTile(
                      title: Text('${k['customerName']} (${k['phone'] ?? ''})', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
                      subtitle: Text('${k['note'] ?? ''} • ${k['date'] ?? ''}', style: const TextStyle(fontSize: 11)),
                      trailing: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text(
                            formatInr(amt),
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                              color: isPaid ? AppTheme.green : Colors.redAccent,
                              decoration: isPaid ? TextDecoration.lineThrough : null,
                            ),
                          ),
                          IconButton(
                            icon: const Icon(Icons.image_outlined, color: AppTheme.green, size: 19),
                            tooltip: 'Share Khata PNG',
                            onPressed: () => showBrandedPngSlipSheet(
                              ctx,
                              title: 'Credit (Khata) Statement',
                              subtitle: 'Date: ${k['date'] ?? getLocalDateString()}',
                              fileNamePrefix: 'UNIVO_KHATA_${k['customerName'] ?? 'CUST'}',
                              rows: [
                                MapEntry('Customer', '${k['customerName'] ?? ''}'),
                                if ((k['phone'] ?? '').toString().isNotEmpty) MapEntry('Mobile', '${k['phone']}'),
                                MapEntry('Details', '${k['note'] ?? 'Dress Bill'}'),
                                MapEntry('Status', isPaid ? 'PAID' : 'PENDING'),
                              ],
                              highlightLabel: isPaid ? 'AMOUNT PAID' : 'BALANCE DUE',
                              highlightValue: formatInr(amt),
                              footerText: 'Please pay at shop or via UPI / GPay. Thank you!',
                            ),
                          ),
                          if (!isPaid)
                            TextButton(
                              onPressed: () async {
                                final updated = Map<String, dynamic>.from(k);
                                updated['status'] = 'Paid';
                                await s.addSimpleDoc('khata', updated);
                                if (ctx.mounted) Navigator.pop(ctx);
                              },
                              child: const Text('Paid', style: TextStyle(color: AppTheme.gold, fontWeight: FontWeight.bold)),
                            ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    ),
  );
}

void showAlterationsSheet(BuildContext context, PosStore s) {
  if (s.isGuest) { ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Sign in to manage Alterations!'))); return; }
  final nameCtrl = TextEditingController();
  final phoneCtrl = TextEditingController();
  final notesCtrl = TextEditingController();
  final feeCtrl = TextEditingController(text: '50');

  showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    builder: (ctx) => Padding(
      padding: EdgeInsets.only(left: 16, right: 16, top: 16, bottom: MediaQuery.of(ctx).viewInsets.bottom + 16),
      child: SizedBox(
        height: MediaQuery.of(ctx).size.height * 0.78,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Tailoring & Alteration Job-Slips', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.indigoAccent)),
            const SizedBox(height: 10),
            Row(
              children: [
                Expanded(child: TextField(controller: nameCtrl, decoration: const InputDecoration(labelText: 'Customer *'))),
                const SizedBox(width: 8),
                Expanded(child: TextField(controller: phoneCtrl, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: 'Mobile *'))),
              ],
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                Expanded(flex: 2, child: TextField(controller: notesCtrl, decoration: const InputDecoration(labelText: 'Alteration Note (e.g. Pant 38") *'))),
                const SizedBox(width: 8),
                Expanded(child: TextField(controller: feeCtrl, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Fee ₹'))),
              ],
            ),
            const SizedBox(height: 8),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(backgroundColor: Colors.indigoAccent, foregroundColor: Colors.white),
                onPressed: () async {
                  if (nameCtrl.text.trim().isEmpty || notesCtrl.text.trim().isEmpty) return;
                  await s.addSimpleDoc('alterations', {
                    'id': makeId('ALT'),
                    'customerName': nameCtrl.text.trim(),
                    'phone': phoneCtrl.text.trim(),
                    'notes': notesCtrl.text.trim(),
                    'fee': double.tryParse(feeCtrl.text) ?? 0,
                    'status': 'Pending',
                    'date': getLocalDateString(),
                    'createdAt': DateTime.now().toIso8601String(),
                  });
                  if (ctx.mounted) Navigator.pop(ctx);
                },
                child: const Text('+ Create Job Slip'),
              ),
            ),
            const SizedBox(height: 10),
            Expanded(
              child: ListView.builder(
                itemCount: s.alterations.length,
                itemBuilder: (_, i) {
                  final a = s.alterations[i];
                  final st = (a['status'] ?? 'Pending').toString();
                  return Card(
                    child: ListTile(
                      title: Text('${a['customerName']} (${a['phone'] ?? ''})', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
                      subtitle: Text('${a['notes'] ?? ''} • Fee: ₹${a['fee'] ?? 0}', style: const TextStyle(fontSize: 11)),
                      trailing: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          IconButton(
                            icon: const Icon(Icons.image_outlined, color: AppTheme.green, size: 19),
                            tooltip: 'Share Job Slip PNG',
                            onPressed: () => showBrandedPngSlipSheet(
                              ctx,
                              title: 'Tailoring Job Slip',
                              subtitle: 'Date: ${a['date'] ?? getLocalDateString()}',
                              fileNamePrefix: 'UNIVO_ALTERATION_${a['customerName'] ?? 'CUST'}',
                              rows: [
                                MapEntry('Customer', '${a['customerName'] ?? ''}'),
                                if ((a['phone'] ?? '').toString().isNotEmpty) MapEntry('Mobile', '${a['phone']}'),
                                MapEntry('Alteration Notes', '${a['notes'] ?? ''}'),
                                MapEntry('Status', st),
                              ],
                              highlightLabel: 'TAILORING FEE',
                              highlightValue: '₹${a['fee'] ?? 0}',
                              footerText: 'Please bring this slip when collecting your garment.',
                            ),
                          ),
                          ElevatedButton(
                            onPressed: () async {
                              final next = st == 'Pending' ? 'Ready' : (st == 'Ready' ? 'Delivered' : 'Pending');
                              final updated = Map<String, dynamic>.from(a);
                              updated['status'] = next;
                              await s.addSimpleDoc('alterations', updated);
                              if (ctx.mounted) Navigator.pop(ctx);
                            },
                            child: Text(st, style: const TextStyle(fontSize: 11)),
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    ),
  );
}

void showSuppliersSheet(BuildContext context, PosStore s) {
  if (!s.isAdmin) { ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Only Owner or Admin can access Wholesale Suppliers!'))); return; }
  final nameCtrl = TextEditingController();
  final cityCtrl = TextEditingController();
  final billCtrl = TextEditingController();
  final amtCtrl = TextEditingController();

  showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    builder: (ctx) => Padding(
      padding: EdgeInsets.only(left: 16, right: 16, top: 16, bottom: MediaQuery.of(ctx).viewInsets.bottom + 16),
      child: SizedBox(
        height: MediaQuery.of(ctx).size.height * 0.78,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Wholesale Supplier Purchase Bills', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.lightBlueAccent)),
            const SizedBox(height: 10),
            Row(
              children: [
                Expanded(child: TextField(controller: nameCtrl, decoration: const InputDecoration(labelText: 'Mill / Supplier *'))),
                const SizedBox(width: 8),
                Expanded(child: TextField(controller: cityCtrl, decoration: const InputDecoration(labelText: 'City (Erode/Surat)'))),
              ],
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                Expanded(child: TextField(controller: billCtrl, decoration: const InputDecoration(labelText: 'Invoice No *'))),
                const SizedBox(width: 8),
                Expanded(child: TextField(controller: amtCtrl, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Amount ₹ *'))),
              ],
            ),
            const SizedBox(height: 8),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(backgroundColor: Colors.lightBlueAccent, foregroundColor: Colors.black),
                onPressed: () async {
                  final amt = double.tryParse(amtCtrl.text) ?? 0;
                  if (nameCtrl.text.trim().isEmpty || amt <= 0) return;
                  await s.addSimpleDoc('suppliers', {
                    'id': makeId('SUP'),
                    'name': nameCtrl.text.trim(),
                    'city': cityCtrl.text.trim(),
                    'billNo': billCtrl.text.trim(),
                    'amount': amt,
                    'status': 'Pending',
                    'date': getLocalDateString(),
                    'createdAt': DateTime.now().toIso8601String(),
                  });
                  if (ctx.mounted) Navigator.pop(ctx);
                },
                child: const Text('+ Save Supplier Bill', style: TextStyle(fontWeight: FontWeight.bold)),
              ),
            ),
            const SizedBox(height: 10),
            Expanded(
              child: ListView.builder(
                itemCount: s.suppliers.length,
                itemBuilder: (_, i) {
                  final sup = s.suppliers[i];
                  final isPaid = sup['status'] == 'Paid';
                  return Card(
                    child: ListTile(
                      title: Text('${sup['name']} (${sup['city'] ?? ''})', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
                      subtitle: Text('Bill #${sup['billNo'] ?? ''} • ${sup['date'] ?? ''}', style: const TextStyle(fontSize: 11)),
                      trailing: TextButton(
                        onPressed: () async {
                          final updated = Map<String, dynamic>.from(sup);
                          updated['status'] = isPaid ? 'Pending' : 'Paid';
                          await s.addSimpleDoc('suppliers', updated);
                          if (ctx.mounted) Navigator.pop(ctx);
                        },
                        child: Text(
                          '${formatInr((sup['amount'] as num? ?? 0).toDouble())} (${sup['status']})',
                          style: TextStyle(color: isPaid ? AppTheme.green : AppTheme.gold, fontWeight: FontWeight.bold),
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    ),
  );
}

void showGodownTransferSheet(BuildContext context, PosStore s) {
  if (s.isGuest) { ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Sign in to transfer stock!'))); return; }
  if (s.stock.isEmpty) return;
  StockItem selected = s.stock.first;
  String toLoc = 'Main Shop';

  showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    builder: (ctx) => StatefulBuilder(
      builder: (ctx, setSt) => Padding(
        padding: EdgeInsets.only(left: 16, right: 16, top: 16, bottom: MediaQuery.of(ctx).viewInsets.bottom + 16),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Godown ↔ Shop Stock Transfer', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: AppTheme.gold)),
            const SizedBox(height: 12),
            DropdownButtonFormField<String>(
              initialValue: selected.id,
              isExpanded: true,
              decoration: const InputDecoration(labelText: 'Select Stock Item'),
              items: s.stock.map((i) => DropdownMenuItem(value: i.id, child: Text('${i.name} [${i.location}] (${i.qty} pcs)'))).toList(),
              onChanged: (id) {
                if (id != null) setSt(() => selected = s.stock.firstWhere((e) => e.id == id));
              },
            ),
            const SizedBox(height: 10),
            DropdownButtonFormField<String>(
              initialValue: toLoc,
              decoration: const InputDecoration(labelText: 'Move To Location'),
              items: kLocations.map((l) => DropdownMenuItem(value: l, child: Text(l))).toList(),
              onChanged: (v) {
                if (v != null) setSt(() => toLoc = v);
              },
            ),
            const SizedBox(height: 14),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(backgroundColor: AppTheme.gold, foregroundColor: Colors.black, padding: const EdgeInsets.symmetric(vertical: 13)),
                onPressed: () async {
                  final updated = StockItem(
                    id: selected.id,
                    name: selected.name,
                    category: selected.category,
                    colour: selected.colour,
                    colourName: selected.colourName,
                    location: toLoc,
                    hsnCode: selected.hsnCode,
                    sizes: selected.sizes,
                    qty: selected.qty,
                    costPrice: selected.costPrice,
                    sellPrice: selected.sellPrice,
                    addedBy: selected.addedBy,
                    date: selected.date,
                    createdAt: selected.createdAt,
                  );
                  await s.saveStock(updated);
                  if (ctx.mounted) Navigator.pop(ctx);
                },
                child: const Text('Confirm Location Transfer', style: TextStyle(fontWeight: FontWeight.bold)),
              ),
            ),
          ],
        ),
      ),
    ),
  );
}

void showVipLoyaltySheet(BuildContext context, PosStore s) {
  showModalBottomSheet(
    context: context,
    builder: (ctx) => Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('VIP Customer Loyalty Club (1 Pt / ₹100)', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.pinkAccent)),
          const SizedBox(height: 10),
          Expanded(
            child: s.customers.isEmpty
                ? const Center(child: Text('Enter customer mobile numbers during billing to earn VIP points!'))
                : ListView.builder(
                    itemCount: s.customers.length,
                    itemBuilder: (_, i) {
                      final c = s.customers[i];
                      return Card(
                        child: ListTile(
                          leading: const CircleAvatar(backgroundColor: Colors.pinkAccent, child: Icon(Icons.star, color: Colors.white)),
                          title: Text('${c['name'] ?? 'VIP Customer'}', style: const TextStyle(fontWeight: FontWeight.bold)),
                          subtitle: Text('${c['phone'] ?? ''} • Spent: ${formatInr((c['totalSpent'] as num? ?? 0).toDouble())}'),
                          trailing: Text('${c['points'] ?? 0} Pts', style: const TextStyle(fontWeight: FontWeight.w800, color: Colors.pinkAccent, fontSize: 14)),
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
    ),
  );
}

String _tallyBaseName(StockItem item) {
  final n = item.name.trim();
  final c = item.colourName.trim();
  if (c.isNotEmpty && n.toLowerCase().endsWith(' - ${c.toLowerCase()}')) {
    return n.substring(0, n.length - (' - $c').length).trim();
  }
  return n;
}

void showNightTallySheet(BuildContext context, PosStore s) {
  if (s.isGuest) {
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Sign in to run Stock Tally!')));
    return;
  }
  showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    builder: (ctx) => AnimatedBuilder(
      animation: s,
      builder: (_, __) {
        // Group all colours under the same design name (e.g. Polo Fit: Brown 7 pcs + White 7 pcs = Total 14 pcs)
        final grouped = <String, List<StockItem>>{};
        for (final item in s.stock.where((x) => x.qty > 0)) {
          final key = _tallyBaseName(item);
          grouped.putIfAbsent(key, () => []).add(item);
        }
        final groupKeys = grouped.keys.toList();
        final wholeTotalPcs = s.stock.fold<int>(0, (a, b) => a + b.qty);
        final wholeTotalVal = s.stock.fold<double>(0, (a, b) => a + (b.sellPrice * b.qty));

        return Padding(
          padding: const EdgeInsets.fromLTRB(16, 16, 16, 20),
          child: SizedBox(
            height: MediaQuery.of(ctx).size.height * 0.84,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text('Physical Stock Tally', style: TextStyle(fontSize: 16.5, fontWeight: FontWeight.w800, color: AppTheme.gold)),
                    Text('${groupKeys.length} styles', style: const TextStyle(fontSize: 11.5, fontWeight: FontWeight.w700, color: Colors.grey)),
                  ],
                ),
                const SizedBox(height: 10),
                Expanded(
                  child: groupKeys.isEmpty
                      ? const Center(child: Text('No stock items to tally.'))
                      : ListView.builder(
                          itemCount: groupKeys.length,
                          itemBuilder: (_, i) {
                            final baseName = groupKeys[i];
                            final variants = grouped[baseName]!;
                            final groupTotal = variants.fold<int>(0, (a, b) => a + b.qty);
                            final colourBreakdown = variants.length > 1
                                ? '${variants.map((v) => '${v.colourName.isNotEmpty ? v.colourName : 'Std'} ${v.qty} pcs').join(' + ')} = Total $groupTotal pcs'
                                : '${variants.first.colourName.isNotEmpty ? '${variants.first.colourName} • ' : ''}Total $groupTotal pcs • ${variants.first.sizes.entries.map((e) => '${e.key}:${e.value}').join(' | ')}';
                            final physCtrl = TextEditingController(text: '$groupTotal');

                            return Card(
                              margin: const EdgeInsets.only(bottom: 8),
                              child: Padding(
                                padding: const EdgeInsets.all(12),
                                child: Row(
                                  children: [
                                    Expanded(
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Text(baseName, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 13.5)),
                                          const SizedBox(height: 3),
                                          Text(colourBreakdown, style: const TextStyle(fontSize: 11, color: Colors.grey, fontWeight: FontWeight.w600)),
                                        ],
                                      ),
                                    ),
                                    const SizedBox(width: 8),
                                    SizedBox(
                                      width: 58,
                                      child: TextField(controller: physCtrl, keyboardType: TextInputType.number, textAlign: TextAlign.center),
                                    ),
                                    const SizedBox(width: 8),
                                    ElevatedButton(
                                      style: ElevatedButton.styleFrom(backgroundColor: AppTheme.gold, foregroundColor: Colors.black, padding: const EdgeInsets.symmetric(horizontal: 12)),
                                      onPressed: () {
                                        final phys = int.tryParse(physCtrl.text) ?? groupTotal;
                                        if (phys < groupTotal) {
                                          Navigator.pop(ctx);
                                          showReportMissingSheet(context, s, preItem: variants.first, preQty: groupTotal - phys);
                                        } else {
                                          ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$baseName: Count OK ($phys pcs)!')));
                                        }
                                      },
                                      child: const Text('Check', style: TextStyle(fontWeight: FontWeight.w800)),
                                    ),
                                  ],
                                ),
                              ),
                            );
                          },
                        ),
                ),
                const SizedBox(height: 10),
                // Whole Grand Total Stock Footer Bar
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                  decoration: BoxDecoration(
                    color: AppTheme.gold.withAlpha(28),
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: AppTheme.gold.withAlpha(110)),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text('TOTAL STOCK (ALL ITEMS)', style: TextStyle(fontSize: 10, fontWeight: FontWeight.w800, color: AppTheme.gold)),
                          Text('${groupKeys.length} Styles  •  ${s.stock.length} Colour Variants', style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w600)),
                        ],
                      ),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          Text('$wholeTotalPcs pcs', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w900, color: AppTheme.green)),
                          Text(formatInr(wholeTotalVal), style: const TextStyle(fontSize: 11.5, fontWeight: FontWeight.w800, color: AppTheme.gold)),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        );
      },
    ),
  );
}

void showReportMissingSheet(BuildContext context, PosStore s, {StockItem? preItem, int preQty = 1}) {
  if (s.isGuest) {
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Sign in to report missing stock!')));
    return;
  }
  if (s.stock.isEmpty) {
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Add stock items first!')));
    return;
  }
  StockItem selected = preItem ?? s.stock.first;
  String selectedSize = selected.sizes.keys.first;
  final qtyCtrl = TextEditingController(text: '$preQty');
  final reasonCtrl = TextEditingController(text: 'Missing during night rack tally');

  showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    builder: (ctx) => StatefulBuilder(
      builder: (ctx, setSt) => Padding(
        padding: EdgeInsets.only(left: 16, right: 16, top: 16, bottom: MediaQuery.of(ctx).viewInsets.bottom + 20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Report Missing / Lost Piece', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: AppTheme.rose)),
            const SizedBox(height: 10),
            DropdownButtonFormField<String>(
              initialValue: selected.id,
              isExpanded: true,
              decoration: const InputDecoration(labelText: 'Select Item'),
              items: s.stock.map((i) => DropdownMenuItem(value: i.id, child: Text('${i.name} (${i.qty} pcs)'))).toList(),
              onChanged: (id) {
                if (id != null) {
                  setSt(() {
                    selected = s.stock.firstWhere((e) => e.id == id);
                    selectedSize = selected.sizes.keys.first;
                  });
                }
              },
            ),
            const SizedBox(height: 8),
            DropdownButtonFormField<String>(
              initialValue: selectedSize,
              decoration: const InputDecoration(labelText: 'Missing Size'),
              items: selected.sizes.entries.map((e) => DropdownMenuItem(value: e.key, child: Text('${e.key} (${e.value} in stock)'))).toList(),
              onChanged: (v) {
                if (v != null) setSt(() => selectedSize = v);
              },
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                Expanded(child: TextField(controller: qtyCtrl, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Missing Qty'))),
                const SizedBox(width: 8),
                Expanded(flex: 2, child: TextField(controller: reasonCtrl, decoration: const InputDecoration(labelText: 'Reason'))),
              ],
            ),
            const SizedBox(height: 14),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(backgroundColor: AppTheme.rose, foregroundColor: Colors.white, padding: const EdgeInsets.symmetric(vertical: 14)),
                onPressed: () async {
                  final q = int.tryParse(qtyCtrl.text) ?? 1;
                  if (q <= 0) return;
                  await s.recordMissing(item: selected, size: selectedSize, qty: q, reason: reasonCtrl.text);
                  if (ctx.mounted) Navigator.pop(ctx);
                  if (context.mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Missing piece logged & deducted from stock!')));
                  }
                },
                child: const Text('Save Missing Log', style: TextStyle(fontWeight: FontWeight.bold)),
              ),
            ),
          ],
        ),
      ),
    ),
  );
}
