import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';
import 'package:url_launcher/url_launcher.dart';
import '../core/app_theme.dart';
import '../core/constants.dart';
import '../services/pos_store.dart';

class AppUpdateInfo {
  final String versionName;
  final int buildNumber;
  final String downloadUrl;
  final String releaseNotes;
  final bool forceUpdate;
  final String source;

  AppUpdateInfo({
    required this.versionName,
    required this.buildNumber,
    required this.downloadUrl,
    required this.releaseNotes,
    required this.forceUpdate,
    required this.source,
  });
}

bool _isNewerVersion(String remoteVer, int remoteBuild) {
  if (remoteBuild > kAppBuildNumber) return true;
  final rParts = remoteVer.replaceAll(RegExp(r'[^0-9.]'), '').split('.');
  final lParts = kAppVersionName.replaceAll(RegExp(r'[^0-9.]'), '').split('.');
  for (int i = 0; i < 3; i++) {
    final r = i < rParts.length ? (int.tryParse(rParts[i]) ?? 0) : 0;
    final l = i < lParts.length ? (int.tryParse(lParts[i]) ?? 0) : 0;
    if (r > l) return true;
    if (r < l) return false;
  }
  return false;
}

Future<void> cleanOldApkCache() async {
  try {
    final dir = await getTemporaryDirectory();
    if (await dir.exists()) {
      for (final f in dir.listSync()) {
        if (f is File && f.path.toLowerCase().endsWith('.apk')) {
          await f.delete();
        }
      }
    }
  } catch (_) {}
}

Future<AppUpdateInfo?> checkForAppUpdate(PosStore s) async {
  // 1. Check Firestore Owner-Pushed Update first
  final cfg = s.remoteUpdateConfig;
  if (cfg.isNotEmpty) {
    final ver = (cfg['versionName'] ?? '').toString().trim();
    final build = (cfg['buildNumber'] as num? ?? 0).toInt();
    final url = (cfg['downloadUrl'] ?? '').toString().trim();
    final notes = (cfg['releaseNotes'] ?? 'New improvements & bug fixes.').toString();
    final force = cfg['forceUpdate'] == true;
    if (url.isNotEmpty && _isNewerVersion(ver, build)) {
      return AppUpdateInfo(
        versionName: ver.isNotEmpty ? ver : 'v$build.0',
        buildNumber: build,
        downloadUrl: url,
        releaseNotes: notes,
        forceUpdate: force,
        source: 'Owner Push',
      );
    }
  }

  // 2. Check Public GitHub Releases API automatically
  try {
    final client = HttpClient()..connectionTimeout = const Duration(seconds: 6);
    final uri = Uri.parse('https://api.github.com/repos/$kGithubOwner/$kGithubRepo/releases/latest');
    final req = await client.getUrl(uri);
    req.headers.set('Accept', 'application/vnd.github+json');
    req.headers.set('User-Agent', 'UNIVO-WEAR-POS/$kAppVersionName');
    final res = await req.close().timeout(const Duration(seconds: 8));
    if (res.statusCode == 200) {
      final raw = await res.transform(utf8.decoder).join();
      final data = jsonDecode(raw) as Map<String, dynamic>;
      final tag = (data['tag_name'] ?? '').toString().trim();
      final body = (data['body'] ?? 'Latest UNIVO WEAR update is ready to install.').toString().trim();
      final htmlUrl = (data['html_url'] ?? '').toString().trim();

      String apkUrl = htmlUrl;
      final assets = data['assets'] as List<dynamic>? ?? [];
      for (final a in assets) {
        final m = a as Map<String, dynamic>;
        final name = (m['name'] ?? '').toString().toLowerCase();
        if (name.endsWith('.apk')) {
          apkUrl = (m['browser_download_url'] ?? htmlUrl).toString();
          break;
        }
      }

      // Parse tag like "v27.0.0+27" or "v27.0.0"
      final cleanTag = tag.startsWith('v') || tag.startsWith('V') ? tag.substring(1) : tag;
      final parts = cleanTag.split('+');
      final verName = parts[0];
      final buildNum = parts.length > 1 ? (int.tryParse(parts[1]) ?? 0) : 0;

      if (apkUrl.isNotEmpty && _isNewerVersion(verName, buildNum)) {
        return AppUpdateInfo(
          versionName: verName,
          buildNumber: buildNum,
          downloadUrl: apkUrl,
          releaseNotes: body.isNotEmpty ? body : 'New features, UI polish & stability fixes.',
          forceUpdate: false,
          source: 'GitHub Releases',
        );
      }
    }
    client.close();
  } catch (_) {}

  return null;
}

Future<void> showUpdateAvailableSheet(BuildContext context, PosStore s, AppUpdateInfo info) async {
  if (!context.mounted) return;
  final accent = s.isDark ? AppTheme.gold : AppTheme.goldLightMode;
  final muted = s.isDark ? const Color(0xFF94A3B8) : const Color(0xFF64748B);
  final surface = s.isDark ? AppTheme.darkSurface : AppTheme.lightSurface;
  final border = s.isDark ? AppTheme.darkBorder : AppTheme.lightBorder;

  await showModalBottomSheet(
    context: context,
    isDismissible: !info.forceUpdate,
    enableDrag: !info.forceUpdate,
    backgroundColor: s.isDark ? AppTheme.darkCard : AppTheme.lightCard,
    shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(26))),
    builder: (ctx) => Padding(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 26),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Center(
            child: Container(
              width: 42,
              height: 4,
              decoration: BoxDecoration(color: muted.withAlpha(90), borderRadius: BorderRadius.circular(4)),
            ),
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              Container(
                width: 46,
                height: 46,
                decoration: BoxDecoration(color: accent.withAlpha(32), borderRadius: BorderRadius.circular(14)),
                child: Icon(Icons.system_update_rounded, color: accent, size: 24),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('New Update Available!', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w900)),
                    Text('UNIVO WEAR • ${info.source}', style: TextStyle(fontSize: 11.5, color: muted)),
                  ],
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(color: AppTheme.green.withAlpha(28), borderRadius: BorderRadius.circular(12)),
                child: Text(
                  'v$kAppVersionName → v${info.versionName}',
                  style: const TextStyle(color: AppTheme.green, fontWeight: FontWeight.w800, fontSize: 11),
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          Wrap(
            spacing: 6,
            runSpacing: 6,
            children: [
              _badgeChip('Zero Data Loss', AppTheme.green),
              _badgeChip('In-Place Update', accent),
              _badgeChip('Login Stays Safe', Colors.lightBlueAccent),
            ],
          ),
          const SizedBox(height: 14),
          Container(
            width: double.infinity,
            constraints: const BoxConstraints(maxHeight: 130),
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: surface,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: border),
            ),
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text("What's New", style: TextStyle(fontSize: 11, fontWeight: FontWeight.w800, color: accent)),
                  const SizedBox(height: 4),
                  Text(info.releaseNotes, style: const TextStyle(fontSize: 12.5, height: 1.4)),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          Text(
            'Tip: Download ஆனதும் "Update" தட்டுங்க — பழைய டேட்டா & லாகின் எதுவும் போகாது.',
            style: TextStyle(fontSize: 11, color: muted),
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              if (!info.forceUpdate) ...[
                Expanded(
                  child: OutlinedButton(
                    style: OutlinedButton.styleFrom(
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                    ),
                    onPressed: () => Navigator.pop(ctx),
                    child: const Text('Later', style: TextStyle(fontWeight: FontWeight.w700)),
                  ),
                ),
                const SizedBox(width: 10),
              ],
              Expanded(
                flex: 2,
                child: ElevatedButton.icon(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: accent,
                    foregroundColor: const Color(0xFF0A0B0E),
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                  ),
                  icon: const Icon(Icons.download_rounded, size: 18),
                  label: const Text('Download & Update Now', style: TextStyle(fontWeight: FontWeight.w900)),
                  onPressed: () async {
                    final uri = Uri.parse(info.downloadUrl);
                    if (await canLaunchUrl(uri)) {
                      await launchUrl(uri, mode: LaunchMode.externalApplication);
                    }
                    if (!info.forceUpdate && ctx.mounted) Navigator.pop(ctx);
                  },
                ),
              ),
            ],
          ),
        ],
      ),
    ),
  );
}

Widget _badgeChip(String label, Color color) => Container(
      padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4),
      decoration: BoxDecoration(color: color.withAlpha(24), borderRadius: BorderRadius.circular(10)),
      child: Text(label, style: TextStyle(fontSize: 10, fontWeight: FontWeight.w800, color: color)),
    );

void showManualPushUpdateDialog(BuildContext context, PosStore s) {
  final verCtrl = TextEditingController(text: (s.remoteUpdateConfig['versionName'] ?? '27.0.0').toString());
  final buildCtrl = TextEditingController(text: (s.remoteUpdateConfig['buildNumber'] ?? (kAppBuildNumber + 1)).toString());
  final urlCtrl = TextEditingController(
    text: (s.remoteUpdateConfig['downloadUrl'] ??
            'https://github.com/$kGithubOwner/$kGithubRepo/releases/latest/download/UNIVO-WEAR-Native-POS.apk')
        .toString(),
  );
  final notesCtrl = TextEditingController(text: (s.remoteUpdateConfig['releaseNotes'] ?? 'New features & performance improvements.').toString());
  bool force = s.remoteUpdateConfig['forceUpdate'] == true;

  showDialog(
    context: context,
    builder: (dCtx) => StatefulBuilder(
      builder: (dCtx, setSt) => AlertDialog(
        title: const Text('Push App Update to All Phones', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Row(
                children: [
                  Expanded(child: TextField(controller: verCtrl, decoration: const InputDecoration(labelText: 'Version (e.g. 27.0.0)'))),
                  const SizedBox(width: 8),
                  Expanded(child: TextField(controller: buildCtrl, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Build #'))),
                ],
              ),
              const SizedBox(height: 10),
              TextField(controller: urlCtrl, decoration: const InputDecoration(labelText: 'Direct APK Download URL')),
              const SizedBox(height: 10),
              TextField(controller: notesCtrl, maxLines: 2, decoration: const InputDecoration(labelText: "What's New Notes")),
              const SizedBox(height: 6),
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: const Text('Force Update (Require Update)', style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w700)),
                value: force,
                onChanged: (v) => setSt(() => force = v),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dCtx), child: const Text('Cancel')),
          ElevatedButton(
            onPressed: () async {
              await s.saveRemoteUpdateConfig(
                versionName: verCtrl.text.trim(),
                buildNumber: int.tryParse(buildCtrl.text.trim()) ?? (kAppBuildNumber + 1),
                downloadUrl: urlCtrl.text.trim(),
                releaseNotes: notesCtrl.text.trim(),
                forceUpdate: force,
              );
              if (dCtx.mounted) Navigator.pop(dCtx);
              if (context.mounted) {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Update alert pushed to all Owner, Admin & Staff devices!')),
                );
              }
            },
            child: const Text('Push Update'),
          ),
        ],
      ),
    ),
  );
}
