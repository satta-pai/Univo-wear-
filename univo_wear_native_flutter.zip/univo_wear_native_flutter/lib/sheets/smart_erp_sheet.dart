import 'dart:io';
import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:path_provider/path_provider.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:share_plus/share_plus.dart';
import '../core/app_theme.dart';
import '../core/constants.dart';
import '../models/pos_models.dart';
import '../services/pos_store.dart';

String _erpRs(double v) => 'Rs. ${NumberFormat('#,##0', 'en_IN').format(v.round())}';

Future<void> _exportReorderPoPdf(BuildContext context, PosStore s, List<Map<String, dynamic>> lowRows) async {
  if (kIsWeb) {
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('PO PDF export is available on Android/Desktop app.')));
    return;
  }
  try {
    final doc = pw.Document();
    final nowStr = DateFormat('dd MMM yyyy, hh:mm a').format(DateTime.now());
    final totalOrderPcs = lowRows.fold<int>(0, (a, b) => a + (b['orderQty'] as int));
    final estCost = lowRows.fold<double>(0, (a, b) => a + ((b['orderQty'] as int) * (b['cost'] as double)));

    doc.addPage(
      pw.MultiPage(
        pageFormat: PdfPageFormat.a4,
        margin: const pw.EdgeInsets.all(22),
        build: (ctx) => [
          pw.Row(
            mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
            children: [
              pw.Column(
                crossAxisAlignment: pw.CrossAxisAlignment.start,
                children: [
                  pw.Text(s.shopName.toUpperCase(), style: pw.TextStyle(fontSize: 18, fontWeight: pw.FontWeight.bold)),
                  pw.Text('SUPPLIER PURCHASE ORDER (AUTO-REORDER)', style: const pw.TextStyle(fontSize: 10, color: PdfColors.grey700)),
                ],
              ),
              pw.Column(
                crossAxisAlignment: pw.CrossAxisAlignment.end,
                children: [
                  pw.Text('Date: $nowStr', style: const pw.TextStyle(fontSize: 9)),
                  pw.Text('Total Reorder: $totalOrderPcs pcs', style: pw.TextStyle(fontSize: 10, fontWeight: pw.FontWeight.bold)),
                ],
              ),
            ],
          ),
          pw.SizedBox(height: 8),
          pw.Divider(color: PdfColors.grey400),
          pw.SizedBox(height: 8),
          pw.TableHelper.fromTextArray(
            headerStyle: pw.TextStyle(fontSize: 8.5, fontWeight: pw.FontWeight.bold, color: PdfColors.white),
            headerDecoration: const pw.BoxDecoration(color: PdfColors.grey900),
            cellStyle: const pw.TextStyle(fontSize: 8.5),
            oddRowDecoration: const pw.BoxDecoration(color: PdfColors.grey100),
            headers: const ['#', 'Garment Name', 'Category', 'Size', 'Left', 'Order Qty', 'Est. Cost'],
            data: List.generate(lowRows.length, (i) {
              final r = lowRows[i];
              return [
                '${i + 1}',
                '${r['name']}',
                '${r['category']}',
                '${r['size']}',
                '${r['left']}',
                '${r['orderQty']} pcs',
                _erpRs((r['orderQty'] as int) * (r['cost'] as double)),
              ];
            }),
          ),
          pw.SizedBox(height: 12),
          pw.Align(
            alignment: pw.Alignment.centerRight,
            child: pw.Text('ESTIMATED PO VALUE: ${_erpRs(estCost)}', style: pw.TextStyle(fontSize: 12, fontWeight: pw.FontWeight.bold)),
          ),
        ],
      ),
    );

    final bytes = await doc.save();
    final dir = await getTemporaryDirectory();
    final f = File('${dir.path}/UNIVO_PO_${DateFormat('yyyyMMdd').format(DateTime.now())}.pdf');
    await f.writeAsBytes(bytes, flush: true);
    await SharePlus.instance.share(
      ShareParams(files: [XFile(f.path)], text: '${s.shopName} Supplier Purchase Order ($totalOrderPcs pcs)'),
    );
  } catch (e) {
    if (context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('PO PDF error: $e')));
    }
  }
}

void showSmartErpSheet(BuildContext context, PosStore s) {
  final now = DateTime.now();

  // 1. Dead-Stock Aging (30 / 60 / 90+ days without a sale)
  final lastSoldByStock = <String, DateTime>{};
  for (final sale in s.sales) {
    final dt = DateTime.tryParse(sale.createdAt);
    if (dt == null) continue;
    final prev = lastSoldByStock[sale.stockId];
    if (prev == null || dt.isAfter(prev)) lastSoldByStock[sale.stockId] = dt;
    for (final c in sale.cartItems) {
      final p2 = lastSoldByStock[c.stockId];
      if (p2 == null || dt.isAfter(p2)) lastSoldByStock[c.stockId] = dt;
    }
  }

  final dead30 = <StockItem>[];
  final dead60 = <StockItem>[];
  final dead90 = <StockItem>[];
  double deadCapital = 0;

  for (final item in s.stock.where((x) => x.qty > 0)) {
    final refDate = lastSoldByStock[item.id] ?? DateTime.tryParse(item.createdAt) ?? now;
    final days = now.difference(refDate).inDays;
    if (days >= 90) {
      dead90.add(item);
      deadCapital += item.costPrice * item.qty;
    } else if (days >= 60) {
      dead60.add(item);
      deadCapital += item.costPrice * item.qty;
    } else if (days >= 30) {
      dead30.add(item);
      deadCapital += item.costPrice * item.qty;
    }
  }

  // 2. Low-Stock Reorder List (any size <= 2 pcs)
  final lowRows = <Map<String, dynamic>>[];
  for (final item in s.stock) {
    item.sizes.forEach((sz, cnt) {
      if (cnt <= 2) {
        lowRows.add({
          'name': item.name,
          'category': item.category,
          'size': sz,
          'left': cnt,
          'orderQty': cnt == 0 ? 10 : 6,
          'cost': item.costPrice,
        });
      }
    });
  }

  // 3. Peak-Hour Shopping Heatmap
  final slotBills = <String, int>{
    'Morning (9-12)': 0,
    'Afternoon (12-4)': 0,
    'Evening (4-7)': 0,
    'Night (7-10+)': 0,
  };
  final slotRev = <String, double>{
    'Morning (9-12)': 0,
    'Afternoon (12-4)': 0,
    'Evening (4-7)': 0,
    'Night (7-10+)': 0,
  };
  for (final sale in s.sales) {
    final dt = DateTime.tryParse(sale.createdAt);
    if (dt == null) continue;
    final h = dt.hour;
    final key = h < 12 ? 'Morning (9-12)' : (h < 16 ? 'Afternoon (12-4)' : (h < 19 ? 'Evening (4-7)' : 'Night (7-10+)'));
    slotBills[key] = (slotBills[key] ?? 0) + 1;
    slotRev[key] = (slotRev[key] ?? 0) + sale.totalSellPrice;
  }
  final maxSlotRev = slotRev.values.fold<double>(1, (a, b) => b > a ? b : a);

  final accent = s.isDark ? AppTheme.gold : AppTheme.goldLightMode;
  final muted = s.isDark ? const Color(0xFF94A3B8) : const Color(0xFF64748B);

  showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    backgroundColor: s.isDark ? AppTheme.darkCard : AppTheme.lightCard,
    shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(26))),
    builder: (ctx) => DraggableScrollableSheet(
      expand: false,
      initialChildSize: 0.88,
      maxChildSize: 0.95,
      builder: (_, sc) => ListView(
        controller: sc,
        padding: const EdgeInsets.fromLTRB(18, 16, 18, 28),
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text('Smart ERP Intelligence', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w900)),
              IconButton(icon: const Icon(Icons.close_rounded), onPressed: () => Navigator.pop(ctx)),
            ],
          ),
          const SizedBox(height: 8),

          // Peak Hours Heatmap
          Card(
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Peak Shopping Hours', style: TextStyle(fontWeight: FontWeight.w800, color: accent)),
                  const SizedBox(height: 10),
                  ...slotRev.entries.map((e) {
                    final ratio = (e.value / maxSlotRev).clamp(0.0, 1.0);
                    return Padding(
                      padding: const EdgeInsets.only(bottom: 8),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text('${e.key} (${slotBills[e.key]} bills)', style: const TextStyle(fontSize: 11.5, fontWeight: FontWeight.w700)),
                              Text(formatInr(e.value), style: const TextStyle(fontSize: 11.5, fontWeight: FontWeight.w900, color: AppTheme.green)),
                            ],
                          ),
                          const SizedBox(height: 4),
                          ClipRRect(
                            borderRadius: BorderRadius.circular(4),
                            child: LinearProgressIndicator(
                              value: ratio,
                              minHeight: 6,
                              backgroundColor: muted.withAlpha(35),
                              valueColor: AlwaysStoppedAnimation<Color>(ratio > 0.7 ? AppTheme.green : accent),
                            ),
                          ),
                        ],
                      ),
                    );
                  }),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),

          // Dead-Stock Aging 30/60/90d
          Card(
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text('Dead-Stock Aging', style: TextStyle(fontWeight: FontWeight.w800, color: AppTheme.rose)),
                      Text('Locked: ${formatInr(deadCapital)}', style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 12, color: AppTheme.rose)),
                    ],
                  ),
                  const SizedBox(height: 10),
                  Row(
                    children: [
                      _agingBox('30+ Days', '${dead30.length} items', accent),
                      const SizedBox(width: 8),
                      _agingBox('60+ Days', '${dead60.length} items', Colors.orangeAccent),
                      const SizedBox(width: 8),
                      _agingBox('90+ Days', '${dead90.length} items', AppTheme.rose),
                    ],
                  ),
                  if (dead90.isNotEmpty || dead60.isNotEmpty) ...[
                    const SizedBox(height: 10),
                    ...([...dead90, ...dead60].take(5)).map((item) => Padding(
                          padding: const EdgeInsets.only(bottom: 4),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Expanded(child: Text('${item.name} (${item.qty} pcs)', style: const TextStyle(fontSize: 11.5, fontWeight: FontWeight.w600))),
                              Text(formatInr(item.costPrice * item.qty), style: const TextStyle(fontSize: 11.5, fontWeight: FontWeight.w800, color: AppTheme.rose)),
                            ],
                          ),
                        )),
                  ],
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),

          // Auto Low-Stock Reorder + 1-Tap Supplier PO PDF
          Card(
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text('Low-Stock Reorder (${lowRows.length} sizes)', style: TextStyle(fontWeight: FontWeight.w800, color: accent)),
                      if (lowRows.isNotEmpty)
                        ElevatedButton.icon(
                          style: ElevatedButton.styleFrom(
                            backgroundColor: accent,
                            foregroundColor: Colors.black,
                            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                            minimumSize: Size.zero,
                          ),
                          onPressed: () => _exportReorderPoPdf(ctx, s, lowRows),
                          icon: const Icon(Icons.picture_as_pdf_rounded, size: 14),
                          label: const Text('Supplier PO PDF', style: TextStyle(fontSize: 11, fontWeight: FontWeight.w800)),
                        ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  if (lowRows.isEmpty)
                    Text('All sizes are well stocked!', style: TextStyle(fontSize: 12, color: muted))
                  else
                    ...lowRows.take(8).map((r) => Padding(
                          padding: const EdgeInsets.symmetric(vertical: 3),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Expanded(child: Text('${r['name']} [${r['size']}]', style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700))),
                              Text('Left: ${r['left']}  •  Order +${r['orderQty']}', style: TextStyle(fontSize: 11, fontWeight: FontWeight.w800, color: (r['left'] as int) == 0 ? AppTheme.rose : accent)),
                            ],
                          ),
                        )),
                ],
              ),
            ),
          ),
        ],
      ),
    ),
  );
}

Widget _agingBox(String title, String val, Color col) => Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 8),
        decoration: BoxDecoration(color: col.withAlpha(24), borderRadius: BorderRadius.circular(12)),
        child: Column(
          children: [
            Text(title, style: TextStyle(fontSize: 10, fontWeight: FontWeight.w700, color: col)),
            const SizedBox(height: 2),
            Text(val, style: const TextStyle(fontSize: 12.5, fontWeight: FontWeight.w900)),
          ],
        ),
      ),
    );
