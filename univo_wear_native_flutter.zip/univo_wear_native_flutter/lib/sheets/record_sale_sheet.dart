import 'package:flutter/material.dart';
import '../core/app_theme.dart';
import '../core/constants.dart';
import '../models/pos_models.dart';
import '../services/pos_store.dart';

class RecordSaleSheet extends StatefulWidget {
  final PosStore store;
  final StockItem? preItem;
  final String? preSize;
  const RecordSaleSheet({super.key, required this.store, this.preItem, this.preSize});

  @override
  State<RecordSaleSheet> createState() => _RecordSaleSheetState();
}

class _RecordSaleSheetState extends State<RecordSaleSheet> {
  StockItem? _item;
  String? _size;
  final _qtyCtrl = TextEditingController(text: '1');
  final _discCtrl = TextEditingController(text: '0');
  final _priceCtrl = TextEditingController(text: '0');
  final _custNameCtrl = TextEditingController();
  final _custPhoneCtrl = TextEditingController();
  String _payment = 'Cash';
  bool _gstEnabled = false;
  final List<CartLine> _cart = [];

  @override
  void initState() {
    super.initState();
    final inStock = widget.store.stock.where((s) => s.qty > 0).toList();
    if (widget.preItem != null) {
      _selectItem(widget.preItem!, preSize: widget.preSize);
    } else if (inStock.isNotEmpty) {
      _selectItem(inStock.first);
    }
  }

  void _selectItem(StockItem item, {String? preSize}) {
    _item = item;
    final avail = item.sizes.entries.where((e) => e.value > 0).map((e) => e.key).toList();
    _size = (preSize != null && avail.contains(preSize)) ? preSize : (avail.isNotEmpty ? avail.first : null);
    _qtyCtrl.text = '1';
    _discCtrl.text = '0';
    _priceCtrl.text = item.sellPrice.toStringAsFixed(0);
  }

  bool _validateCurrentLine(BuildContext context) {
    if (_item == null || _size == null) return false;
    final qty = int.tryParse(_qtyCtrl.text) ?? 1;
    final avail = _item!.sizes[_size!] ?? 0;
    if (qty <= 0 || qty > avail) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Only $avail left in $_size')));
      return false;
    }
    final price = double.tryParse(_priceCtrl.text) ?? 0;
    final unitDisc = (_item!.sellPrice - price) < 0 ? 0.0 : (_item!.sellPrice - price);
    if (!widget.store.isAdmin) {
      if (price < _item!.costPrice) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Blocked: Staff cannot sell below Cost Price!')));
        return false;
      }
      if (unitDisc > widget.store.maxStaffDiscount) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Blocked: Max staff discount is ₹${widget.store.maxStaffDiscount.toStringAsFixed(0)}')));
        return false;
      }
    }
    return true;
  }

  @override
  Widget build(BuildContext context) {
    final inStock = widget.store.stock.where((s) => s.qty > 0).toList();
    final cartTotal = _cart.fold<double>(0, (a, b) => a + b.totalSellPrice);
    final curQty = int.tryParse(_qtyCtrl.text) ?? 1;
    final curPrice = double.tryParse(_priceCtrl.text) ?? 0;
    final baseTotal = _cart.isNotEmpty ? cartTotal : (curQty * curPrice);
    final gstRate = _gstEnabled ? ((curPrice <= 1000) ? 5 : 12) : 0;
    final grandTotal = baseTotal + (_gstEnabled ? (baseTotal * gstRate / 100).roundToDouble() : 0);

    return Padding(
      padding: EdgeInsets.only(
        left: 16,
        right: 16,
        top: 16,
        bottom: MediaQuery.of(context).viewInsets.bottom + 16,
      ),
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Record Sale (Multi-Item POS)', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            const SizedBox(height: 10),
            DropdownButtonFormField<String>(
              value: _item?.id,
              isExpanded: true,
              decoration: const InputDecoration(labelText: 'Select Item'),
              items: inStock
                  .map((i) => DropdownMenuItem(value: i.id, child: Text('${i.name} (${i.qty} pcs - ${formatInr(i.sellPrice)})')))
                  .toList(),
              onChanged: (id) {
                if (id == null) return;
                setState(() => _selectItem(inStock.firstWhere((e) => e.id == id)));
              },
            ),
            if (_item != null) ...[
              const SizedBox(height: 10),
              Wrap(
                spacing: 6,
                children: _item!.sizes.entries.map((e) {
                  return ChoiceChip(
                    label: Text('${e.key} (${e.value})'),
                    selected: _size == e.key,
                    onSelected: e.value > 0 ? (_) => setState(() => _size = e.key) : null,
                  );
                }).toList(),
              ),
              const SizedBox(height: 10),
              Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: _qtyCtrl,
                      keyboardType: TextInputType.number,
                      decoration: const InputDecoration(labelText: 'Qty'),
                      onChanged: (_) => setState(() {}),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: TextField(
                      controller: _discCtrl,
                      keyboardType: TextInputType.number,
                      decoration: const InputDecoration(labelText: 'Less (₹)'),
                      onChanged: (v) {
                        final d = double.tryParse(v) ?? 0;
                        final p = (_item!.sellPrice - d) < 0 ? 0.0 : (_item!.sellPrice - d);
                        setState(() => _priceCtrl.text = p.toStringAsFixed(0));
                      },
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: TextField(
                      controller: _priceCtrl,
                      keyboardType: TextInputType.number,
                      decoration: const InputDecoration(labelText: 'Final (₹)'),
                      onChanged: (v) {
                        final p = double.tryParse(v) ?? 0;
                        final d = (_item!.sellPrice - p) < 0 ? 0.0 : (_item!.sellPrice - p);
                        setState(() => _discCtrl.text = d.toStringAsFixed(0));
                      },
                    ),
                  ),
                ],
              ),
            ],
            const SizedBox(height: 10),
            Row(
              children: [
                Expanded(
                  child: DropdownButtonFormField<String>(
                    value: _payment,
                    decoration: const InputDecoration(labelText: 'Payment'),
                    items: kPaymentModes.map((m) => DropdownMenuItem(value: m, child: Text(m))).toList(),
                    onChanged: (v) {
                      if (v != null) setState(() => _payment = v);
                    },
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: CheckboxListTile(
                    contentPadding: EdgeInsets.zero,
                    title: const Text('GST Bill', style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold)),
                    value: _gstEnabled,
                    onChanged: (v) => setState(() => _gstEnabled = v ?? false),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                Expanded(child: TextField(controller: _custPhoneCtrl, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: 'Customer Mobile'))),
                const SizedBox(width: 8),
                Expanded(child: TextField(controller: _custNameCtrl, decoration: const InputDecoration(labelText: 'Customer Name'))),
              ],
            ),
            if (_cart.isNotEmpty) ...[
              const SizedBox(height: 10),
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: AppTheme.gold),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Cart Items (${_cart.length})', style: const TextStyle(fontWeight: FontWeight.bold, color: AppTheme.gold, fontSize: 12)),
                    ..._cart.asMap().entries.map((entry) => Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Expanded(child: Text('${entry.value.itemName} [${entry.value.size} x${entry.value.qty}]', style: const TextStyle(fontSize: 12))),
                            Text(formatInr(entry.value.totalSellPrice), style: const TextStyle(fontWeight: FontWeight.bold, color: AppTheme.green)),
                            IconButton(
                              icon: const Icon(Icons.close, size: 16, color: Colors.redAccent),
                              onPressed: () => setState(() => _cart.removeAt(entry.key)),
                            ),
                          ],
                        )),
                  ],
                ),
              ),
            ],
            const SizedBox(height: 12),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text('Customer Final Bill:', style: TextStyle(fontWeight: FontWeight.bold)),
                Text(formatInr(grandTotal), style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: AppTheme.green)),
              ],
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton(
                    onPressed: () {
                      if (!_validateCurrentLine(context)) return;
                      setState(() {
                        _cart.add(CartLine(
                          stockId: _item!.id,
                          itemName: _item!.name,
                          hsnCode: _item!.hsnCode,
                          size: _size!,
                          qty: int.tryParse(_qtyCtrl.text) ?? 1,
                          unitMrp: _item!.sellPrice,
                          unitSellPrice: double.tryParse(_priceCtrl.text) ?? _item!.sellPrice,
                          costPrice: _item!.costPrice,
                        ));
                      });
                    },
                    child: const Text('+ Add to Cart'),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  flex: 2,
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppTheme.green,
                      foregroundColor: Colors.black,
                      padding: const EdgeInsets.symmetric(vertical: 14),
                    ),
                    onPressed: () async {
                      List<CartLine> lines = List.from(_cart);
                      if (lines.isEmpty) {
                        if (!_validateCurrentLine(context)) return;
                        lines.add(CartLine(
                          stockId: _item!.id,
                          itemName: _item!.name,
                          hsnCode: _item!.hsnCode,
                          size: _size!,
                          qty: int.tryParse(_qtyCtrl.text) ?? 1,
                          unitMrp: _item!.sellPrice,
                          unitSellPrice: double.tryParse(_priceCtrl.text) ?? _item!.sellPrice,
                          costPrice: _item!.costPrice,
                        ));
                      }
                      await widget.store.completeSale(
                        lines: lines,
                        payment: _payment,
                        gstEnabled: _gstEnabled,
                        customerName: _custNameCtrl.text,
                        customerPhone: _custPhoneCtrl.text,
                      );
                      if (context.mounted) Navigator.pop(context);
                    },
                    child: const Text('Complete Sale', style: TextStyle(fontWeight: FontWeight.bold)),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
