import 'dart:io';
import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import '../core/app_theme.dart';
import '../core/constants.dart';
import '../models/pos_models.dart';
import '../services/pos_store.dart';

void showBillReceiptPngSheet(BuildContext context, PosStore s, SaleRecord sale) {
  final boundaryKey = GlobalKey();
  bool exporting = false;

  showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(28))),
    builder: (ctx) => StatefulBuilder(
      builder: (ctx, setSt) {
        Future<void> sharePng() async {
          setSt(() => exporting = true);
          try {
            final boundary = boundaryKey.currentContext?.findRenderObject() as RenderRepaintBoundary?;
            if (boundary == null) return;
            final image = await boundary.toImage(pixelRatio: 3.0);
            final byteData = await image.toByteData(format: ui.ImageByteFormat.png);
            if (byteData == null) return;
            final pngBytes = byteData.buffer.asUint8List();
            final dir = await getTemporaryDirectory();
            final file = File('${dir.path}/UNIVO_BILL_${sale.id}.png');
            await file.writeAsBytes(pngBytes);
            await Share.shareXFiles(
              [XFile(file.path)],
              text: 'UNIVO WEAR Bill ${sale.id} • Paid: ${formatInr(sale.totalSellPrice)}',
            );
          } catch (e) {
            if (ctx.mounted) {
              ScaffoldMessenger.of(ctx).showSnackBar(SnackBar(content: Text('PNG export error: $e')));
            }
          } finally {
            if (ctx.mounted) setSt(() => exporting = false);
          }
        }

        return Padding(
          padding: const EdgeInsets.fromLTRB(18, 16, 18, 28),
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                // Capturable Branded PNG Bill Receipt Card
                RepaintBoundary(
                  key: boundaryKey,
                  child: Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      color: const Color(0xFFFFFFFF),
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: const Color(0xFFE5B869), width: 1.5),
                    ),
                    child: DefaultTextStyle(
                      style: const TextStyle(color: Color(0xFF111318), fontSize: 12),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              ClipRRect(
                                borderRadius: BorderRadius.circular(10),
                                child: Image.asset('assets/images/univo_logo.png', width: 42, height: 42, fit: BoxFit.cover),
                              ),
                              const SizedBox(width: 10),
                              const Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text('UNIVO WEAR', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900, letterSpacing: 2, color: Color(0xFF111318))),
                                  Text('STYLE YOUR IDENTITY • TAX INVOICE', style: TextStyle(fontSize: 9, fontWeight: FontWeight.w700, color: Color(0xFF9A6B22))),
                                ],
                              ),
                            ],
                          ),
                          const Divider(height: 22, color: Color(0xFFE2E8F0)),
                          _billRow('Invoice No', sale.id),
                          _billRow('Date & Time', '${sale.date} ${sale.time}'),
                          if (sale.customerName.isNotEmpty) _billRow('Customer', '${sale.customerName} ${sale.customerPhone}'),
                          _billRow('Billed By', sale.soldBy),
                          const Divider(height: 18, color: Color(0xFFE2E8F0)),
                          if (sale.cartItems.isNotEmpty)
                            ...sale.cartItems.map((c) => Padding(
                                  padding: const EdgeInsets.symmetric(vertical: 3),
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    children: [
                                      Expanded(child: Text('${c.itemName} [${c.size} x${c.qty}]', style: const TextStyle(fontWeight: FontWeight.w700))),
                                      Text(formatInr(c.totalSellPrice), style: const TextStyle(fontWeight: FontWeight.w800)),
                                    ],
                                  ),
                                ))
                          else
                            _billRow('${sale.itemName} [${sale.size} x${sale.qty}]', formatInr(sale.taxableValue)),
                          const Divider(height: 18, color: Color(0xFFE2E8F0)),
                          if (sale.discount > 0) _billRow('Discount / Less', '-${formatInr(sale.discount)}', valColor: const Color(0xFFB45309)),
                          if (sale.gstTotal > 0) _billRow('GST (${sale.gstRate}% CGST+SGST)', '+${formatInr(sale.gstTotal)}', valColor: const Color(0xFF059669)),
                          _billRow('Payment Mode', sale.payment),
                          const SizedBox(height: 6),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                            decoration: BoxDecoration(color: const Color(0xFFF6F5F1), borderRadius: BorderRadius.circular(12)),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                const Text('FINAL PAID', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 14)),
                                Text(formatInr(sale.totalSellPrice), style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 18, color: Color(0xFF059669))),
                              ],
                            ),
                          ),
                          const SizedBox(height: 10),
                          const Text('Thank you for shopping at UNIVO WEAR!', textAlign: TextAlign.center, style: TextStyle(fontSize: 10, color: Color(0xFF64748B), fontWeight: FontWeight.w600)),
                        ],
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 14),
                Row(
                  children: [
                    Expanded(
                      child: ElevatedButton.icon(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: AppTheme.gold,
                          foregroundColor: Colors.black,
                          padding: const EdgeInsets.symmetric(vertical: 14),
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                        ),
                        onPressed: exporting ? null : sharePng,
                        icon: exporting
                            ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.black))
                            : const Icon(Icons.image_outlined, size: 18),
                        label: const Text('Send Bill PNG', style: TextStyle(fontWeight: FontWeight.w900)),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: ElevatedButton.icon(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: AppTheme.green,
                          foregroundColor: Colors.black,
                          padding: const EdgeInsets.symmetric(vertical: 14),
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                        ),
                        onPressed: () => openWhatsAppMessage(
                          'UNIVO WEAR\nBill: ${sale.id} | ${sale.date}\nItem: ${sale.itemName}\nSize: ${sale.size} (x${sale.qty})\nPaid: ${formatInr(sale.totalSellPrice)} (${sale.payment})',
                          phone: sale.customerPhone,
                        ),
                        icon: const Icon(Icons.share_rounded, size: 18),
                        label: const Text('WhatsApp Text', style: TextStyle(fontWeight: FontWeight.w900)),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                if (!s.isGuest && sale.size != 'MULTI')
                  Row(
                    children: [
                      Expanded(
                        child: OutlinedButton.icon(
                          onPressed: () => _showSizeExchangeDialog(ctx, s, sale),
                          icon: const Icon(Icons.swap_horiz_rounded, size: 16),
                          label: const Text('Exchange Size'),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: OutlinedButton.icon(
                          onPressed: () {
                            final crv = makeId('CRV');
                            openWhatsAppMessage(
                              '🎟️ UNIVO WEAR STORE CREDIT VOUCHER\nCode: $crv\nValue: ${formatInr(sale.totalSellPrice)}\nAgainst Bill: ${sale.id}',
                              phone: sale.customerPhone,
                            );
                          },
                          icon: const Icon(Icons.confirmation_number_outlined, size: 16),
                          label: const Text('Credit Note'),
                        ),
                      ),
                    ],
                  ),
              ],
            ),
          ),
        );
      },
    ),
  );
}

Widget _billRow(String k, String v, {Color? valColor}) {
  return Padding(
    padding: const EdgeInsets.symmetric(vertical: 2),
    child: Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(k, style: const TextStyle(color: Color(0xFF64748B), fontSize: 11)),
        Flexible(child: Text(v, textAlign: TextAlign.right, style: TextStyle(fontWeight: FontWeight.w700, fontSize: 11, color: valColor ?? const Color(0xFF111318)))),
      ],
    ),
  );
}

void _showSizeExchangeDialog(BuildContext context, PosStore s, SaleRecord sale) {
  final matches = s.stock.where((i) => i.id == sale.stockId).toList();
  if (matches.isEmpty) return;
  final stockItem = matches.first;
  String selected = sale.size;
  showDialog(
    context: context,
    builder: (ctx) => StatefulBuilder(
      builder: (ctx, setSt) => AlertDialog(
        title: const Text('Exchange Dress Size'),
        content: DropdownButtonFormField<String>(
          initialValue: stockItem.sizes.containsKey(selected) ? selected : stockItem.sizes.keys.first,
          items: stockItem.sizes.entries
              .map((e) => DropdownMenuItem(value: e.key, child: Text('${e.key} (${e.value} in stock)')))
              .toList(),
          onChanged: (v) {
            if (v != null) setSt(() => selected = v);
          },
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          ElevatedButton(
            onPressed: () async {
              final err = await s.exchangeSaleSize(sale, selected);
              if (ctx.mounted) Navigator.pop(ctx);
              if (context.mounted) {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text(err ?? 'Exchanged size to $selected!')),
                );
              }
            },
            child: const Text('Confirm Exchange'),
          ),
        ],
      ),
    ),
  );
}
