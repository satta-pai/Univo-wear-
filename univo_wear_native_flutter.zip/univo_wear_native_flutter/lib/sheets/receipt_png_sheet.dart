import 'package:flutter/services.dart';
import 'package:intl/intl.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'png_share_helper.dart';
import 'dart:io';
import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import '../core/app_theme.dart';
import '../core/constants.dart';
import '../models/pos_models.dart';
import '../services/pos_store.dart';

void showBillReceiptPngSheet(BuildContext context, PosStore s, SaleRecord sale) {
  final boundaryKey = GlobalKey();
  bool exporting = false;

  showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(28))),
    builder: (ctx) => StatefulBuilder(
      builder: (ctx, setSt) {
        Future<void> sharePng() async {
          setSt(() => exporting = true);
          try {
            final boundary = boundaryKey.currentContext?.findRenderObject() as RenderRepaintBoundary?;
            if (boundary == null) return;
            final image = await boundary.toImage(pixelRatio: 3.0);
            final byteData = await image.toByteData(format: ui.ImageByteFormat.png);
            if (byteData == null) return;
            final pngBytes = byteData.buffer.asUint8List();
            final dir = await getTemporaryDirectory();
            final file = File('${dir.path}/UNIVO_BILL_${sale.id}.png');
            await file.writeAsBytes(pngBytes);
            await SharePlus.instance.share(
              ShareParams(
                files: [XFile(file.path)],
                text: 'UNIVO WEAR Bill ${sale.id} • Paid: ${formatInr(sale.totalSellPrice)}',
              ),
            );
          } catch (e) {
            if (ctx.mounted) {
              ScaffoldMessenger.of(ctx).showSnackBar(SnackBar(content: Text('PNG export error: $e')));
            }
          } finally {
            if (ctx.mounted) setSt(() => exporting = false);
          }
        }

        return Padding(
          padding: const EdgeInsets.fromLTRB(18, 16, 18, 28),
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                // Capturable Branded PNG Bill Receipt Card
                RepaintBoundary(
                  key: boundaryKey,
                  child: Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      color: const Color(0xFFFFFFFF),
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: const Color(0xFFE5B869), width: 1.5),
                    ),
                    child: DefaultTextStyle(
                      style: const TextStyle(color: Color(0xFF111318), fontSize: 12),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              ClipRRect(
                                borderRadius: BorderRadius.circular(10),
                                child: Image.asset('assets/images/univo_logo.png', width: 42, height: 42, fit: BoxFit.cover),
                              ),
                              const SizedBox(width: 10),
                              const Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text('UNIVO WEAR', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900, letterSpacing: 2, color: Color(0xFF111318))),
                                  Text('STYLE YOUR IDENTITY • TAX INVOICE', style: TextStyle(fontSize: 9, fontWeight: FontWeight.w700, color: Color(0xFF9A6B22))),
                                ],
                              ),
                            ],
                          ),
                          const Divider(height: 22, color: Color(0xFFE2E8F0)),
                          _billRow('Invoice No', sale.id),
                          _billRow('Date & Time', '${sale.date} ${sale.time}'),
                          if (sale.customerName.isNotEmpty || sale.customerPhone.isNotEmpty) _billRow('Customer', '${sale.customerName} ${sale.customerPhone}'.trim()),
                          _billRow('Billed By', sale.soldBy),
                          const Divider(height: 18, color: Color(0xFFE2E8F0)),
                          if (sale.cartItems.isNotEmpty)
                            ...sale.cartItems.map((c) => Padding(
                                  padding: const EdgeInsets.symmetric(vertical: 3),
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    children: [
                                      Expanded(child: Text('${c.itemName} [${c.size} x${c.qty}]', style: const TextStyle(fontWeight: FontWeight.w700))),
                                      Text(formatInr(c.mrpTotal > 0 ? c.mrpTotal : c.totalSellPrice), style: const TextStyle(fontWeight: FontWeight.w800)),
                                    ],
                                  ),
                                ))
                          else
                            _billRow('${sale.itemName} [${sale.size} x${sale.qty}]', formatInr(sale.mrpTotal > 0 ? sale.mrpTotal : (sale.totalSellPrice + sale.discount - sale.gstTotal))),
                          const Divider(height: 18, color: Color(0xFFE2E8F0)),
                          if (sale.discount > 0 || sale.gstTotal > 0) _billRow('Subtotal (MRP)', formatInr(sale.mrpTotal > 0 ? sale.mrpTotal : (sale.totalSellPrice + sale.discount - sale.gstTotal))),
                          if (sale.discount > 0) _billRow('Discount / Less', '-${formatInr(sale.discount)}', valColor: const Color(0xFFB45309)),
                          if (sale.gstTotal > 0) _billRow('GST (${sale.gstRate}% CGST+SGST)', '+${formatInr(sale.gstTotal)}', valColor: const Color(0xFF059669)),
                          _billRow('Payment Mode', sale.payment),
                          const SizedBox(height: 6),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                            decoration: BoxDecoration(color: const Color(0xFFF6F5F1), borderRadius: BorderRadius.circular(12)),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                const Text('FINAL PAID', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 14)),
                                Text(formatInr(sale.totalSellPrice), style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 18, color: Color(0xFF059669))),
                              ],
                            ),
                          ),
                          const SizedBox(height: 10),
                          const Text('Thank you for shopping at UNIVO WEAR!', textAlign: TextAlign.center, style: TextStyle(fontSize: 10, color: Color(0xFF64748B), fontWeight: FontWeight.w600)),
                        ],
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 14),
                Row(
                  children: [
                    Expanded(
                      child: ElevatedButton.icon(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: AppTheme.gold,
                          foregroundColor: Colors.black,
                          padding: const EdgeInsets.symmetric(vertical: 14),
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                        ),
                        onPressed: exporting ? null : sharePng,
                        icon: exporting
                            ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.black))
                            : const Icon(Icons.image_outlined, size: 18),
                        label: const Text('Send Bill PNG', style: TextStyle(fontWeight: FontWeight.w900)),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: ElevatedButton.icon(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: AppTheme.green,
                          foregroundColor: Colors.black,
                          padding: const EdgeInsets.symmetric(vertical: 14),
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                        ),
                        onPressed: exporting
                            ? null
                            : () async {
                                setSt(() => exporting = true);
                                try {
                                  final res = await captureAndSaveOrSharePng(
                                    boundaryKey,
                                    fileNamePrefix: 'UNIVO_BILL_${sale.id}',
                                    share: false,
                                  );
                                  if (res != null && ctx.mounted) {
                                    ScaffoldMessenger.of(ctx).showSnackBar(
                                      SnackBar(
                                        content: Text(res.inDownloads
                                            ? 'Bill PNG saved to Downloads: ${res.fileName}'
                                            : 'Bill PNG saved to Storage: ${res.fileName}'),
                                      ),
                                    );
                                  }
                                } finally {
                                  if (ctx.mounted) setSt(() => exporting = false);
                                }
                              },
                        icon: const Icon(Icons.download_rounded, size: 18),
                        label: const Text('Save Bill PNG', style: TextStyle(fontWeight: FontWeight.w900)),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                SizedBox(
                  width: double.infinity,
                  child: OutlinedButton.icon(
                    style: OutlinedButton.styleFrom(
                      padding: const EdgeInsets.symmetric(vertical: 13),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                    ),
                    onPressed: exporting ? null : () => printBillReceiptPdf(ctx, sale),
                    icon: const Icon(Icons.print_rounded, size: 18, color: AppTheme.gold),
                    label: const Text('Print Bill (Thermal / A4 Printer)', style: TextStyle(fontWeight: FontWeight.w800)),
                  ),
                ),
                const SizedBox(height: 8),
                if (!s.isGuest && sale.size != 'MULTI')
                  Row(
                    children: [
                      Expanded(
                        child: OutlinedButton.icon(
                          onPressed: () => _showSizeExchangeDialog(ctx, s, sale),
                          icon: const Icon(Icons.swap_horiz_rounded, size: 16),
                          label: const Text('Exchange Size'),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: OutlinedButton.icon(
                          onPressed: () {
                            final crv = makeId('CRV');
                            showBrandedPngSlipSheet(
                              ctx,
                              title: 'Store Credit Voucher',
                              subtitle: 'Issued: ${getLocalDateString()}',
                              fileNamePrefix: 'UNIVO_VOUCHER_$crv',
                              rows: [
                                MapEntry('Voucher Code', crv),
                                MapEntry('Against Bill', sale.id),
                                if (sale.customerName.isNotEmpty) MapEntry('Customer', sale.customerName),
                                if (sale.customerPhone.isNotEmpty) MapEntry('Mobile', sale.customerPhone),
                              ],
                              highlightLabel: 'CREDIT VALUE',
                              highlightValue: formatInr(sale.totalSellPrice),
                              footerText: 'Redeemable on your next purchase at UNIVO WEAR.',
                            );
                          },
                          icon: const Icon(Icons.confirmation_number_outlined, size: 16),
                          label: const Text('Credit Note'),
                        ),
                      ),
                    ],
                  ),
              ],
            ),
          ),
        );
      },
    ),
  );
}

Widget _billRow(String k, String v, {Color? valColor}) {
  return Padding(
    padding: const EdgeInsets.symmetric(vertical: 2),
    child: Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(k, style: const TextStyle(color: Color(0xFF64748B), fontSize: 11)),
        Flexible(child: Text(v, textAlign: TextAlign.right, style: TextStyle(fontWeight: FontWeight.w700, fontSize: 11, color: valColor ?? const Color(0xFF111318)))),
      ],
    ),
  );
}

void _showSizeExchangeDialog(BuildContext context, PosStore s, SaleRecord sale) {
  final matches = s.stock.where((i) => i.id == sale.stockId).toList();
  if (matches.isEmpty) return;
  final stockItem = matches.first;
  String selected = sale.size;
  showDialog(
    context: context,
    builder: (ctx) => StatefulBuilder(
      builder: (ctx, setSt) => AlertDialog(
        title: const Text('Exchange Dress Size'),
        content: DropdownButtonFormField<String>(
          initialValue: stockItem.sizes.containsKey(selected) ? selected : stockItem.sizes.keys.first,
          items: stockItem.sizes.entries
              .map((e) => DropdownMenuItem(value: e.key, child: Text('${e.key} (${e.value} in stock)')))
              .toList(),
          onChanged: (v) {
            if (v != null) setSt(() => selected = v);
          },
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          ElevatedButton(
            onPressed: () async {
              final err = await s.exchangeSaleSize(sale, selected);
              if (ctx.mounted) Navigator.pop(ctx);
              if (context.mounted) {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text(err ?? 'Exchanged size to $selected!')),
                );
              }
            },
            child: const Text('Confirm Exchange'),
          ),
        ],
      ),
    ),
  );
}

const MethodChannel _printerChannel = MethodChannel('com.univowear.pos/updater');

String _tRs(double v) => 'Rs. ${NumberFormat('#,##0', 'en_IN').format(v.round())}';

Future<void> printBillReceiptPdf(BuildContext context, SaleRecord sale) async {
  try {
    final doc = pw.Document();
    final mrpSub = sale.mrpTotal > 0 ? sale.mrpTotal : (sale.totalSellPrice + sale.discount - sale.gstTotal);

    doc.addPage(
      pw.Page(
        pageFormat: PdfPageFormat.roll80,
        margin: const pw.EdgeInsets.symmetric(horizontal: 10, vertical: 12),
        build: (ctx) => pw.Column(
          crossAxisAlignment: pw.CrossAxisAlignment.stretch,
          children: [
            pw.Center(child: pw.Text('UNIVO WEAR', style: pw.TextStyle(fontSize: 15, fontWeight: pw.FontWeight.bold))),
            pw.Center(child: pw.Text('STYLE YOUR IDENTITY', style: const pw.TextStyle(fontSize: 7.5))),
            pw.SizedBox(height: 6),
            pw.Divider(borderStyle: pw.BorderStyle.dashed, thickness: 0.7),
            pw.Text('Bill: ${sale.id}', style: const pw.TextStyle(fontSize: 8)),
            pw.Text('Date: ${sale.date} ${sale.time}', style: const pw.TextStyle(fontSize: 8)),
            if (sale.customerName.isNotEmpty || sale.customerPhone.isNotEmpty)
              pw.Text('Customer: ${sale.customerName} ${sale.customerPhone}'.trim(), style: const pw.TextStyle(fontSize: 8)),
            pw.Text('Staff: ${sale.soldBy}', style: const pw.TextStyle(fontSize: 8)),
            pw.Divider(borderStyle: pw.BorderStyle.dashed, thickness: 0.7),
            if (sale.cartItems.isNotEmpty)
              ...sale.cartItems.map((c) => pw.Padding(
                    padding: const pw.EdgeInsets.symmetric(vertical: 2),
                    child: pw.Row(
                      mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
                      children: [
                        pw.Expanded(child: pw.Text('${c.itemName} [${c.size} x${c.qty}]', style: const pw.TextStyle(fontSize: 8.5))),
                        pw.Text(_tRs(c.mrpTotal > 0 ? c.mrpTotal : c.totalSellPrice), style: pw.TextStyle(fontSize: 8.5, fontWeight: pw.FontWeight.bold)),
                      ],
                    ),
                  ))
            else
              pw.Row(
                mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
                children: [
                  pw.Expanded(child: pw.Text('${sale.itemName} [${sale.size} x${sale.qty}]', style: const pw.TextStyle(fontSize: 8.5))),
                  pw.Text(_tRs(mrpSub), style: pw.TextStyle(fontSize: 8.5, fontWeight: pw.FontWeight.bold)),
                ],
              ),
            pw.Divider(borderStyle: pw.BorderStyle.dashed, thickness: 0.7),
            if (sale.discount > 0 || sale.gstTotal > 0)
              pw.Row(
                mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
                children: [
                  pw.Text('Subtotal', style: const pw.TextStyle(fontSize: 8.5)),
                  pw.Text(_tRs(mrpSub), style: const pw.TextStyle(fontSize: 8.5)),
                ],
              ),
            if (sale.discount > 0)
              pw.Row(
                mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
                children: [
                  pw.Text('Less / Discount', style: const pw.TextStyle(fontSize: 8.5)),
                  pw.Text('-${_tRs(sale.discount)}', style: const pw.TextStyle(fontSize: 8.5)),
                ],
              ),
            if (sale.gstTotal > 0)
              pw.Row(
                mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
                children: [
                  pw.Text('GST (${sale.gstRate}%)', style: const pw.TextStyle(fontSize: 8.5)),
                  pw.Text('+${_tRs(sale.gstTotal)}', style: const pw.TextStyle(fontSize: 8.5)),
                ],
              ),
            pw.Row(
              mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
              children: [
                pw.Text('Payment', style: const pw.TextStyle(fontSize: 8.5)),
                pw.Text(sale.payment, style: const pw.TextStyle(fontSize: 8.5)),
              ],
            ),
            pw.SizedBox(height: 4),
            pw.Divider(thickness: 1),
            pw.Row(
              mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
              children: [
                pw.Text('FINAL PAID', style: pw.TextStyle(fontSize: 11, fontWeight: pw.FontWeight.bold)),
                pw.Text(_tRs(sale.totalSellPrice), style: pw.TextStyle(fontSize: 12, fontWeight: pw.FontWeight.bold)),
              ],
            ),
            pw.Divider(thickness: 1),
            pw.SizedBox(height: 6),
            pw.Center(child: pw.Text('Thank you for shopping at UNIVO WEAR!', style: const pw.TextStyle(fontSize: 7.5))),
          ],
        ),
      ),
    );

    final bytes = await doc.save();
    final dir = await getTemporaryDirectory();
    final file = File('${dir.path}/UNIVO_PRINT_${sale.id}.pdf');
    await file.writeAsBytes(bytes, flush: true);

    try {
      await _printerChannel.invokeMethod('printPdf', {
        'path': file.path,
        'jobName': 'UNIVO_BILL_${sale.id}',
      });
    } catch (_) {
      // Fallback: share thermal PDF to RawBT / Bluetooth Print / Printer App
      await SharePlus.instance.share(
        ShareParams(
          files: [XFile(file.path)],
          text: 'Print UNIVO WEAR Bill ${sale.id}',
        ),
      );
    }
  } catch (e) {
    if (context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Print error: $e')));
    }
  }
}
