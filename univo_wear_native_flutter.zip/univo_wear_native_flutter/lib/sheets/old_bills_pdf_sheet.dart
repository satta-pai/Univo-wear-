import 'package:flutter/services.dart';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:path_provider/path_provider.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:share_plus/share_plus.dart';
import 'package:url_launcher/url_launcher.dart';
import '../core/app_theme.dart';
import '../core/constants.dart';
import '../models/pos_models.dart';
import '../services/pos_store.dart';

class SavedPdfResult {
  final String path;
  final String fileName;
  final bool inDownloads;
  SavedPdfResult({required this.path, required this.fileName, required this.inDownloads});
}

String _pdfRs(double v) => 'Rs. ${NumberFormat('#,##0', 'en_IN').format(v.round())}';

String _billDateDisplay(SaleRecord sale) {
  try {
    if (sale.date.length >= 10) {
      final dt = DateTime.parse(sale.date.substring(0, 10));
      return DateFormat('EEE, dd MMM yyyy').format(dt);
    }
    final dt = DateTime.parse(sale.createdAt);
    return DateFormat('EEE, dd MMM yyyy').format(dt);
  } catch (_) {
    return sale.date.isNotEmpty ? sale.date : 'Unknown Date';
  }
}

String _billIsoDate(SaleRecord sale) {
  if (sale.date.length >= 10) return sale.date.substring(0, 10);
  if (sale.createdAt.length >= 10) return sale.createdAt.substring(0, 10);
  return '';
}

String _billMonthKey(SaleRecord sale) {
  final iso = _billIsoDate(sale);
  return iso.length >= 7 ? iso.substring(0, 7) : '';
}

String _monthLabel(String ym) {
  try {
    final dt = DateTime.parse('$ym-01');
    return DateFormat('MMM yyyy').format(dt);
  } catch (_) {
    return ym;
  }
}

Future<SavedPdfResult> generateAndSaveBillsPdf({
  required List<SaleRecord> bills,
  required String periodLabel,
  required String generatedBy,
}) async {
  final sorted = List<SaleRecord>.from(bills)
    ..sort((a, b) => b.createdAt.compareTo(a.createdAt));

  final totalQty = sorted.fold<int>(0, (a, b) => a + b.qty);
  final totalDisc = sorted.fold<double>(0, (a, b) => a + b.discount);
  final netTotal = sorted.fold<double>(0, (a, b) => a + b.totalSellPrice);

  double cashTotal = 0, upiTotal = 0, cardTotal = 0, creditTotal = 0, otherTotal = 0;
  for (final x in sorted) {
    final p = x.payment.toLowerCase();
    if (p.contains('cash')) {
      cashTotal += x.totalSellPrice;
    } else if (p.contains('upi') || p.contains('gpay') || p.contains('phonepe') || p.contains('paytm') || p.contains('online') || p.contains('qr')) {
      upiTotal += x.totalSellPrice;
    } else if (p.contains('card')) {
      cardTotal += x.totalSellPrice;
    } else if (p.contains('credit') || p.contains('khata')) {
      creditTotal += x.totalSellPrice;
    } else {
      otherTotal += x.totalSellPrice;
    }
  }

  final doc = pw.Document();
  final nowStr = DateFormat('dd MMM yyyy, hh:mm a').format(DateTime.now());

  doc.addPage(
    pw.MultiPage(
      pageFormat: PdfPageFormat.a4,
      margin: const pw.EdgeInsets.all(22),
      header: (ctx) => pw.Column(
        crossAxisAlignment: pw.CrossAxisAlignment.start,
        children: [
          pw.Row(
            mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
            children: [
              pw.Column(
                crossAxisAlignment: pw.CrossAxisAlignment.start,
                children: [
                  pw.Text('UNIVO WEAR', style: pw.TextStyle(fontSize: 18, fontWeight: pw.FontWeight.bold)),
                  pw.Text('Sales Statement - $periodLabel', style: const pw.TextStyle(fontSize: 10, color: PdfColors.grey700)),
                ],
              ),
              pw.Column(
                crossAxisAlignment: pw.CrossAxisAlignment.end,
                children: [
                  pw.Text('Date: $nowStr', style: const pw.TextStyle(fontSize: 9, color: PdfColors.grey700)),
                  pw.Text('Total Bills: ${sorted.length} ($totalQty pcs)', style: pw.TextStyle(fontSize: 9.5, fontWeight: pw.FontWeight.bold)),
                ],
              ),
            ],
          ),
          pw.SizedBox(height: 6),
          pw.Divider(color: PdfColors.grey400),
        ],
      ),
      footer: (ctx) => pw.Row(
        mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
        children: [
          pw.Text('UNIVO WEAR', style: const pw.TextStyle(fontSize: 8, color: PdfColors.grey600)),
          pw.Text('Page ${ctx.pageNumber} of ${ctx.pagesCount}', style: const pw.TextStyle(fontSize: 8, color: PdfColors.grey600)),
        ],
      ),
      build: (ctx) => [
        pw.Container(
          padding: const pw.EdgeInsets.all(10),
          decoration: pw.BoxDecoration(
            color: PdfColors.grey100,
            borderRadius: pw.BorderRadius.circular(6),
            border: pw.Border.all(color: PdfColors.grey300),
          ),
          child: pw.Column(
            children: [
              pw.Row(
                mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
                children: [
                  pw.Text('Cash: ${_pdfRs(cashTotal)}', style: pw.TextStyle(fontSize: 9.5, fontWeight: pw.FontWeight.bold)),
                  pw.Text('UPI / GPay: ${_pdfRs(upiTotal)}', style: pw.TextStyle(fontSize: 9.5, fontWeight: pw.FontWeight.bold)),
                  pw.Text('Card: ${_pdfRs(cardTotal)}', style: pw.TextStyle(fontSize: 9.5, fontWeight: pw.FontWeight.bold)),
                  pw.Text('Credit: ${_pdfRs(creditTotal)}', style: pw.TextStyle(fontSize: 9.5, fontWeight: pw.FontWeight.bold)),
                ],
              ),
              pw.SizedBox(height: 6),
              pw.Divider(color: PdfColors.grey300, height: 1),
              pw.SizedBox(height: 6),
              pw.Row(
                mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
                children: [
                  pw.Text('Total Less / Discount: ${_pdfRs(totalDisc)}', style: const pw.TextStyle(fontSize: 9.5, color: PdfColors.grey800)),
                  if (otherTotal > 0)
                    pw.Text('Other: ${_pdfRs(otherTotal)}', style: const pw.TextStyle(fontSize: 9.5, color: PdfColors.grey800)),
                  pw.Text('GRAND TOTAL: ${_pdfRs(netTotal)}', style: pw.TextStyle(fontSize: 12, fontWeight: pw.FontWeight.bold)),
                ],
              ),
            ],
          ),
        ),
        pw.SizedBox(height: 12),
        if (sorted.isEmpty)
          pw.Center(child: pw.Text('No bills found for this period.', style: const pw.TextStyle(fontSize: 11)))
        else
          pw.TableHelper.fromTextArray(
            headerStyle: pw.TextStyle(fontSize: 8.5, fontWeight: pw.FontWeight.bold, color: PdfColors.white),
            headerDecoration: const pw.BoxDecoration(color: PdfColors.grey900),
            cellStyle: const pw.TextStyle(fontSize: 8.5),
            cellPadding: const pw.EdgeInsets.symmetric(horizontal: 5, vertical: 4),
            oddRowDecoration: const pw.BoxDecoration(color: PdfColors.grey100),
            headers: const ['#', 'Date & Time', 'Item & Size', 'Staff', 'Payment', 'Less', 'Amount'],
            data: List.generate(sorted.length, (i) {
              final b = sorted[i];
              final dtStr = '${_billIsoDate(b)} ${b.time}'.trim();
              final payClean = b.payment.contains('UPI') ? 'UPI/GPay' : b.payment;
              return [
                '${i + 1}',
                dtStr,
                '${b.itemName} (${b.size} x${b.qty})',
                b.soldBy,
                payClean,
                b.discount > 0 ? _pdfRs(b.discount) : '-',
                _pdfRs(b.totalSellPrice),
              ];
            }),
          ),
      ],
    ),
  );

  final bytes = await doc.save();
  final safeLabel = periodLabel.replaceAll(RegExp(r'[^A-Za-z0-9_-]+'), '_');
  final stamp = DateFormat('yyyyMMdd_HHmm').format(DateTime.now());
  final fileName = 'UNIVO_WEAR_Bills_${safeLabel}_$stamp.pdf';

  // Try saving directly to Android Downloads folder first, fallback gracefully to app external/docs storage
  try {
    final dlDir = Platform.isWindows
        ? await getDownloadsDirectory()
        : Directory('/storage/emulated/0/Download');
    if (dlDir != null && await dlDir.exists()) {
      final f = File('${dlDir.path}${Platform.pathSeparator}$fileName');
      await f.writeAsBytes(bytes, flush: true);
      return SavedPdfResult(path: f.path, fileName: fileName, inDownloads: true);
    }
  } catch (_) {}

  try {
    final extDir = await getExternalStorageDirectory();
    if (extDir != null) {
      final outDir = Directory('${extDir.path}/UNIVO_WEAR_Bills');
      if (!await outDir.exists()) await outDir.create(recursive: true);
      final f = File('${outDir.path}/$fileName');
      await f.writeAsBytes(bytes, flush: true);
      return SavedPdfResult(path: f.path, fileName: fileName, inDownloads: false);
    }
  } catch (_) {}

  final appDir = await getApplicationDocumentsDirectory();
  final f = File('${appDir.path}/$fileName');
  await f.writeAsBytes(bytes, flush: true);
  return SavedPdfResult(path: f.path, fileName: fileName, inDownloads: false);
}

Future<void> _sendWhatsAppDeleteAlert(PosStore s) async {
  final days = s.daysUntilMonthlyAutoDelete;
  final count = s.currentMonthBills.length;
  final sum = s.currentMonthBills.fold<double>(0, (a, b) => a + b.totalSellPrice);
  final monthStr = DateFormat('MMMM yyyy').format(DateTime.now());
  final msg = 'UNIVO WEAR ALERT (Owner & Admin)\n'
      'Monthly Old Bills Auto-Delete in $days day(s)!\n'
      'Month: $monthStr | Bills: $count | Total: ${formatInr(sum)}\n'
      'Please open UNIVO WEAR app -> Old Bills Archive -> Save Total PDF to phone storage before the 1st of next month.';
  final uri = Uri.parse('https://wa.me/?text=${Uri.encodeComponent(msg)}');
  if (await canLaunchUrl(uri)) {
    await launchUrl(uri, mode: LaunchMode.externalApplication);
  }
}

Future<void> showDeleteWarningPopupIfNeeded(BuildContext context, PosStore s) async {
  if (!s.isWithin3DayDeleteWarning) return;
  try {
    const MethodChannel('com.univowear.pos/updater').invokeMethod('showLocalNotification', {
      'title': 'UNIVO WEAR • Auto-Delete in ${s.daysUntilMonthlyAutoDelete} day(s)!',
      'body': 'Save this month Old Bills PDF to phone storage before automatic monthly cleanup.',
    });
  } catch (_) {}
  final days = s.daysUntilMonthlyAutoDelete;
  final count = s.currentMonthBills.length;
  final sum = s.currentMonthBills.fold<double>(0, (a, b) => a + b.totalSellPrice);
  final monthName = DateFormat('MMMM yyyy').format(DateTime.now());
  final countdownText = days == 0
      ? 'TONIGHT at 12:00 AM (Final Day!)'
      : 'in $days day${days == 1 ? '' : 's'}';

  if (!context.mounted) return;
  await showDialog(
    context: context,
    builder: (dCtx) => AlertDialog(
      title: Row(
        children: const [
          Icon(Icons.notifications_active_rounded, color: AppTheme.rose),
          SizedBox(width: 8),
          Expanded(child: Text('Monthly Bills Auto-Delete Alert', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800))),
        ],
      ),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            '$monthName old bills ($count bills • ${formatInr(sum)}) will be automatically deleted $countdownText.',
            style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13),
          ),
          const SizedBox(height: 8),
          Text(
            'இன்னும் $days நாட்களில் இந்த மாத பழைய பில்கள் தானாக டெலீட் ஆகப் போகுது! இப்பவே Total PDF-ஆக Storage-ல சேவ் பண்ணிக்கோங்க.',
            style: const TextStyle(fontSize: 12),
          ),
        ],
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(dCtx),
          child: const Text('Later'),
        ),
        TextButton.icon(
          icon: const Icon(Icons.share_rounded, size: 16),
          label: const Text('Notify Admins'),
          onPressed: () => _sendWhatsAppDeleteAlert(s),
        ),
        ElevatedButton.icon(
          style: ElevatedButton.styleFrom(backgroundColor: AppTheme.gold, foregroundColor: Colors.black),
          icon: const Icon(Icons.picture_as_pdf_rounded, size: 16),
          label: const Text('Save PDF Now', style: TextStyle(fontWeight: FontWeight.w800)),
          onPressed: () async {
            Navigator.pop(dCtx);
            final res = await generateAndSaveBillsPdf(
              bills: s.currentMonthBills,
              periodLabel: monthName,
              generatedBy: s.userName,
            );
            await s.saveMonthlyAutoDeleteConfig(lastBackupMonth: s.currentMonthKey);
            if (context.mounted) {
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text(res.inDownloads
                      ? 'Saved PDF to Downloads: ${res.fileName}'
                      : 'Saved PDF to Storage: ${res.fileName}'),
                  action: SnackBarAction(
                    label: 'SHARE',
                    onPressed: () => SharePlus.instance.share(ShareParams(files: [XFile(res.path)], text: 'UNIVO WEAR $monthName Old Bills PDF')),
                  ),
                ),
              );
            }
          },
        ),
      ],
    ),
  );
}

void showOldBillsArchiveSheet(BuildContext context, PosStore s) {
  if (!s.isAdmin) {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Only Owner & Admin can access Old Bills Archive & PDF Export.')),
    );
    return;
  }

  final monthsSet = <String>{};
  for (final b in s.sales) {
    final mk = _billMonthKey(b);
    if (mk.isNotEmpty) monthsSet.add(mk);
  }
  final months = monthsSet.toList()..sort((a, b) => b.compareTo(a));

  String selectedMonth = 'ALL';
  DateTime? pickedDate;
  bool busyPdf = false;
  String? lastSavedPath;

  showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    backgroundColor: s.isDark ? AppTheme.darkCard : AppTheme.lightCard,
    shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
    builder: (ctx) => StatefulBuilder(
      builder: (ctx, setSt) {
        final filtered = s.sales.where((b) {
          final iso = _billIsoDate(b);
          if (pickedDate != null) {
            final targetIso = DateFormat('yyyy-MM-dd').format(pickedDate!);
            return iso == targetIso;
          }
          if (selectedMonth != 'ALL') {
            return _billMonthKey(b) == selectedMonth;
          }
          return true;
        }).toList()
          ..sort((a, b) => b.createdAt.compareTo(a.createdAt));

        final totalAmt = filtered.fold<double>(0, (a, b) => a + b.totalSellPrice);
        final totalLess = filtered.fold<double>(0, (a, b) => a + b.discount);
        final periodLabel = pickedDate != null
            ? DateFormat('dd MMM yyyy').format(pickedDate!)
            : (selectedMonth == 'ALL' ? 'All Old Bills' : _monthLabel(selectedMonth));

        // Group filtered bills by ISO Date
        final grouped = <String, List<SaleRecord>>{};
        for (final b in filtered) {
          final k = _billIsoDate(b).isNotEmpty ? _billIsoDate(b) : 'Other';
          grouped.putIfAbsent(k, () => []).add(b);
        }
        final dateKeys = grouped.keys.toList()..sort((a, b) => b.compareTo(a));

        final muted = s.isDark ? const Color(0xFF94A3B8) : const Color(0xFF64748B);
        final border = s.isDark ? AppTheme.darkBorder : AppTheme.lightBorder;
        final accent = s.isDark ? AppTheme.gold : AppTheme.goldLightMode;
        final daysLeft = s.daysUntilMonthlyAutoDelete;

        return DraggableScrollableSheet(
          expand: false,
          initialChildSize: 0.88,
          minChildSize: 0.55,
          maxChildSize: 0.95,
          builder: (_, scrollCtrl) => Padding(
            padding: const EdgeInsets.fromLTRB(16, 14, 16, 16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Center(
                  child: Container(
                    width: 42,
                    height: 4,
                    decoration: BoxDecoration(color: muted.withAlpha(90), borderRadius: BorderRadius.circular(4)),
                  ),
                ),
                const SizedBox(height: 12),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text('Old Bills Archive & PDF', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
                        
                      ],
                    ),
                    IconButton(
                      icon: const Icon(Icons.close_rounded),
                      onPressed: () => Navigator.pop(ctx),
                    ),
                  ],
                ),
                const SizedBox(height: 10),

                // Monthly Auto-Delete & 3-Day Warning Status Card
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: (daysLeft <= 3 && s.autoDeleteMonthlyBills)
                        ? AppTheme.rose.withAlpha(24)
                        : accent.withAlpha(18),
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(
                      color: (daysLeft <= 3 && s.autoDeleteMonthlyBills)
                          ? AppTheme.rose.withAlpha(110)
                          : border,
                    ),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Icon(
                            daysLeft <= 3 ? Icons.notifications_active_rounded : Icons.auto_delete_rounded,
                            size: 18,
                            color: daysLeft <= 3 ? AppTheme.rose : accent,
                          ),
                          const SizedBox(width: 8),
                          Expanded(
                            child: Text(
                              s.autoDeleteMonthlyBills
                                  ? 'Monthly Auto-Delete ON • $daysLeft day(s) to month-end'
                                  : 'Monthly Auto-Delete PAUSED',
                              style: TextStyle(
                                fontWeight: FontWeight.w800,
                                fontSize: 12,
                                color: daysLeft <= 3 ? AppTheme.rose : null,
                              ),
                            ),
                          ),
                          Switch(
                            value: s.autoDeleteMonthlyBills,
                            onChanged: (v) async {
                              await s.saveMonthlyAutoDeleteConfig(enabled: v);
                              setSt(() {});
                            },
                          ),
                        ],
                      ),

                    ],
                  ),
                ),
                const SizedBox(height: 10),

                // Month Filter Chips + Exact Date Picker
                SizedBox(
                  height: 36,
                  child: ListView(
                    scrollDirection: Axis.horizontal,
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(right: 6),
                        child: ActionChip(
                          avatar: Icon(Icons.calendar_month_rounded, size: 15, color: accent),
                          label: Text(
                            pickedDate == null ? 'Pick Date' : DateFormat('dd MMM yyyy').format(pickedDate!),
                            style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w700),
                          ),
                          onPressed: () async {
                            final d = await showDatePicker(
                              context: ctx,
                              initialDate: pickedDate ?? DateTime.now(),
                              firstDate: DateTime(2024),
                              lastDate: DateTime(2030),
                            );
                            if (d != null) setSt(() { pickedDate = d; lastSavedPath = null; });
                          },
                        ),
                      ),
                      if (pickedDate != null)
                        Padding(
                          padding: const EdgeInsets.only(right: 6),
                          child: ActionChip(
                            label: const Text('Clear Date', style: TextStyle(fontSize: 11)),
                            onPressed: () => setSt(() { pickedDate = null; lastSavedPath = null; }),
                          ),
                        ),
                      ...['ALL', ...months].map((m) {
                        final act = pickedDate == null && selectedMonth == m;
                        return Padding(
                          padding: const EdgeInsets.only(right: 6),
                          child: ChoiceChip(
                            label: Text(m == 'ALL' ? 'All Months' : _monthLabel(m), style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w700)),
                            selected: act,
                            onSelected: (_) => setSt(() {
                              pickedDate = null;
                              selectedMonth = m;
                              lastSavedPath = null;
                            }),
                          ),
                        );
                      }),
                    ],
                  ),
                ),
                const SizedBox(height: 10),

                // Total Summary + Save PDF & Share Buttons
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: s.isDark ? AppTheme.darkSurface : AppTheme.lightSurface,
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: border),
                  ),
                  child: Column(
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text('$periodLabel (${filtered.length} bills)', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 12)),
                          Text('Less: ${formatInr(totalLess)}', style: TextStyle(color: AppTheme.rose, fontSize: 11, fontWeight: FontWeight.w700)),
                          Text(formatInr(totalAmt), style: const TextStyle(color: AppTheme.green, fontWeight: FontWeight.w900, fontSize: 14)),
                        ],
                      ),
                      const SizedBox(height: 10),
                      Row(
                        children: [
                          Expanded(
                            child: ElevatedButton.icon(
                              style: ElevatedButton.styleFrom(
                                backgroundColor: accent,
                                foregroundColor: const Color(0xFF0A0B0E),
                                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                              ),
                              icon: busyPdf
                                  ? const SizedBox(width: 14, height: 14, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.black))
                                  : const Icon(Icons.picture_as_pdf_rounded, size: 17),
                              label: Text(busyPdf ? 'Saving PDF...' : 'Save Total PDF', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 12)),
                              onPressed: (busyPdf || filtered.isEmpty)
                                  ? null
                                  : () async {
                                      setSt(() => busyPdf = true);
                                      try {
                                        final res = await generateAndSaveBillsPdf(
                                          bills: filtered,
                                          periodLabel: periodLabel,
                                          generatedBy: s.userName,
                                        );
                                        lastSavedPath = res.path;
                                        if (selectedMonth == 'ALL' || selectedMonth == s.currentMonthKey) {
                                          await s.saveMonthlyAutoDeleteConfig(lastBackupMonth: s.currentMonthKey);
                                        }
                                        if (ctx.mounted) {
                                          ScaffoldMessenger.of(ctx).showSnackBar(
                                            SnackBar(
                                              content: Text(res.inDownloads
                                                  ? 'PDF saved in Downloads: ${res.fileName}'
                                                  : 'PDF saved in Storage: ${res.fileName}'),
                                            ),
                                          );
                                        }
                                      } catch (e) {
                                        if (ctx.mounted) {
                                          ScaffoldMessenger.of(ctx).showSnackBar(SnackBar(content: Text('PDF Error: $e')));
                                        }
                                      } finally {
                                        setSt(() => busyPdf = false);
                                      }
                                    },
                            ),
                          ),
                          const SizedBox(width: 8),
                          OutlinedButton.icon(
                            style: OutlinedButton.styleFrom(shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
                            icon: const Icon(Icons.share_rounded, size: 16),
                            label: const Text('Share PDF', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700)),
                            onPressed: (busyPdf || filtered.isEmpty)
                                ? null
                                : () async {
                                    setSt(() => busyPdf = true);
                                    try {
                                      String p = lastSavedPath ?? '';
                                      if (p.isEmpty || !await File(p).exists()) {
                                        final res = await generateAndSaveBillsPdf(
                                          bills: filtered,
                                          periodLabel: periodLabel,
                                          generatedBy: s.userName,
                                        );
                                        p = res.path;
                                        lastSavedPath = p;
                                      }
                                      await SharePlus.instance.share(ShareParams(files: [XFile(p)], text: 'UNIVO WEAR Old Bills PDF ($periodLabel)'));
                                    } finally {
                                      setSt(() => busyPdf = false);
                                    }
                                  },
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 10),

                // Date-Grouped Old Bills List
                Expanded(
                  child: dateKeys.isEmpty
                      ? Center(child: Text('No old bills for $periodLabel', style: TextStyle(color: muted)))
                      : ListView.builder(
                          controller: scrollCtrl,
                          itemCount: dateKeys.length,
                          itemBuilder: (_, idx) {
                            final dk = dateKeys[idx];
                            final dayBills = grouped[dk]!;
                            final daySum = dayBills.fold<double>(0, (a, b) => a + b.totalSellPrice);
                            final prettyDate = _billDateDisplay(dayBills.first);
                            return Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Padding(
                                  padding: const EdgeInsets.only(top: 10, bottom: 6),
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    children: [
                                      Text(prettyDate, style: TextStyle(fontWeight: FontWeight.w800, fontSize: 12, color: accent)),
                                      Text('${dayBills.length} bills • ${formatInr(daySum)}', style: TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: muted)),
                                    ],
                                  ),
                                ),
                                ...dayBills.map((b) => Container(
                                      margin: const EdgeInsets.only(bottom: 6),
                                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
                                      decoration: BoxDecoration(
                                        color: s.isDark ? AppTheme.darkSurface : AppTheme.lightSurface,
                                        borderRadius: BorderRadius.circular(12),
                                        border: Border.all(color: border),
                                      ),
                                      child: Row(
                                        children: [
                                          Expanded(
                                            child: Column(
                                              crossAxisAlignment: CrossAxisAlignment.start,
                                              children: [
                                                Text('${b.itemName} (${b.size} × ${b.qty})', style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 12.5)),
                                                const SizedBox(height: 2),
                                                Text(
                                                  '${b.date} ${b.time} • ${b.payment} • By ${b.soldBy}${b.discount > 0 ? ' • Less ${formatInr(b.discount)}' : ''}',
                                                  style: TextStyle(fontSize: 10.5, color: muted),
                                                ),
                                              ],
                                            ),
                                          ),
                                          Text(formatInr(b.totalSellPrice), style: const TextStyle(color: AppTheme.green, fontWeight: FontWeight.w900, fontSize: 13)),
                                          if (DateTime.now().difference(DateTime.tryParse(_billIsoDate(b)) ?? DateTime(2020)).inDays <= 7)
                                            IconButton(
                                              padding: EdgeInsets.zero,
                                              constraints: const BoxConstraints(minWidth: 32),
                                              icon: const Icon(Icons.restore_from_trash_rounded, size: 18, color: AppTheme.rose),
                                              tooltip: 'Restore & Delete (7-Day Window)',
                                              onPressed: () async {
                                                final rCtrl = TextEditingController();
                                                final reason = await showDialog<String>(
                                                  context: ctx,
                                                  builder: (dCtx) => AlertDialog(
                                                    title: const Text('Restore & Delete Bill'),
                                                    content: TextField(
                                                      controller: rCtrl,
                                                      decoration: const InputDecoration(labelText: 'Restore Reason *'),
                                                    ),
                                                    actions: [
                                                      TextButton(onPressed: () => Navigator.pop(dCtx, null), child: const Text('Cancel')),
                                                      ElevatedButton(
                                                        onPressed: () {
                                                          if (rCtrl.text.trim().isEmpty) return;
                                                          Navigator.pop(dCtx, rCtrl.text.trim());
                                                        },
                                                        child: const Text('Restore'),
                                                      ),
                                                    ],
                                                  ),
                                                );
                                                if (reason != null && reason.isNotEmpty) {
                                                  await s.refundSale(b, reason: reason);
                                                  setSt(() {});
                                                }
                                              },
                                            ),
                                        ],
                                      ),
                                    )),
                              ],
                            );
                          },
                        ),
                ),
              ],
            ),
          ),
        );
      },
    ),
  );
}
