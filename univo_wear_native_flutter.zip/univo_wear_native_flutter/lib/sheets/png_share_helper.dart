import 'dart:io';
import 'dart:ui' as ui;
import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:intl/intl.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import '../core/app_theme.dart';

class SavedPngResult {
  final String path;
  final String fileName;
  final bool inDownloads;
  SavedPngResult({required this.path, required this.fileName, required this.inDownloads});
}

Future<SavedPngResult?> captureAndSaveOrSharePng(
  GlobalKey boundaryKey, {
  required String fileNamePrefix,
  required bool share,
  String shareText = 'UNIVO WEAR',
}) async {
  if (kIsWeb) return null;
  final boundary = boundaryKey.currentContext?.findRenderObject() as RenderRepaintBoundary?;
  if (boundary == null) return null;
  final image = await boundary.toImage(pixelRatio: 3.0);
  final byteData = await image.toByteData(format: ui.ImageByteFormat.png);
  if (byteData == null) return null;
  final pngBytes = byteData.buffer.asUint8List();

  final safePrefix = fileNamePrefix.replaceAll(RegExp(r'[^A-Za-z0-9_-]+'), '_');
  final stamp = DateFormat('yyyyMMdd_HHmmss').format(DateTime.now());
  final fileName = '${safePrefix}_$stamp.png';

  if (share) {
    final dir = await getTemporaryDirectory();
    final f = File('${dir.path}/$fileName');
    await f.writeAsBytes(pngBytes, flush: true);
    await SharePlus.instance.share(
      ShareParams(
        files: [XFile(f.path)],
        text: shareText,
      ),
    );
    return SavedPngResult(path: f.path, fileName: fileName, inDownloads: false);
  }

  try {
    final dlDir = Directory('/storage/emulated/0/Download');
    if (await dlDir.exists()) {
      final f = File('${dlDir.path}/$fileName');
      await f.writeAsBytes(pngBytes, flush: true);
      return SavedPngResult(path: f.path, fileName: fileName, inDownloads: true);
    }
  } catch (_) {}

  try {
    final extDir = await getExternalStorageDirectory();
    if (extDir != null) {
      final outDir = Directory('${extDir.path}/UNIVO_WEAR_Images');
      if (!await outDir.exists()) await outDir.create(recursive: true);
      final f = File('${outDir.path}/$fileName');
      await f.writeAsBytes(pngBytes, flush: true);
      return SavedPngResult(path: f.path, fileName: fileName, inDownloads: false);
    }
  } catch (_) {}

  final appDir = await getApplicationDocumentsDirectory();
  final f = File('${appDir.path}/$fileName');
  await f.writeAsBytes(pngBytes, flush: true);
  return SavedPngResult(path: f.path, fileName: fileName, inDownloads: false);
}

void showBrandedPngSlipSheet(
  BuildContext context, {
  required String title,
  required String subtitle,
  required String fileNamePrefix,
  required List<MapEntry<String, String>> rows,
  required String highlightLabel,
  required String highlightValue,
  String footerText = 'Thank you for shopping at UNIVO WEAR!',
}) {
  final boundaryKey = GlobalKey();
  bool busy = false;

  showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(26))),
    builder: (ctx) => StatefulBuilder(
      builder: (ctx, setSt) {
        Future<void> runExport(bool doShare) async {
          if (busy) return;
          setSt(() => busy = true);
          try {
            final res = await captureAndSaveOrSharePng(
              boundaryKey,
              fileNamePrefix: fileNamePrefix,
              share: doShare,
              shareText: 'UNIVO WEAR - $title',
            );
            if (!doShare && res != null && ctx.mounted) {
              ScaffoldMessenger.of(ctx).showSnackBar(
                SnackBar(
                  content: Text(res.inDownloads
                      ? 'PNG saved to Downloads: ${res.fileName}'
                      : 'PNG saved to Storage: ${res.fileName}'),
                ),
              );
            }
          } catch (e) {
            if (ctx.mounted) {
              ScaffoldMessenger.of(ctx).showSnackBar(SnackBar(content: Text('PNG error: $e')));
            }
          } finally {
            if (ctx.mounted) setSt(() => busy = false);
          }
        }

        return Padding(
          padding: const EdgeInsets.fromLTRB(18, 16, 18, 26),
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                RepaintBoundary(
                  key: boundaryKey,
                  child: Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      color: const Color(0xFFFFFFFF),
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: const Color(0xFFE5B869), width: 1.5),
                    ),
                    child: DefaultTextStyle(
                      style: const TextStyle(color: Color(0xFF111318), fontSize: 12),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              ClipRRect(
                                borderRadius: BorderRadius.circular(10),
                                child: Image.asset('assets/images/univo_logo.png', width: 40, height: 40, fit: BoxFit.cover),
                              ),
                              const SizedBox(width: 10),
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  const Text('UNIVO WEAR', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w900, letterSpacing: 2, color: Color(0xFF111318))),
                                  Text(title.toUpperCase(), style: const TextStyle(fontSize: 9, fontWeight: FontWeight.w800, color: Color(0xFF9A6B22))),
                                ],
                              ),
                            ],
                          ),
                          if (subtitle.isNotEmpty) ...[
                            const SizedBox(height: 6),
                            Text(subtitle, textAlign: TextAlign.center, style: const TextStyle(fontSize: 10, color: Color(0xFF64748B))),
                          ],
                          const Divider(height: 20, color: Color(0xFFE2E8F0)),
                          ...rows.map((e) => Padding(
                                padding: const EdgeInsets.symmetric(vertical: 3),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text(e.key, style: const TextStyle(color: Color(0xFF475569), fontSize: 11.5)),
                                    const SizedBox(width: 10),
                                    Flexible(
                                      child: Text(
                                        e.value,
                                        textAlign: TextAlign.right,
                                        style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 12, color: Color(0xFF0F172A)),
                                      ),
                                    ),
                                  ],
                                ),
                              )),
                          const SizedBox(height: 10),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                            decoration: BoxDecoration(color: const Color(0xFFF6F5F1), borderRadius: BorderRadius.circular(12)),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text(highlightLabel, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 13)),
                                Text(highlightValue, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 17, color: Color(0xFF059669))),
                              ],
                            ),
                          ),
                          const SizedBox(height: 10),
                          Text(footerText, textAlign: TextAlign.center, style: const TextStyle(fontSize: 10, color: Color(0xFF64748B), fontWeight: FontWeight.w600)),
                        ],
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 14),
                Row(
                  children: [
                    Expanded(
                      child: ElevatedButton.icon(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: AppTheme.gold,
                          foregroundColor: Colors.black,
                          padding: const EdgeInsets.symmetric(vertical: 14),
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                        ),
                        onPressed: busy ? null : () => runExport(true),
                        icon: busy
                            ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.black))
                            : const Icon(Icons.share_rounded, size: 18),
                        label: const Text('Share PNG', style: TextStyle(fontWeight: FontWeight.w900)),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: ElevatedButton.icon(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: AppTheme.green,
                          foregroundColor: Colors.black,
                          padding: const EdgeInsets.symmetric(vertical: 14),
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                        ),
                        onPressed: busy ? null : () => runExport(false),
                        icon: const Icon(Icons.download_rounded, size: 18),
                        label: const Text('Save PNG', style: TextStyle(fontWeight: FontWeight.w900)),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    ),
  );
}
